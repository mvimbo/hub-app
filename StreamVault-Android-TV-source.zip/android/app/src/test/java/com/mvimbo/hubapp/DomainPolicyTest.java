package com.mvimbo.hubapp;

import static org.junit.Assert.*;
import java.net.InetAddress;
import org.junit.Test;

public class DomainPolicyTest {
    private final DomainPolicy policy = new DomainPolicy();

    @Test public void blocksAdvertisingHostAndSubdomainsOnly() {
        assertTrue(policy.isBlocked("doubleclick.net"));
        assertTrue(policy.isBlocked("secure.doubleclick.net"));
        assertTrue(policy.isBlocked("DOUBLECLICK.NET."));
        assertFalse(policy.isBlocked("notdoubleclick.net"));
        assertFalse(policy.isBlocked("doubleclick.net.example.org"));
    }

    @Test public void preservesKnownVideoAndCatalogHosts() {
        assertFalse(policy.isBlocked("vidsrc.me"));
        assertFalse(policy.isBlocked("youtube.com"));
        assertFalse(policy.isBlocked("api.themoviedb.org"));
        assertFalse(policy.isBlocked("image.tmdb.org"));
    }

    @Test public void deniesPrivateOrLinkLocalAddressRanges() throws Exception {
        for (String host : new String[] {
            "127.0.0.1", "10.0.0.1", "172.16.0.1", "192.168.1.1",
            "169.254.169.254", "100.64.0.1", "::1", "fc00::1", "fe80::1"
        }) assertFalse(host, DomainPolicy.isPublic(InetAddress.getByName(host)));
        assertTrue(DomainPolicy.isPublic(InetAddress.getByName("8.8.8.8")));
        assertTrue(DomainPolicy.isPublic(InetAddress.getByName("2606:4700:4700::1111")));
    }

    @Test public void reportsRealAdvertisingRuleCount() {
        assertEquals(24, policy.ruleCount());
    }
}
