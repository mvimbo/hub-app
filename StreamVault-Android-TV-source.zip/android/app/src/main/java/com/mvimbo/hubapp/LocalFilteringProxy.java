package com.mvimbo.hubapp;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.concurrent.*;

/**
 * Device-local HTTPS CONNECT and HTTP GET/HEAD proxy, with bounded resources.
 * Only public destinations on ports 443/80 are reachable. TLS is opaque.
 */
public final class LocalFilteringProxy implements AutoCloseable {
    private final DomainPolicy policy;
    private final Set<Socket> sockets = ConcurrentHashMap.newKeySet();
    private ServerSocket listener;
    private ExecutorService connections;
    private ExecutorService reverse;
    private volatile boolean running;

    public LocalFilteringProxy(DomainPolicy policy) { this.policy = policy; }

    private static ExecutorService pool(String name) {
        return new ThreadPoolExecutor(0, 32, 30, TimeUnit.SECONDS,
            new SynchronousQueue<>(), task -> {
                Thread thread = new Thread(task, name);
                thread.setDaemon(true);
                return thread;
            }, new ThreadPoolExecutor.AbortPolicy());
    }

    public synchronized int start() throws IOException {
        if (running) return listener.getLocalPort();
        listener = new ServerSocket();
        listener.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 32);
        connections = pool("streamvault-proxy");
        reverse = pool("streamvault-relay");
        running = true;
        Thread thread = new Thread(this::accept, "streamvault-proxy-listener");
        thread.setDaemon(true);
        thread.start();
        return listener.getLocalPort();
    }

    private void accept() {
        ServerSocket server = listener;
        while (running && !server.isClosed()) {
            try {
                Socket client = server.accept();
                sockets.add(client);
                try { connections.execute(() -> handle(client)); }
                catch (RejectedExecutionException ignored) { closeSocket(client); }
            } catch (IOException ignored) { break; }
        }
    }

    private static String readHeader(InputStream stream) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int trailing = 0;
        while (buffer.size() < 16384) {
            int value = stream.read();
            if (value < 0) throw new EOFException();
            buffer.write(value);
            trailing = (trailing << 8) | value;
            if (trailing == 0x0d0a0d0a)
                return new String(buffer.toByteArray(), StandardCharsets.US_ASCII);
        }
        throw new IOException("Header too large");
    }

    private static void reply(Socket client, int code, String message) throws IOException {
        client.getOutputStream().write(("HTTP/1.1 " + code + " " + message
            + "\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
            .getBytes(StandardCharsets.US_ASCII));
        client.getOutputStream().flush();
    }

    private void handle(Socket client) {
        Socket upstream = null;
        boolean established = false;
        CountDownLatch ready = new CountDownLatch(1);
        try {
            client.setSoTimeout(10000);
            String header = readHeader(client.getInputStream());
            String[] lines = header.split("\r\n");
            String[] request = lines[0].split(" ");
            if (request.length != 3 || !request[2].matches("HTTP/1\\.[01]")) {
                reply(client, 400, "Bad Request"); return;
            }
            boolean tunnel = request[0].equals("CONNECT");
            URI uri;
            if (tunnel) uri = new URI("https://" + request[1]);
            else {
                if (!request[0].equals("GET") && !request[0].equals("HEAD")) {
                    reply(client, 405, "Method Not Allowed"); return;
                }
                uri = new URI(request[1]);
            }
            String host = uri.getHost();
            int port = uri.getPort() == -1 ? (tunnel ? 443 : 80) : uri.getPort();
            if (host == null || !host.matches("[a-zA-Z0-9.-]{1,253}")
                || uri.getUserInfo() != null || uri.getFragment() != null
                || (tunnel && (port != 443 || !uri.getRawPath().isEmpty() || uri.getQuery() != null))
                || (!tunnel && (!"http".equals(uri.getScheme()) || port != 80))) {
                reply(client, 403, "Destination Not Allowed"); return;
            }
            if (policy.isBlocked(host)) {
                policy.blocked.incrementAndGet();
                reply(client, 403, "Blocked"); return;
            }
            // Resolve once and connect to that same address, preventing DNS rebinding.
            InetAddress[] addresses = InetAddress.getAllByName(host);
            for (InetAddress address : addresses) {
                if (!DomainPolicy.isPublic(address)) {
                    reply(client, 403, "Destination Not Allowed"); return;
                }
            }
            if (addresses.length == 0) throw new UnknownHostException();
            upstream = new Socket();
            sockets.add(upstream);
            upstream.connect(new InetSocketAddress(addresses[0], port), 10000);
            upstream.setSoTimeout(60000);
            client.setSoTimeout(60000);
            if (!tunnel) {
                String path = uri.getRawPath().isEmpty() ? "/" : uri.getRawPath();
                if (uri.getRawQuery() != null) path += "?" + uri.getRawQuery();
                StringBuilder forward = new StringBuilder(request[0] + " " + path
                    + " HTTP/1.1\r\nHost: " + host + "\r\nConnection: close\r\n");
                for (int i = 1; i < lines.length; i++) {
                    int colon = lines[i].indexOf(':');
                    if (colon < 1) throw new IOException("Invalid header");
                    String key = lines[i].substring(0, colon).toLowerCase(java.util.Locale.ROOT);
                    if (key.equals("transfer-encoding") || key.equals("content-length")) {
                        reply(client, 400, "Request Body Not Allowed"); return;
                    }
                    if (!java.util.Arrays.asList("host", "connection", "proxy-connection",
                        "proxy-authorization", "keep-alive", "upgrade").contains(key))
                        forward.append(lines[i]).append("\r\n");
                }
                forward.append("\r\n");
                upstream.getOutputStream().write(forward.toString().getBytes(StandardCharsets.US_ASCII));
                upstream.getOutputStream().flush();
            }
            Socket remote = upstream;
            // Reserve a relay thread before acknowledging the tunnel.
            reverse.execute(() -> {
                try {
                    ready.await();
                    pump(remote.getInputStream(), client.getOutputStream());
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                } catch (IOException ignored) {
                    // Peer closed or the idle timeout expired.
                } finally { closeSocket(remote); closeSocket(client); }
            });
            if (tunnel) {
                client.getOutputStream().write("HTTP/1.1 200 Connection Established\r\n\r\n"
                    .getBytes(StandardCharsets.US_ASCII));
                client.getOutputStream().flush();
            }
            established = true;
            ready.countDown();
            pump(client.getInputStream(), remote.getOutputStream());
        } catch (Exception ignored) {
            // Never log hostnames, signed URLs, request headers or TLS payloads.
            if (!established) try { reply(client, 502, "Proxy Connection Failed"); }
                catch (IOException suppressed) { /* Socket already closed. */ }
        } finally {
            ready.countDown();
            closeSocket(client);
            if (upstream != null) closeSocket(upstream);
        }
    }

    private static void pump(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[16384];
        int read;
        while ((read = input.read(buffer)) != -1) {
            output.write(buffer, 0, read);
            output.flush();
        }
    }

    private void closeSocket(Socket socket) {
        sockets.remove(socket);
        try { socket.close(); } catch (IOException ignored) { }
    }

    public boolean isRunning() { return running; }

    @Override public synchronized void close() {
        running = false;
        if (listener != null) try { listener.close(); } catch (IOException ignored) { }
        for (Socket socket : sockets) closeSocket(socket);
        if (connections != null) connections.shutdownNow();
        if (reverse != null) reverse.shutdownNow();
    }
}
