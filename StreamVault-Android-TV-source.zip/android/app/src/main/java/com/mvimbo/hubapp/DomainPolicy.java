package com.mvimbo.hubapp;

import java.net.InetAddress;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

/** Host-only filtering. Never decrypts TLS or reads video, cookies or passwords. */
public final class DomainPolicy {
    private static final Set<String> AD_HOSTS = java.util.Collections.unmodifiableSet(
        new java.util.HashSet<>(java.util.Arrays.asList(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adservice.google.co.uk", "popads.net",
        "popcash.net", "propellerads.com", "onclickads.net", "a-ads.com",
        "adsterra.com", "adsterra.org", "exoclick.com", "exosrv.com",
        "trafficjunky.net", "juicyads.com", "adsrvr.org", "adroll.com",
        "scorecardresearch.com", "quantserve.com", "criteo.com",
        "criteo.net", "taboola.com", "outbrain.com"
    )));
    public final AtomicLong blocked = new AtomicLong();

    public boolean isBlocked(String host) {
        String value = host.toLowerCase(java.util.Locale.ROOT);
        while (value.endsWith(".")) value = value.substring(0, value.length() - 1);
        for (String rule : AD_HOSTS) {
            if (value.equals(rule) || value.endsWith("." + rule)) return true;
        }
        return false;
    }

    public int ruleCount() { return AD_HOSTS.size(); }

    public static boolean isPublic(InetAddress address) {
        if (address.isAnyLocalAddress() || address.isLoopbackAddress()
            || address.isLinkLocalAddress() || address.isSiteLocalAddress()
            || address.isMulticastAddress()) return false;
        byte[] bytes = address.getAddress();
        if (bytes.length == 16) return (bytes[0] & 0xfe) != 0xfc;
        int a = bytes[0] & 255, b = bytes[1] & 255, c = bytes[2] & 255;
        return !(a == 0 || a == 10 || a == 127 || a >= 224
            || (a == 100 && b >= 64 && b <= 127)
            || (a == 169 && b == 254) || (a == 172 && b >= 16 && b <= 31)
            || (a == 192 && b == 168) || (a == 192 && b == 0 && c == 0)
            || (a == 198 && (b == 18 || b == 19)));
    }
}
