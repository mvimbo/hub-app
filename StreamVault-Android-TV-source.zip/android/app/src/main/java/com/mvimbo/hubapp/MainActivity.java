package com.mvimbo.hubapp;

import android.os.Bundle;
import android.os.Message;
import android.webkit.WebView;
import android.webkit.WebResourceRequest;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.*;

public class MainActivity extends BridgeActivity {
    private View fullscreenView;
    private android.webkit.WebChromeClient.CustomViewCallback fullscreenCallback;
    private int previousVisibility;
    private OnBackPressedCallback fullscreenBack;

    private void hideFullscreen() {
        if (fullscreenView == null) return;
        ((ViewGroup) getWindow().getDecorView()).removeView(fullscreenView);
        fullscreenView = null;
        getBridge().getWebView().setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(previousVisibility);
        fullscreenBack.setEnabled(false);
        if (fullscreenCallback != null) fullscreenCallback.onCustomViewHidden();
        fullscreenCallback = null;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(RequestGuardPlugin.class);
        super.onCreate(savedInstanceState);
        WebView view = getBridge().getWebView();
        fullscreenBack = new OnBackPressedCallback(false) {
            @Override public void handleOnBackPressed() { hideFullscreen(); }
        };
        getOnBackPressedDispatcher().addCallback(this, fullscreenBack);
        view.getSettings().setMediaPlaybackRequiresUserGesture(false);
        // Report new-window requests rather than letting them replace the app.
        view.getSettings().setSupportMultipleWindows(true);
        view.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        view.setWebChromeClient(new BridgeWebChromeClient(getBridge()) {
            @Override public boolean onCreateWindow(WebView webView, boolean dialog,
                boolean gesture, Message message) { return false; }
            @Override public void onShowCustomView(View content, CustomViewCallback callback) {
                if (fullscreenView != null) { callback.onCustomViewHidden(); return; }
                fullscreenView = content;
                fullscreenCallback = callback;
                previousVisibility = getWindow().getDecorView().getSystemUiVisibility();
                content.setBackgroundColor(android.graphics.Color.BLACK);
                ((ViewGroup) getWindow().getDecorView()).addView(content,
                    new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                view.setVisibility(View.INVISIBLE);
                getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                fullscreenBack.setEnabled(true);
            }
            @Override public void onHideCustomView() { hideFullscreen(); }
        });
        getBridge().setWebViewClient(new BridgeWebViewClient(getBridge()) {
            @Override public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest request) {
                // Prevent automatic top-level redirects out of the bundled application.
                if (request.isForMainFrame() && !"localhost".equals(request.getUrl().getHost())
                    && !request.hasGesture()) return true;
                return super.shouldOverrideUrlLoading(webView, request);
            }
        });
    }
}
