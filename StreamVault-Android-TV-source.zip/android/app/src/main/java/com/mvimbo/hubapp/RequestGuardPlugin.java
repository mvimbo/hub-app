package com.mvimbo.hubapp;

import android.content.Context;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.IOException;

@CapacitorPlugin(name = "RequestGuard")
public final class RequestGuardPlugin extends Plugin {
    private final DomainPolicy policy = new DomainPolicy();
    private final LocalFilteringProxy proxy = new LocalFilteringProxy(policy);
    private volatile boolean enabled;
    private volatile boolean changing;
    private String reason;

    private boolean supported() { return WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE); }

    @Override public void load() {
        if (!supported()) { reason = "Update Android System WebView to use request protection."; return; }
        boolean requested = getContext().getSharedPreferences("request_guard", Context.MODE_PRIVATE)
            .getBoolean("enabled", true);
        getActivity().runOnUiThread(() -> apply(requested, null));
    }

    private JSObject status() {
        JSObject result = new JSObject();
        result.put("available", supported());
        result.put("enabled", enabled && proxy.isRunning());
        result.put("blockedRequests", policy.blocked.get());
        result.put("popupBlocking", true);
        result.put("ruleCount", policy.ruleCount());
        if (reason != null) result.put("reason", reason);
        return result;
    }

    @PluginMethod public void getStatus(PluginCall call) { call.resolve(status()); }

    @PluginMethod public void setEnabled(PluginCall call) {
        Boolean requested = call.getBoolean("enabled");
        if (requested == null) { call.reject("enabled must be a boolean"); return; }
        if (!supported()) { call.reject("This WebView does not support proxy override."); return; }
        getActivity().runOnUiThread(() -> apply(requested, call));
    }

    private void apply(boolean requested, PluginCall call) {
        if (changing) { if (call != null) call.reject("A protection change is already in progress."); return; }
        changing = true;
        Runnable applied = () -> {
            enabled = requested;
            changing = false;
            reason = null;
            if (!requested) proxy.close();
            getContext().getSharedPreferences("request_guard", Context.MODE_PRIVATE)
                .edit().putBoolean("enabled", requested).apply();
            if (call != null) call.resolve(status());
        };
        try {
            if (requested) {
                int port = proxy.start();
                ProxyConfig config = new ProxyConfig.Builder()
                    .addProxyRule("127.0.0.1:" + port)
                    .addBypassRule("localhost").addBypassRule("127.0.0.1").addBypassRule("[::1]")
                    .build();
                ProxyController.getInstance().setProxyOverride(config,
                    task -> getActivity().runOnUiThread(task), applied);
            } else ProxyController.getInstance().clearProxyOverride(
                task -> getActivity().runOnUiThread(task), applied);
        } catch (IOException | RuntimeException error) {
            changing = false;
            enabled = false;
            reason = "Request protection could not start. Retry from Settings.";
            proxy.close();
            if (call != null) call.reject(reason);
        }
    }

    @Override protected void handleOnDestroy() {
        proxy.close();
        if (supported()) ProxyController.getInstance().clearProxyOverride(Runnable::run, () -> {});
    }
}
