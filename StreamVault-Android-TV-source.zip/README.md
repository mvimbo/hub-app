# StreamVault Android / TV

Separate, installable Capacitor Android application for Android phones/tablets
and Android/Google TV. The original StreamVault browser project is not changed.

## Features

- Bundled five-second Aurelia launch video centered at its original proportions
  on a full-screen black background (browser VP8 + Android H.264-compatible
  copies of the supplied clip) on every cold launch; **no Skip**.
  A denied autoplay request offers Start intro; a file failure offers Retry.
  The catalog opens only when the video finishes.
- Existing movies, TV, Cartoon, Korean, Documentary, Sports and News catalog.
- Provider-owned iframe playback and fullscreen; no custom progress simulation
  or downloads. Continue Watching records opened titles/episodes, not an
  invented playback position.
- Device-local favorites, watchlist and viewing history.
- Touch navigation, visible keyboard/D-pad focus and TV launcher support.
- Settings with native protection state, compatibility toggle and real blocked
  request count. Browser preview clearly reports native protection unavailable.

## Local filtering, not a remote open proxy

The Android WebView uses a loopback-only HTTP/CONNECT proxy. It filters
24 known advertising/tracking host families. HTTPS travels in an opaque
tunnel: no TLS certificate installation, decryption, page rewriting, DRM
workarounds or provider-control replacement. Pop-up windows are refused.
Public destinations are limited to HTTP port 80 and HTTPS port 443.
Private, loopback, link-local and carrier-NAT destinations are rejected inside
the proxy; the bundled localhost Capacitor origin bypasses it.

This reduces some ads; it cannot remove first-party or server-inserted ads.
Providers may block embedding or ad filtering, stop operating, or require
regional authorization. Toggle protection off in Settings for compatibility,
then reopen the player. Unsupported WebViews report the limitation rather than
pretending filtering is enabled. WebView proxy settings are per app process,
not a device-wide VPN or proxy for other applications.

## Build prerequisites

Node.js 22+, pnpm 10+, JDK 21, Android SDK platform 36 and build tools 36.0.0.
For GUI development use Android Studio with these components installed.
Android 7.0+ (API 24) and an up-to-date Android System WebView are required.
Samsung Tizen, LG webOS, Apple TV and iOS are **not** supported by this Android
package. The TV device must support Android applications.

```sh
pnpm install
cp .env.example .env
# Set your own TMDB client API key in .env for movie/TV metadata.
# TMDB client keys are included in the locally-built app and can be extracted.
# Use a key you own; never commit it or reuse it as a private server credential.
pnpm run android:sync
cd android
./gradlew testDebugUnitTest assembleDebug
```

The installable development APK is
`android/app/build/outputs/apk/debug/app-debug.apk`.
Use `adb install -r` or Android Studio to install it on a phone or TV.
The debug APK is for device testing. Store distribution needs your own release
signing key, a release build and store review; signing keys never belong in Git.
On TV, sideloading/unknown-source permissions may be required.

To preview in a browser use `pnpm run dev`. The web preview is not the Android
runtime and cannot verify native proxy filtering or remote-control hardware.

## Checks

```sh
pnpm run typecheck
pnpm test
mkdir -p /tmp/streamvault-native-test
javac -d /tmp/streamvault-native-test \
  android/app/src/main/java/com/mvimbo/hubapp/DomainPolicy.java \
  android/app/src/main/java/com/mvimbo/hubapp/LocalFilteringProxy.java \
  tests/NativeProxyCheck.java
java -cp /tmp/streamvault-native-test NativeProxyCheck
```

The offline proxy checks exercise host boundaries, private-network rejection,
blocked counters and a real loopback listener. They do not verify third-party
video availability or playback on physical hardware.

## Data and distribution

TMDB provides metadata, not video playback rights. The movie/TV catalog is
disabled until an authorized TMDB client key is configured for the build; the
app calls this out in the Home screen rather than silently showing empty rows.
Sports data and official news
links use their existing providers; no unlicensed live-sports sources are added.
No third-party videos are downloaded or hosted by this repository. Ensure
permission for every video/broadcaster and for the supplied intro before
commercial distribution. The supplied intro is part of this public source
repository as requested for this app.

There is no central user account, hotel administration, subscription or
multi-tenant white-label platform in this version. Device preferences are
separate from the original browser app and do not erase its saved data.
