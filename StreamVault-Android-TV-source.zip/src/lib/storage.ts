export type MediaType = "movie" | "tv";

export interface SavedItem {
  id: number;
  type: MediaType;
  title: string;
  poster_path: string | null;
  vote_average?: number;
  release_date?: string;
  timestamp: number;
}

export interface WatchProgress extends SavedItem {
  progress: number; // 0-100
  positionSecs?: number;
  watched?: boolean;
  season?: number;
  episode?: number;
}

export const STORAGE_CHANGED_EVENT = "streamvault-storage-changed";

export function getWatchUrl(item: Pick<WatchProgress, "id" | "type" | "season" | "episode">) {
  if (item.type === "movie") return `/watch/movie/${item.id}`;
  if (Number.isSafeInteger(item.season) && item.season! >= 0 &&
    Number.isSafeInteger(item.episode) && item.episode! > 0) {
    return `/watch/tv/${item.id}/${item.season}/${item.episode}`;
  }
  return `/tv/${item.id}`;
}

const mediaKey = (item: Pick<SavedItem, "id" | "type">) => `${item.type}:${item.id}`;

const getStorage = <T>(key: string): T[] => {
  try {
    const item = localStorage.getItem(key);
    const parsed = item ? JSON.parse(item) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const setStorage = <T>(key: string, data: T[]) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    if (typeof window !== "undefined") window.dispatchEvent(new Event(STORAGE_CHANGED_EVENT));
  } catch (e) {
    console.error("Error saving to localStorage", e);
  }
};

export const storage = {
  getFavorites: () => getStorage<SavedItem>("sv_favorites"),
  addFavorite: (item: Omit<SavedItem, "timestamp">) => {
    const faves = storage.getFavorites().filter(i => i.id !== item.id);
    faves.unshift({ ...item, timestamp: Date.now() });
    setStorage("sv_favorites", faves);
  },
  removeFavorite: (id: number) => {
    setStorage("sv_favorites", storage.getFavorites().filter(i => i.id !== id));
  },
  isFavorite: (id: number) => storage.getFavorites().some(i => i.id === id),

  getWatchlist: () => getStorage<SavedItem>("sv_watchlist"),
  addToWatchlist: (item: Omit<SavedItem, "timestamp">) => {
    const list = storage.getWatchlist().filter(i => i.id !== item.id);
    list.unshift({ ...item, timestamp: Date.now() });
    setStorage("sv_watchlist", list);
  },
  removeFromWatchlist: (id: number) => {
    setStorage("sv_watchlist", storage.getWatchlist().filter(i => i.id !== id));
  },
  isInWatchlist: (id: number) => storage.getWatchlist().some(i => i.id === id),

  // Keep the original history key and all existing episode records.
  getViewingHistory: () => getStorage<WatchProgress>("sv_continue_watching")
    .filter(i => i && Number.isSafeInteger(i.id) && i.id > 0 &&
      (i.type === "movie" || i.type === "tv") && typeof i.title === "string")
    .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0)),
  getContinueWatching: () => {
    const hidden = new Set(getStorage<string>("sv_continue_hidden"));
    const seen = new Set<string>();
    return storage.getViewingHistory().filter(item => {
      const key = mediaKey(item);
      // Latest episode wins, even if it is completed or dismissed.
      if (seen.has(key)) return false;
      seen.add(key);
      return !hidden.has(key) && !item.watched && !(item.progress >= 90);
    });
  },
  hideFromContinueWatching: (id: number, type: MediaType) => {
    const hidden = new Set(getStorage<string>("sv_continue_hidden"));
    hidden.add(mediaKey({ id, type }));
    setStorage("sv_continue_hidden", [...hidden]);
  },
  recordOpened: (item: Omit<SavedItem, "timestamp"> & { season?: number; episode?: number }) => {
    const existing = storage.getProgress(item.id, item.type, item.season, item.episode);
    // An opened iframe is not evidence of elapsed playback or completion.
    storage.saveProgress({ ...existing, ...item, progress: existing?.progress ?? 0 });
  },
  saveProgress: (item: Omit<WatchProgress, "timestamp">) => {
    const progress = storage.getViewingHistory().filter(i =>
      i.id !== item.id ||
      i.type !== item.type ||
      (item.type === "tv" && (i.season !== item.season || i.episode !== item.episode))
    );
    progress.unshift({ ...item, timestamp: Date.now() });
    setStorage("sv_continue_watching", progress.slice(0, 50));
    setStorage("sv_continue_hidden", getStorage<string>("sv_continue_hidden").filter(key => key !== mediaKey(item)));
  },
  getProgress: (id: number, type: MediaType, season?: number, episode?: number) => {
    return storage.getViewingHistory().find(i =>
      i.id === id &&
      i.type === type &&
      (type !== "tv" || (i.season === season && i.episode === episode))
    );
  },
  markWatched: (id: number, type: MediaType, season?: number, episode?: number) => {
    const existing = storage.getProgress(id, type, season, episode);
    storage.saveProgress({
      id,
      type,
      title: existing?.title ?? "",
      poster_path: existing?.poster_path ?? null,
      progress: 100,
      positionSecs: existing?.positionSecs,
      watched: true,
      season,
      episode,
    });
  },
  removeProgress: (id: number, type?: MediaType, season?: number, episode?: number) => {
    setStorage("sv_continue_watching", storage.getViewingHistory().filter(i => {
      if (i.id !== id) return true;
      if (type && i.type !== type) return true;
      if (type === "tv" && (season !== undefined || episode !== undefined)) {
        return i.season !== season || i.episode !== episode;
      }
      return false;
    }));
  },
};
