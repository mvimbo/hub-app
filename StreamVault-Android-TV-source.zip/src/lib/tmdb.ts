import { cartoonSeries, cartoonMovies, validateCartoon } from "./cartoons";
import { replaceRequestedDocumentaries } from "./documentary-replacements.mjs";

export const TMDB_API_KEY = import.meta.env.VITE_TMDB_API_KEY || "";
export const TMDB_BASE_URL = "https://api.themoviedb.org/3";
export const IMAGE_BASE_URL = "https://image.tmdb.org/t/p";

export const getImageUrl = (path: string | null, size: "w500" | "original" | "w1280" = "w500") => {
  if (!path) return null;
  return `${IMAGE_BASE_URL}/${size}${path}`;
};

const fetchRawTMDB = async (endpoint: string, params: Record<string, string> = {}) => {
  if (!TMDB_API_KEY) {
    throw new Error("Movie and TV metadata is not configured. Set VITE_TMDB_API_KEY before building this app.");
  }
  const url = new URL(`${TMDB_BASE_URL}${endpoint}`);
  url.searchParams.append("api_key", TMDB_API_KEY);
  
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.append(key, value);
  });

  const res = await fetch(url.toString());
  if (!res.ok) {
    throw new Error(`TMDB API Error: ${res.statusText}`);
  }
  return res.json();
};

const replacementPools = new Map<string, Promise<any[]>>();

function getReplacementDocumentaries(type: string) {
  let pool = replacementPools.get(type);
  if (!pool) {
    pool = fetchRawTMDB(`/discover/${type}`, {
      with_genres: "99",
      sort_by: "vote_average.desc",
      "vote_count.gte": type === "tv" ? "50" : "500",
      page: "1",
    }).then((data) => data.results ?? []).catch((error) => {
      replacementPools.delete(type);
      throw error;
    });
    replacementPools.set(type, pool);
  }
  return pool;
}

const fetchTMDB = async (endpoint: string, params: Record<string, string> = {}) => {
  const data = await fetchRawTMDB(endpoint, params);
  const fallbackType = /\/tv(?:\/|$)/.test(endpoint) ? "tv" : "movie";
  if (Array.isArray(data.results)) {
    data.results = await replaceRequestedDocumentaries(data.results, getReplacementDocumentaries, fallbackType);
  }
  // Recommendations are discovery cards too; the requested title's own detail
  // record and all saved watchlist/history data remain unchanged.
  for (const collection of ["recommendations", "similar"]) {
    if (Array.isArray(data[collection]?.results)) {
      data[collection].results = await replaceRequestedDocumentaries(
        data[collection].results, getReplacementDocumentaries, fallbackType,
      );
    }
  }
  return data;
};

export const tmdb = {
  getTrending: (mediaType: "all" | "movie" | "tv" = "all", timeWindow: "day" | "week" = "week") => 
    fetchTMDB(`/trending/${mediaType}/${timeWindow}`),
  getPopularMovies: () => fetchTMDB("/movie/popular"),
  getTopRatedMovies: () => fetchTMDB("/movie/top_rated"),
  getNowPlayingMovies: () => fetchTMDB("/movie/now_playing"),
  getMoviesByGenre: (genreId: string, sortBy: "popularity.desc" | "vote_average.desc" = "popularity.desc") =>
    fetchTMDB("/discover/movie", {
      with_genres: genreId,
      sort_by: sortBy,
      "vote_count.gte": sortBy === "vote_average.desc" ? "50" : "10",
    }),
  getPopularTV: () => fetchTMDB("/tv/popular"),
  getTopRatedTV: () => fetchTMDB("/tv/top_rated"),
  getTVByGenre: (genreId: string, sortBy: "popularity.desc" | "vote_average.desc" | "first_air_date.desc" = "popularity.desc") =>
    fetchTMDB("/discover/tv", {
      with_genres: genreId,
      sort_by: sortBy,
      "vote_count.gte": sortBy === "vote_average.desc" ? "50" : "10",
    }),
  getCartoonTV: async () => ({
    results: await Promise.all(cartoonSeries.map(async (entry) =>
      validateCartoon(await fetchTMDB(`/tv/${entry.id}`), entry))),
  }),
  getCartoonMovies: async () => ({
    results: await Promise.all(cartoonMovies.map(async (entry) =>
      validateCartoon(await fetchTMDB(`/movie/${entry.id}`), entry))),
  }),
  getKoreanTV: (sortBy: "popularity.desc" | "vote_average.desc" | "first_air_date.desc" = "popularity.desc") =>
    fetchTMDB("/discover/tv", {
      with_original_language: "ko",
      watch_region: "KR",
      sort_by: sortBy,
      "vote_count.gte": sortBy === "vote_average.desc" ? "50" : "0",
    }),
  getKoreanMovies: (sortBy: "popularity.desc" | "vote_average.desc" = "popularity.desc") =>
    fetchTMDB("/discover/movie", {
      with_original_language: "ko",
      watch_region: "KR",
      sort_by: sortBy,
      "vote_count.gte": sortBy === "vote_average.desc" ? "50" : "0",
    }),
  getKoreanTVByGenre: (genreId: string) =>
    fetchTMDB("/discover/tv", {
      with_original_language: "ko",
      with_genres: genreId,
      watch_region: "KR",
      sort_by: "popularity.desc",
      "vote_count.gte": "10",
    }),
  getKoreanMoviesByGenre: (genreId: string) =>
    fetchTMDB("/discover/movie", {
      with_original_language: "ko",
      with_genres: genreId,
      watch_region: "KR",
      sort_by: "popularity.desc",
      "vote_count.gte": "10",
    }),
  getKoreanSearch: async (query: string, mediaType: "all" | "movie" | "tv" = "all", includeEpisodeCounts = false) => {
    const endpoints = mediaType === "all" ? ["/search/multi"] : [`/search/${mediaType}`];
    const responses = await Promise.all(
      endpoints.map((endpoint) => fetchTMDB(endpoint, { query, page: "1" }))
    );
    let results = responses.flatMap((response) => response.results ?? [])
      .filter((item: any) => item.media_type === "movie" || item.media_type === "tv" || mediaType !== "all")
      .filter((item: any) => item.original_language === "ko")
      .slice(0, 20);

    if (includeEpisodeCounts) {
      results = await Promise.all(results.map(async (item: any) => {
        if ((item.media_type || mediaType) !== "tv") return item;
        try {
          const details = await fetchTMDB(`/tv/${item.id}`);
          return {
            ...item,
            number_of_episodes: details.number_of_episodes,
            episode_run_time: details.episode_run_time,
          };
        } catch {
          return item;
        }
      }));
    }

    return { results };
  },
  getDocumentaries: (mediaType: "movie" | "tv", sortBy: "popularity.desc" | "vote_average.desc" | "primary_release_date.desc" = "popularity.desc") =>
    fetchTMDB(`/discover/${mediaType}`, {
      with_genres: "99",
      sort_by: sortBy,
      ...(mediaType === "movie" ? { "vote_count.gte": sortBy === "vote_average.desc" ? "50" : "10" } : { "vote_count.gte": sortBy === "vote_average.desc" ? "20" : "5" }),
    }),
  getDocumentaryTopic: async (topic: string) => {
    const [movies, series] = await Promise.all([
      fetchTMDB("/search/movie", { query: `${topic} documentary`, page: "1" }),
      fetchTMDB("/search/tv", { query: `${topic} documentary`, page: "1" }),
    ]);
    return {
      results: [...(movies.results ?? []), ...(series.results ?? [])]
        .filter((item: any) => item.genre_ids?.includes(99))
        .sort((a: any, b: any) => (b.popularity ?? 0) - (a.popularity ?? 0))
        .slice(0, 20),
    };
  },
  getDocumentarySearch: async (query: string, mediaType: "all" | "movie" | "tv" = "all") => {
    const endpoints = mediaType === "all" ? ["/search/movie", "/search/tv"] : [`/search/${mediaType}`];
    const responses = await Promise.all(endpoints.map(async (endpoint) => ({
      type: endpoint.includes("/tv") ? "tv" : "movie",
      data: await fetchTMDB(endpoint, { query, page: "1" }),
    })));
    return {
      results: responses.flatMap(({ type, data }) => (data.results ?? []).map((item: any) => ({ ...item, media_type: type })))
        .filter((item: any) => item.genre_ids?.includes(99))
        .sort((a: any, b: any) => (b.popularity ?? 0) - (a.popularity ?? 0))
        .slice(0, 30),
    };
  },
  getMovieDetails: (id: string | number) => fetchTMDB(`/movie/${id}`, { append_to_response: "videos,credits,similar,recommendations" }),
  getTVDetails: (id: string | number) => fetchTMDB(`/tv/${id}`, { append_to_response: "videos,credits,similar,recommendations" }),
  searchMulti: (query: string, page: number = 1) => fetchTMDB("/search/multi", { query, page: page.toString() }),
  getSeasonDetails: (id: string | number, season: string | number) =>
    fetchTMDB(`/tv/${id}/season/${season}`),
};
