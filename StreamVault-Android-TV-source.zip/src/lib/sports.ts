const API_BASE = "https://www.thesportsdb.com/api/v1/json/123";
const SCOREBOARD_BASE = "https://site.api.espn.com/apis/site/v2/sports";
const scoreboardPaths: Record<string, string> = {
  "4328": "soccer/eng.1",
  "4387": "basketball/nba",
  "4391": "football/nfl",
  "4424": "baseball/mlb",
  "4380": "hockey/nhl",
};

export interface SportsLeague {
  id: string;
  name: string;
  sport: string;
  officialScoresUrl: string;
  officialStandingsUrl: string;
  officialVideosUrl: string;
}

export interface SportsEvent {
  id: string;
  name: string;
  date: string;
  time: string | null;
  status: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number | null;
  awayScore: number | null;
  homeBadge: string | null;
  awayBadge: string | null;
  venue: string | null;
  videoUrl: string | null;
  videoId: string | null;
  thumbnail?: string | null;
  videoTitle?: string | null;
  coverageUrl?: string | null;
  startTime?: string;
  videoLookupFailed?: boolean;
}

interface TheSportsDbLeagueResponse {
  leagues?: Array<{ strCurrentSeason?: string | null }> | null;
}

interface ScoreboardCompetitor {
  homeAway?: string;
  score?: string;
  team?: { displayName?: string; logo?: string };
}

interface ScoreboardClip {
  headline?: string;
  thumbnail?: string;
  links?: { web?: { href?: string } };
}

interface ScoreboardEvent {
  id: string;
  name?: string;
  date: string;
  status?: { type?: { state?: string; completed?: boolean; detail?: string; description?: string } };
  links?: Array<{ rel?: string[]; href?: string }>;
  competitions?: Array<{
    competitors?: ScoreboardCompetitor[];
    venue?: { fullName?: string };
    status?: ScoreboardEvent["status"];
    highlights?: ScoreboardClip[];
  }>;
}

interface ScoreboardResponse {
  events?: ScoreboardEvent[];
}

export class SportsDataError extends Error {
  constructor(message: string, public readonly status?: number) {
    super(message);
    this.name = "SportsDataError";
  }
}

export function localSportsDate(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function millisecondsUntilSportsMidnight(date: Date) {
  const midnight = new Date(date);
  midnight.setHours(24, 0, 0, 0);
  return Math.max(1, midnight.getTime() - date.getTime());
}

export const SPORTS_REPLAY_LOOKBACK_DAYS = 14;

interface TheSportsDbStanding {
  idStanding?: string | null;
  strTeam?: string | null;
  strBadge?: string | null;
  intRank?: string | number | null;
  intPlayed?: string | number | null;
  intWin?: string | number | null;
  intDraw?: string | number | null;
  intLoss?: string | number | null;
  intGoalsFor?: string | number | null;
  intGoalsAgainst?: string | number | null;
  intGoalDifference?: string | number | null;
  intPoints?: string | number | null;
}

interface TheSportsDbTableResponse {
  table?: TheSportsDbStanding[] | null;
}

export interface SportsStanding {
  id: string;
  rank: number | null;
  team: string;
  badge: string | null;
  played: number | null;
  wins: number | null;
  draws: number | null;
  losses: number | null;
  goalsFor: number | null;
  goalsAgainst: number | null;
  goalDifference: number | null;
  points: number | null;
}

export const sportsLeagues: SportsLeague[] = [
  {
    id: "4328",
    name: "Premier League",
    sport: "Soccer",
    officialScoresUrl: "https://www.premierleague.com/en/matches",
    officialStandingsUrl: "https://www.premierleague.com/en/tables",
    officialVideosUrl: "https://www.premierleague.com/en/video/all",
  },
  {
    id: "4387",
    name: "NBA",
    sport: "Basketball",
    officialScoresUrl: "https://www.nba.com/scores",
    officialStandingsUrl: "https://www.nba.com/standings",
    officialVideosUrl: "https://www.nba.com/video",
  },
  {
    id: "4391",
    name: "NFL",
    sport: "American football",
    officialScoresUrl: "https://www.nfl.com/scores/",
    officialStandingsUrl: "https://www.nfl.com/standings/",
    officialVideosUrl: "https://www.nfl.com/videos/",
  },
  {
    id: "4424",
    name: "MLB",
    sport: "Baseball",
    officialScoresUrl: "https://www.mlb.com/scores",
    officialStandingsUrl: "https://www.mlb.com/standings",
    officialVideosUrl: "https://www.mlb.com/video",
  },
  {
    id: "4380",
    name: "NHL",
    sport: "Ice hockey",
    officialScoresUrl: "https://www.nhl.com/scores",
    officialStandingsUrl: "https://www.nhl.com/standings",
    officialVideosUrl: "https://www.nhl.com/video",
  },
];

function getSafeHttpUrl(value: string | null | undefined) {
  if (!value) return null;

  try {
    const url = new URL(value);
    return url.protocol === "https:" ? url.toString() : null;
  } catch {
    return null;
  }
}

function getYouTubeVideoId(value: string | null | undefined) {
  if (!value) return null;

  try {
    const url = new URL(value);
    if (url.protocol !== "https:") return null;
    if (url.hostname === "youtu.be") return url.pathname.slice(1) || null;
    if (url.hostname === "www.youtube.com" || url.hostname === "youtube.com") {
      return url.pathname === "/watch" ? url.searchParams.get("v") : null;
    }
  } catch {
    return null;
  }

  return null;
}

function parseScore(value: string | number | null | undefined) {
  if (value === null || value === undefined || value === "") return null;
  const score = Number(value);
  return Number.isFinite(score) ? score : null;
}

async function fetchSportsJson<T>(url: string, signal?: AbortSignal): Promise<T> {
  const controller = new AbortController();
  const abort = () => controller.abort(signal?.reason);
  if (signal?.aborted) abort();
  else signal?.addEventListener("abort", abort, { once: true });
  const timeout = setTimeout(() => controller.abort(), 15_000);
  try {
    const response = await fetch(url, { signal: controller.signal, cache: "no-store" });
    if (!response.ok) {
      throw new SportsDataError(`Sports data is temporarily unavailable (HTTP ${response.status}).`, response.status);
    }
    try {
      return await response.json() as T;
    } catch {
      if (controller.signal.aborted) throw new SportsDataError("Sports data took too long to respond. Updates will retry automatically.");
      throw new SportsDataError("The sports data provider returned an unreadable response.");
    }
  } catch (error) {
    if (signal?.aborted) throw error;
    if (error instanceof SportsDataError) throw error;
    if (controller.signal.aborted) throw new SportsDataError("Sports data took too long to respond. Updates will retry automatically.");
    throw new SportsDataError("Sports data could not be reached. Check your connection and try again.");
  } finally {
    clearTimeout(timeout);
    signal?.removeEventListener("abort", abort);
  }
}

function getOfficialVideoUrl(value: string | undefined) {
  const safe = getSafeHttpUrl(value);
  if (!safe) return null;
  const host = new URL(safe).hostname;
  return host === "www.espn.com" || host === "espn.com" || getYouTubeVideoId(safe) ? safe : null;
}

function getBestOfficialClip(clips: ScoreboardClip[]) {
  const available = clips.filter((clip) => getOfficialVideoUrl(clip.links?.web?.href));
  return available.find((clip) => /game highlights|match highlights/i.test(clip.headline ?? "")) ?? available[0];
}

async function fetchScoreboardDay(path: string, date: Date, signal?: AbortSignal) {
  const params = new URLSearchParams({ dates: localSportsDate(date).replaceAll("-", ""), limit: "1000" });
  const payload = await fetchSportsJson<ScoreboardResponse>(`${SCOREBOARD_BASE}/${path}/scoreboard?${params}`, signal);
  if (!Array.isArray(payload?.events)) throw new SportsDataError("The scoreboard provider returned an unexpected response.");
  return payload.events;
}

function mapScoreboardEvent(event: ScoreboardEvent): SportsEvent | null {
  const kickoff = new Date(event.date);
  const competition = event.competitions?.[0];
  const home = competition?.competitors?.find((team) => team.homeAway === "home");
  const away = competition?.competitors?.find((team) => team.homeAway === "away");
  if (!event.id || !home || !away || Number.isNaN(kickoff.getTime())) return null;
  const status = competition?.status?.type ?? event.status?.type;
  const detail = status?.detail || status?.description;
  const clip = getBestOfficialClip(competition?.highlights ?? []);
  const videoUrl = getOfficialVideoUrl(clip?.links?.web?.href);
  const coverageLink = event.links?.find((link) => link.rel?.includes("highlights"))
    ?? event.links?.find((link) => link.rel?.includes("summary"));

  return {
    id: event.id,
    name: event.name || "Match",
    date: localSportsDate(kickoff),
    time: `${String(kickoff.getHours()).padStart(2, "0")}:${String(kickoff.getMinutes()).padStart(2, "0")}:00`,
    status: status?.state === "in"
      ? `Live · ${detail || "In progress"}`
      : status?.state === "pre"
        ? status.description || "Scheduled"
        : detail || (status?.state === "post" ? "Final" : "Scheduled"),
    homeTeam: home.team?.displayName || "Home team",
    awayTeam: away.team?.displayName || "Away team",
    homeScore: status?.state === "pre" ? null : parseScore(home.score),
    awayScore: status?.state === "pre" ? null : parseScore(away.score),
    homeBadge: getSafeHttpUrl(home.team?.logo),
    awayBadge: getSafeHttpUrl(away.team?.logo),
    venue: competition?.venue?.fullName || null,
    videoUrl,
    videoId: getYouTubeVideoId(videoUrl),
    thumbnail: getSafeHttpUrl(clip?.thumbnail),
    videoTitle: clip?.headline ?? null,
    coverageUrl: getOfficialVideoUrl(coverageLink?.href),
    startTime: kickoff.toISOString(),
  };
}

export async function getSportsEventsForDate(leagueId: string, date: string, signal?: AbortSignal) {
  const path = scoreboardPaths[leagueId];
  if (!path) throw new SportsDataError("This league does not have a configured scoreboard.");
  const day = new Date(`${date}T12:00:00`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(day.getTime()) || localSportsDate(day) !== date) {
    throw new SportsDataError("Choose a valid fixture date.");
  }

  // League calendars and the viewer's timezone can differ. Request adjacent
  // provider days, then filter actual kickoff timestamps to the viewer's date.
  const payloads = await Promise.all([-1, 0, 1].map(async (offset) => {
    const providerDay = new Date(day);
    providerDay.setDate(providerDay.getDate() + offset);
    return fetchScoreboardDay(path, providerDay, signal);
  }));
  const events = new Map<string, SportsEvent>();
  for (const event of payloads.flat()) {
    const kickoff = new Date(event.date);
    if (Number.isNaN(kickoff.getTime()) || localSportsDate(kickoff) !== date) continue;
    const mapped = mapScoreboardEvent(event);
    if (mapped) events.set(mapped.id, mapped);
  }
  return [...events.values()].sort((a, b) => (a.time ?? "").localeCompare(b.time ?? ""));
}

async function getSportsCurrentSeason(leagueId: string, signal?: AbortSignal) {
  const leaguePayload = await fetchSportsJson<TheSportsDbLeagueResponse>(
    `${API_BASE}/lookupleague.php?id=${encodeURIComponent(leagueId)}`,
    signal,
  );
  const season = leaguePayload.leagues?.[0]?.strCurrentSeason;

  if (!season) {
    return null;
  }

  return season;
}

export async function getSportsRecentEvents(leagueId: string, signal?: AbortSignal, now = new Date()) {
  const path = scoreboardPaths[leagueId];
  if (!path) throw new SportsDataError("This league does not have a configured scoreboard.");
  const cutoff = new Date(now);
  cutoff.setHours(0, 0, 0, 0);
  cutoff.setDate(cutoff.getDate() - SPORTS_REPLAY_LOOKBACK_DAYS + 1);
  const events = new Map<string, SportsEvent>();

  // Walk backward in bounded batches, including adjacent provider calendar days
  // for timezone differences. Stop once we have the eight newest final games.
  for (let offset = -1; offset <= SPORTS_REPLAY_LOOKBACK_DAYS && events.size < 8; offset += 4) {
    const dates = Array.from({ length: Math.min(4, SPORTS_REPLAY_LOOKBACK_DAYS - offset + 1) }, (_, index) => {
      const day = new Date(now);
      day.setDate(day.getDate() - offset - index);
      return day;
    });
    const batches = await Promise.all(dates.map((date) => fetchScoreboardDay(path, date, signal)));
    for (const event of batches.flat()) {
      const status = event.competitions?.[0]?.status?.type ?? event.status?.type;
      const kickoff = new Date(event.date);
      if (status?.state !== "post" || status.completed === false || /cancel|postpon|abandon|suspend/i.test(`${status.description ?? ""} ${status.detail ?? ""}`) || kickoff < cutoff || kickoff > now) continue;
      const mapped = mapScoreboardEvent(event);
      if (mapped) events.set(mapped.id, mapped);
    }
  }
  const recent = [...events.values()]
    .sort((a, b) => (b.startTime ?? "").localeCompare(a.startTime ?? ""))
    .slice(0, 8);
  // Some leagues only publish clips on the game summary, not the scoreboard.
  // A video lookup failure must not discard that game's confirmed final result.
  const withoutClips = recent.filter((game) => !game.videoUrl);
  for (let index = 0; index < withoutClips.length; index += 4) {
    await Promise.all(withoutClips.slice(index, index + 4).map(async (game) => {
      try {
        const payload = await fetchSportsJson<{ videos?: ScoreboardClip[] | null }>(
          `${SCOREBOARD_BASE}/${path}/summary?event=${encodeURIComponent(game.id)}`, signal,
        );
        if (!Array.isArray(payload.videos ?? [])) throw new SportsDataError("Unexpected game video details.");
        const clip = getBestOfficialClip(payload.videos ?? []);
        if (clip) {
          game.videoUrl = getOfficialVideoUrl(clip.links?.web?.href);
          game.videoId = getYouTubeVideoId(game.videoUrl);
          game.thumbnail = getSafeHttpUrl(clip.thumbnail);
          game.videoTitle = clip.headline ?? null;
        }
      } catch (error) {
        if (signal?.aborted) throw error;
        game.videoLookupFailed = true;
      }
    }));
  }
  return recent;
}

export async function getSportsStandings(leagueId: string, signal?: AbortSignal) {
  const season = await getSportsCurrentSeason(leagueId, signal);
  if (!season) throw new SportsDataError("The sports data provider did not return a current season for this league.");

  const params = new URLSearchParams({ l: leagueId, s: season });
  const payload = await fetchSportsJson<TheSportsDbTableResponse>(`${API_BASE}/lookuptable.php?${params.toString()}`, signal);
  if (!payload || !("table" in payload) || (payload.table !== null && !Array.isArray(payload.table))) {
    throw new SportsDataError("The sports data provider returned unexpected league standings.");
  }

  return (payload.table ?? [])
    .map((row, index): SportsStanding => ({
      id: row.idStanding || `${leagueId}-${index}`,
      rank: parseScore(row.intRank),
      team: row.strTeam?.trim() || "Team",
      badge: getSafeHttpUrl(row.strBadge),
      played: parseScore(row.intPlayed),
      wins: parseScore(row.intWin),
      draws: parseScore(row.intDraw),
      losses: parseScore(row.intLoss),
      goalsFor: parseScore(row.intGoalsFor),
      goalsAgainst: parseScore(row.intGoalsAgainst),
      goalDifference: parseScore(row.intGoalDifference),
      points: parseScore(row.intPoints),
    }))
    .sort((a, b) => (a.rank ?? Number.MAX_SAFE_INTEGER) - (b.rank ?? Number.MAX_SAFE_INTEGER));
}