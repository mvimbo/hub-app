export interface AniListMetadata {
  id: number;
  title: {
    romaji: string | null;
    english: string | null;
    native: string | null;
  };
  description: string | null;
  episodes: number | null;
  duration: number | null;
  status: string;
  season: string | null;
  seasonYear: number | null;
  averageScore: number | null;
  genres: string[];
  studios: {
    nodes: Array<{ name: string }>;
  };
  siteUrl: string;
}

const ANILIST_URL = "https://graphql.anilist.co";

const MEDIA_QUERY = `
  query AnimeMetadata($search: String!) {
    Media(search: $search, type: ANIME) {
      id
      title { romaji english native }
      description(asHtml: false)
      episodes
      duration
      status
      season
      seasonYear
      averageScore
      genres
      studios(isMain: true) { nodes { name } }
      siteUrl
    }
  }
`;

export async function getAniListMetadata(search: string): Promise<AniListMetadata | null> {
  if (!search.trim()) return null;

  const response = await fetch(ANILIST_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query: MEDIA_QUERY, variables: { search } }),
  });

  if (!response.ok) {
    throw new Error(`AniList API Error: ${response.statusText}`);
  }

  const payload = await response.json();
  return payload.data?.Media ?? null;
}

export function getAniListDisplayTitle(metadata: AniListMetadata) {
  return metadata.title.english || metadata.title.romaji || metadata.title.native || "Anime";
}

export function formatAniListStatus(status: string) {
  return status
    .toLowerCase()
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}