export interface DocumentaryCard {
  id: number;
  title?: string;
  name?: string;
  media_type?: string;
  genre_ids?: number[];
  genres?: { id: number }[];
  poster_path?: string | null;
  [key: string]: any;
}
export function isRequestedDocumentary(item: DocumentaryCard): boolean;
export function replaceRequestedDocumentaries(
  items: DocumentaryCard[],
  loadCandidates: (type: string) => Promise<DocumentaryCard[]>,
  fallbackType?: string,
): Promise<DocumentaryCard[]>;
