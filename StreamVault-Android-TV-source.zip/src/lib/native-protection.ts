import { Capacitor, registerPlugin } from "@capacitor/core";

export interface ProtectionStatus {
  available: boolean;
  enabled: boolean;
  blockedRequests: number;
  popupBlocking: boolean;
  ruleCount: number;
  reason?: string;
}

interface RequestGuardPlugin {
  getStatus(): Promise<ProtectionStatus>;
  setEnabled(options: { enabled: boolean }): Promise<ProtectionStatus>;
}

const RequestGuard = registerPlugin<RequestGuardPlugin>("RequestGuard");
export const isAndroidApp = () => Capacitor.getPlatform() === "android";

export async function getProtectionStatus(): Promise<ProtectionStatus> {
  if (!isAndroidApp()) return {
    available: false, enabled: false, blockedRequests: 0,
    popupBlocking: false, ruleCount: 24,
    reason: "Native request protection is available in the installed Android app, not this browser preview.",
  };
  return RequestGuard.getStatus();
}

export async function setProtectionEnabled(enabled: boolean): Promise<ProtectionStatus> {
  if (!isAndroidApp()) throw new Error("Install the Android app to change request protection.");
  return RequestGuard.setEnabled({ enabled });
}
