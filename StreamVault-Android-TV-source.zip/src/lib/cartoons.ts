// Selected children's series and family animated films, not the unrestricted animation genre.
// IDs stay as TMDB IDs so details, watchlist, history and playback retain their existing contracts.
export const cartoonSeries = [
  { id: 82728, title: "Bluey" },
  { id: 57532, title: "PAW Patrol" },
  { id: 12225, title: "Peppa Pig" },
  { id: 387, title: "SpongeBob SquarePants" },
  { id: 1877, title: "Phineas and Ferb" },
  { id: 65417, title: "PJ Masks" },
  { id: 3934, title: "Mickey Mouse Clubhouse" },
  { id: 3902, title: "Shaun the Sheep" },
] as const;
export const cartoonMovies = [
  { id: 862, title: "Toy Story" },
  { id: 12, title: "Finding Nemo" },
  { id: 10681, title: "WALL·E" },
  { id: 585, title: "Monsters, Inc." },
  { id: 109445, title: "Frozen" },
  { id: 269149, title: "Zootopia" },
  { id: 508947, title: "Turning Red" },
  { id: 568124, title: "Encanto" },
] as const;

export function validateCartoon(item: any, expected: { id: number; title: string }) {
  if (item.id !== expected.id || (item.name || item.title) !== expected.title ||
    item.adult === true || !item.genres?.some((genre: { id: number }) => genre.id === 16)) {
    throw new Error(`Unexpected catalog data for ${expected.title}`);
  }
  return item;
}
