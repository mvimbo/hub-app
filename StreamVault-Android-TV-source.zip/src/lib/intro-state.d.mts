export type IntroState = "loading" | "playing" | "blocked" | "error" | "done";
export type IntroEvent = "playing" | "autoplay-blocked" | "error" | "retry" | "start" | "ended" | string;
export const INITIAL_INTRO: IntroState;
export function introReducer(state: IntroState, event: IntroEvent): IntroState;
export function catalogUnlocked(state: IntroState): boolean;
