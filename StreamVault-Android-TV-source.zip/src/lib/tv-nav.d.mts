export type Direction = "up" | "down" | "left" | "right";
export interface Box { left: number; top: number; width: number; height: number }
export const DIRECTION_KEYS: Record<string, Direction>;
export function pickNext(current: Box, candidates: Box[], direction: Direction): number;
export function keepsArrowKey(tag: string, type: string | null | undefined, direction: Direction, selStart: number | null, selEnd: number | null, valueLength: number): boolean;
