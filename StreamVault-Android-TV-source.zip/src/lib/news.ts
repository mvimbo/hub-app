export type NewsCategory = "East Africa" | "Africa" | "Global" | "Business";

export interface NewsChannel {
  id: string;
  name: string;
  shortName: string;
  category: NewsCategory;
  location: string;
  language: string;
  description: string;
  officialUrl: string;
  embedUrl: string;
  embedProvider: "Broadcaster" | "YouTube";
  sourceNote: string;
}

export const newsCategories = ["All", "East Africa", "Africa", "Global", "Business"] as const;
export type NewsFilter = typeof newsCategories[number];

export const newsChannels: NewsChannel[] = [
  {
    id: "ntv-uganda", name: "NTV Uganda", shortName: "NTV", category: "East Africa",
    location: "Uganda", language: "English / Luganda",
    description: "National news, interviews and current affairs.",
    officialUrl: "https://ntv.co.ug/live-tv",
    embedUrl: "https://ams-2629.antmedia.cloud/LiveApp/play.html?id=abul2026",
    embedProvider: "Broadcaster",
    sourceNote: "Player published on NTV Uganda’s official live-TV page.",
  },
  {
    id: "spark", name: "Spark TV", shortName: "SPARK", category: "East Africa",
    location: "Uganda", language: "English / Luganda",
    description: "Local news, community stories and lifestyle programmes.",
    officialUrl: "https://ntv.co.ug/spark-live-tv-2",
    embedUrl: "https://ams-2629.antmedia.cloud/LiveApp/play.html?id=spark2026",
    embedProvider: "Broadcaster",
    sourceNote: "Player published on Spark TV’s official Nation Media live-TV page.",
  },
  {
    id: "citizen-kenya", name: "Citizen TV", shortName: "CITIZEN", category: "East Africa",
    location: "Kenya", language: "English / Swahili",
    description: "Kenyan news, political coverage and current-affairs programmes.",
    officialUrl: "https://citizen.digital/tv/citizen-tv-live-15",
    embedUrl: "https://www.youtube-nocookie.com/embed/1Vm7lAjpZZM?rel=0",
    embedProvider: "YouTube",
    sourceNote: "Citizen TV Kenya’s official YouTube live broadcast.",
  },
  {
    id: "ntv-kenya", name: "NTV Kenya", shortName: "NTV KENYA", category: "East Africa",
    location: "Kenya", language: "English / Swahili",
    description: "Kenyan headlines, regional affairs and national news bulletins.",
    officialUrl: "https://ntvkenya.co.ke/live/",
    embedUrl: "https://www.youtube-nocookie.com/embed/u3DUxIoBHRA?rel=0",
    embedProvider: "YouTube",
    sourceNote: "YouTube player published on NTV Kenya’s official live page.",
  },
  {
    id: "al-jazeera", name: "Al Jazeera English", shortName: "AL JAZEERA", category: "Global",
    location: "Qatar", language: "English",
    description: "International news with Africa and Middle East coverage.",
    officialUrl: "https://www.aljazeera.com/video/live",
    embedUrl: "https://www.youtube.com/embed/gCNeDWCI0vo",
    embedProvider: "YouTube",
    sourceNote: "YouTube player published on Al Jazeera’s official live page.",
  },
  {
    id: "dw", name: "DW English", shortName: "DW", category: "Global",
    location: "Germany", language: "English",
    description: "European and international news and current affairs.",
    officialUrl: "https://www.dw.com/en/live-tv/channel-english",
    embedUrl: "https://www.youtube-nocookie.com/embed/LuKwFajn37U?rel=0", embedProvider: "YouTube",
    sourceNote: "DW News’ official YouTube live broadcast; full website framing is not used.",
  },
  {
    id: "france24", name: "France 24 English", shortName: "FRANCE 24", category: "Global",
    location: "France", language: "English",
    description: "International headlines and extensive Africa coverage.",
    officialUrl: "https://www.france24.com/en/live",
    embedUrl: "https://embed.france24.com/en/live",
    embedProvider: "Broadcaster",
    sourceNote: "France 24’s broadcaster-provided embed page.",
  },
  {
    id: "sky", name: "Sky News", shortName: "SKY NEWS", category: "Global",
    location: "United Kingdom", language: "English",
    description: "UK and international breaking news.",
    officialUrl: "https://news.sky.com/watch-live",
    embedUrl: "https://www.youtube-nocookie.com/embed/cMymRkxOx5k?rel=0", embedProvider: "YouTube",
    sourceNote: "Sky News’ current official YouTube live coverage. Live events and schedules can change.",
  },
  {
    id: "africanews", name: "Africanews", shortName: "AFRICANEWS", category: "Africa",
    location: "Pan-African", language: "English",
    description: "Pan-African news, business and international affairs.",
    officialUrl: "https://www.africanews.com/live/",
    embedUrl: "https://www.youtube-nocookie.com/embed/NQjabLGdP5g?rel=0", embedProvider: "YouTube",
    sourceNote: "Africanews’ official English YouTube live broadcast.",
  },
  {
    id: "channels-tv", name: "Channels Television", shortName: "CHANNELS", category: "Africa",
    location: "Nigeria", language: "English",
    description: "Nigerian headlines, politics and African current affairs.",
    officialUrl: "https://www.channelstv.com/live",
    embedUrl: "https://www.youtube-nocookie.com/embed/d4zDorDl5UE?rel=0",
    embedProvider: "YouTube",
    sourceNote: "Channels Television’s official YouTube live broadcast.",
  },
  {
    id: "news-central", name: "News Central TV", shortName: "NEWS CENTRAL", category: "Africa",
    location: "Nigeria / Pan-African", language: "English",
    description: "Pan-African news, analysis and current affairs.",
    officialUrl: "https://newscentraltv.com/",
    embedUrl: "https://www.youtube-nocookie.com/embed/uNUPuUTvyH8?rel=0",
    embedProvider: "YouTube",
    sourceNote: "News Central TV’s official YouTube live broadcast.",
  },
  {
    id: "cna", name: "CNA", shortName: "CNA", category: "Global",
    location: "Singapore", language: "English",
    description: "Singapore, Asia and international affairs.",
    officialUrl: "https://www.channelnewsasia.com/watch/cna-livestream-1590771",
    embedUrl: "https://www.youtube-nocookie.com/embed/XWq5kBlakcQ?rel=0", embedProvider: "YouTube",
    sourceNote: "CNA’s official 24-hour YouTube broadcast.",
  },
  {
    id: "euronews", name: "Euronews", shortName: "EURONEWS", category: "Global",
    location: "Europe", language: "English",
    description: "European affairs and international headlines.",
    officialUrl: "https://www.euronews.com/live",
    embedUrl: "https://www.youtube-nocookie.com/embed/pykpO5kQJ98?rel=0", embedProvider: "YouTube",
    sourceNote: "Euronews’ official English YouTube live broadcast.",
  },
  {
    id: "trt", name: "TRT World", shortName: "TRT WORLD", category: "Global",
    location: "Türkiye", language: "English",
    description: "International news and regional affairs.",
    officialUrl: "https://www.trtworld.com/",
    embedUrl: "https://www.youtube-nocookie.com/embed/qBe59l6p_EU?rel=0", embedProvider: "YouTube",
    sourceNote: "TRT World’s official YouTube live broadcast.",
  },
  {
    id: "nhk", name: "NHK World-Japan", shortName: "NHK WORLD", category: "Global",
    location: "Japan", language: "English",
    description: "Japan, Asia, news and English-language programmes.",
    officialUrl: "https://www3.nhk.or.jp/nhkworld/en/live/",
    embedUrl: "https://www.youtube-nocookie.com/embed/IimtbuqYIE8?rel=0", embedProvider: "YouTube",
    sourceNote: "NHK World-Japan’s official live news YouTube broadcast.",
  },
  {
    id: "abc", name: "ABC News Live", shortName: "ABC NEWS", category: "Global",
    location: "United States", language: "English",
    description: "US news, breaking events and international reporting.",
    officialUrl: "https://abcnews.com/live",
    embedUrl: "https://www.youtube-nocookie.com/embed/UNlabc4CzPE?rel=0", embedProvider: "YouTube",
    sourceNote: "ABC News’ current official YouTube live broadcast. The daily broadcast ID can change.",
  },
  {
    id: "cbs-news", name: "CBS News 24/7", shortName: "CBS NEWS", category: "Global",
    location: "United States", language: "English",
    description: "US headlines, international stories and breaking-news coverage.",
    officialUrl: "https://www.cbsnews.com/live/",
    embedUrl: "https://www.youtube-nocookie.com/embed/Q9GprU4Hi-Q?rel=0",
    embedProvider: "YouTube",
    sourceNote: "CBS News’ current official YouTube live broadcast; broadcast IDs can change.",
  },
  {
    id: "arirang", name: "Arirang TV", shortName: "ARIRANG", category: "Global",
    location: "South Korea", language: "English",
    description: "Korean and international news, culture and current affairs.",
    officialUrl: "https://arirang.com/live",
    embedUrl: "https://www.youtube-nocookie.com/embed/hvVlyZ5GiE8?rel=0",
    embedProvider: "YouTube",
    sourceNote: "Arirang TV’s official 24-hour YouTube broadcast.",
  },
  {
    id: "bloomberg", name: "Bloomberg Television", shortName: "BLOOMBERG", category: "Business",
    location: "United States / global", language: "English",
    description: "Markets, business and economic news worldwide.",
    officialUrl: "https://www.bloomberg.com/live/us-btv",
    embedUrl: "https://www.youtube-nocookie.com/embed/QB5BNdBFujE?rel=0", embedProvider: "YouTube",
    sourceNote: "Bloomberg Television’s official YouTube business news broadcast.",
  },
  {
    id: "cnbc-africa", name: "CNBC Africa", shortName: "CNBC AFRICA", category: "Business",
    location: "South Africa / Pan-African", language: "English",
    description: "African business, markets, investment and economic affairs.",
    officialUrl: "https://www.cnbcafrica.com/live",
    embedUrl: "https://www.youtube-nocookie.com/embed/93FyuZgOUMo?rel=0",
    embedProvider: "YouTube",
    sourceNote: "YouTube player published on CNBC Africa’s official live page.",
  },
  {
    id: "cnbc-tv18", name: "CNBC-TV18", shortName: "CNBC-TV18", category: "Business",
    location: "India", language: "English",
    description: "Indian financial markets, business headlines and economic news.",
    officialUrl: "https://www.cnbctv18.com/live-tv",
    embedUrl: "https://www.youtube-nocookie.com/embed/1_Ih0JYmkjI?rel=0",
    embedProvider: "YouTube",
    sourceNote: "CNBC-TV18’s official 24-hour business-news YouTube broadcast.",
  },
];

export function filterNewsChannels(category: NewsFilter, search: string) {
  const term = search.trim().toLocaleLowerCase();
  return newsChannels.filter((channel) =>
    (category === "All" || channel.category === category) &&
    `${channel.name} ${channel.location} ${channel.language} ${channel.description}`.toLocaleLowerCase().includes(term),
  );
}

export function getNewsChannel(id: string | null | undefined) {
  return newsChannels.find((channel) => channel.id === id) ?? newsChannels[0];
}
