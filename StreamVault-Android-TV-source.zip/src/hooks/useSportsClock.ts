import { useEffect, useState } from "react";
import { millisecondsUntilSportsMidnight } from "@/lib/sports";

// Keep freshness labels and "Today" correct after midnight, returning to the
// tab, and reconnecting. Query polling itself pauses in hidden/offline tabs.
export function useSportsClock() {
  const [now, setNow] = useState(Date.now);
  const [online, setOnline] = useState(() => navigator.onLine);

  useEffect(() => {
    let midnightTimer: number;
    const update = () => {
      setNow(Date.now());
      setOnline(navigator.onLine);
      window.clearTimeout(midnightTimer);
      midnightTimer = window.setTimeout(update, millisecondsUntilSportsMidnight(new Date()));
    };
    update();
    const interval = window.setInterval(update, 15_000);
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    window.addEventListener("focus", update);
    document.addEventListener("visibilitychange", update);
    return () => {
      window.clearInterval(interval);
      window.clearTimeout(midnightTimer);
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
      window.removeEventListener("focus", update);
      document.removeEventListener("visibilitychange", update);
    };
  }, []);

  return { now, online };
}
