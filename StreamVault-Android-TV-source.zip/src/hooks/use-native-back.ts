import { useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Capacitor, type PluginListenerHandle } from "@capacitor/core";
import { App as CapApp } from "@capacitor/app";

/** Android hardware back: route back, exit at root. Only active after intro. */
export function useNativeBack(enabled: boolean) {
  const [location] = useLocation();
  const locRef = useRef(location);
  locRef.current = location;
  useEffect(() => {
    if (!enabled || !Capacitor.isNativePlatform()) return;
    let handle: PluginListenerHandle | undefined;
    let disposed = false;
    CapApp.addListener("backButton", ({ canGoBack }) => {
      if (locRef.current !== "/" && (canGoBack || window.history.length > 1)) window.history.back();
      else void CapApp.exitApp();
    }).then((h) => { if (disposed) void h.remove(); else handle = h; }).catch(() => undefined);
    return () => { disposed = true; void handle?.remove(); };
  }, [enabled]);
}
