import { useEffect } from "react";
import { DIRECTION_KEYS, pickNext, keepsArrowKey, type Direction } from "@/lib/tv-nav.mjs";

const SELECTOR = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [role="button"], [role="switch"], [tabindex]:not([tabindex="-1"])';

function visible(el: HTMLElement) {
  if (el.closest("[aria-hidden='true'], [inert]")) return false;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return false;
  const s = getComputedStyle(el);
  return s.visibility !== "hidden" && s.display !== "none";
}

export function useTvNavigation(enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey) return;
      const active = document.activeElement as HTMLElement | null;
      if (active?.tagName === "IFRAME") return; // cross-origin player owns keys
      const dir = DIRECTION_KEYS[e.key] as Direction | undefined;
      if (!dir) {
        if ((e.key === "Enter") && active && active.getAttribute("role") === "button" && !/^(A|BUTTON|INPUT|TEXTAREA|SELECT)$/.test(active.tagName)) {
          e.preventDefault(); active.click();
        }
        return;
      }
      if (active && active !== document.body) {
        const inp = active as HTMLInputElement;
        let ss: number | null = null, se: number | null = null;
        try { ss = inp.selectionStart ?? null; se = inp.selectionEnd ?? null; } catch { /* unsupported type */ }
        if (keepsArrowKey(active.tagName, inp.type, dir, ss, se, inp.value?.length ?? 0)) return;
        if (active.closest('[role="menu"], [role="listbox"], [role="slider"], [role="tablist"], [role="radiogroup"]')) return;
      }
      const all = Array.from(document.querySelectorAll<HTMLElement>(SELECTOR)).filter((el) => el !== active && visible(el));
      if (!all.length) return;
      e.preventDefault();
      if (!active || active === document.body || !visible(active)) {
        all.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top || a.getBoundingClientRect().left - b.getBoundingClientRect().left);
        all[0].focus(); return;
      }
      const cur = active.getBoundingClientRect();
      const idx = pickNext(cur, all.map((el) => el.getBoundingClientRect()), dir);
      if (idx < 0) return;
      const next = all[idx];
      next.focus({ preventScroll: true });
      next.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [enabled]);
}
