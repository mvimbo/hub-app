import { useState, useEffect, useCallback } from "react";
import { storage, WatchProgress, STORAGE_CHANGED_EVENT } from "@/lib/storage";

export function useContinueWatching() {
  const [items, setItems] = useState<WatchProgress[]>(() => storage.getContinueWatching());

  const refresh = useCallback(() => {
    setItems(storage.getContinueWatching());
  }, []);

  useEffect(() => {
    // Re-read when the tab gains focus (user comes back from watch page)
    window.addEventListener("focus", refresh);
    // Browser storage events cover other tabs; our event covers this tab.
    window.addEventListener("storage", refresh);
    window.addEventListener(STORAGE_CHANGED_EVENT, refresh);
    return () => {
      window.removeEventListener("focus", refresh);
      window.removeEventListener("storage", refresh);
      window.removeEventListener(STORAGE_CHANGED_EVENT, refresh);
    };
  }, [refresh]);

  const remove = useCallback((id: number, type: "movie" | "tv") => {
    storage.hideFromContinueWatching(id, type);
    refresh();
  }, [refresh]);

  return { items, remove, refresh };
}
