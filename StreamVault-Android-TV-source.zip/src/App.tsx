import { Switch, Route, Redirect, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect, useState } from "react";
import { HelmetProvider } from "react-helmet-async";

// Pages
import Home from "@/pages/Home";
import Search from "@/pages/Search";
import MovieDetail from "@/pages/MovieDetail";
import TVDetail from "@/pages/TVDetail";
import WatchMovie from "@/pages/WatchMovie";
import WatchTV from "@/pages/WatchTV";
import Favorites from "@/pages/Favorites";
import Watchlist from "@/pages/Watchlist";
import HistoryPage from "@/pages/History";
import Cartoon from "@/pages/Cartoon";
import Korean from "@/pages/Korean";
import Documentaries from "@/pages/Documentaries";
import Sports from "@/pages/Sports";
import News from "@/pages/News";
import NotFound from "@/pages/not-found";
import Settings from "@/pages/Settings";
import LaunchIntro from "@/components/LaunchIntro";
import { useTvNavigation } from "@/hooks/use-tv-navigation";
import { useNativeBack } from "@/hooks/use-native-back";

import Navbar from "@/components/Navbar";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  useTvNavigation(true);
  useNativeBack(true);
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="flex-1">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/search" component={Search} />
          <Route path="/movie/:id" component={MovieDetail} />
          <Route path="/tv/:id" component={TVDetail} />
          <Route path="/watch/movie/:id" component={WatchMovie} />
          <Route path="/watch/tv/:id/:season/:episode" component={WatchTV} />
          <Route path="/favorites" component={Favorites} />
          <Route path="/watchlist" component={Watchlist} />
          <Route path="/history" component={HistoryPage} />
          <Route path="/cartoon" component={Cartoon} />
          <Route path="/anime"><Redirect to="/cartoon" /></Route>
          <Route path="/korean" component={Korean} />
          <Route path="/documentaries" component={Documentaries} />
          <Route path="/sports" component={Sports} />
          <Route path="/news" component={News} />
          <Route path="/settings" component={Settings} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  // Module state resets only on cold launch; route changes never re-show the intro.
  const [introDone, setIntroDone] = useState(false);
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            {introDone ? <Router /> : <LaunchIntro onFinished={() => setIntroDone(true)} />}
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </HelmetProvider>
  );
}

export default App;
