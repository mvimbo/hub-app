import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import { Clapperboard, Play, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { tmdb, getImageUrl } from "@/lib/tmdb";
import ContentRow from "@/components/ContentRow";
import { Button } from "@/components/ui/button";

function CartoonHero({ item }: { item: any }) {
  if (!item) return <div className="h-[52vh] min-h-[420px] bg-gradient-to-br from-indigo-950 via-background to-background" />;
  const title = item.name || item.title;
  const backdrop = getImageUrl(item.backdrop_path, "w1280");
  return (
    <div className="relative h-[52vh] min-h-[420px] w-full overflow-hidden">
      {backdrop && <img src={backdrop} alt="" className="h-full w-full object-cover" />}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/75 to-background/10" />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/40 to-transparent" />
      <div className="absolute inset-x-0 bottom-0">
        <div className="container mx-auto px-4 md:px-8 pb-12 md:pb-16">
          <div className="flex items-center gap-2 text-indigo-300 text-xs font-bold uppercase tracking-[0.2em] mb-4">
            <Sparkles className="w-4 h-4" /> Featured cartoon
          </div>
          <h1 className="max-w-2xl text-4xl md:text-6xl font-bold text-white tracking-tight">{title}</h1>
          <p className="mt-4 max-w-xl text-white/65 line-clamp-3 leading-relaxed">
            {item.overview || "Discover children’s cartoons and animated adventures for family viewing."}
          </p>
          <div className="mt-6 flex items-center gap-3">
            <Link href={`/watch/tv/${item.id}/1/1`}>
              <Button className="bg-primary hover:bg-primary/90 text-white font-bold gap-2">
                <Play className="w-4 h-4 fill-current" /> Watch now
              </Button>
            </Link>
            <Link href={`/tv/${item.id}`}>
              <Button variant="outline" className="border-white/20 bg-black/30 text-white hover:bg-white/10 gap-2">
                <Clapperboard className="w-4 h-4" /> View details
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Cartoon() {
  const series = useQuery({
    queryKey: ["cartoon", "tv"],
    queryFn: tmdb.getCartoonTV,
  });
  const movies = useQuery({
    queryKey: ["cartoon", "movies"],
    queryFn: tmdb.getCartoonMovies,
  });
  const seriesItems = (series.data?.results ?? []).map((item: any) => ({ ...item, media_type: "tv" }));
  const popularItems = [...seriesItems].sort((a, b) => b.popularity - a.popularity);
  const topRatedItems = [...seriesItems].sort((a, b) => b.vote_average - a.vote_average);
  const movieItems = (movies.data?.results ?? []).map((item: any) => ({ ...item, media_type: "movie" }));

  return (
    <div className="min-h-screen pb-20">
      <Helmet>
        <title>Cartoon — StreamVault</title>
        <meta name="description" content="Explore children’s cartoon series and family animated movies on StreamVault." />
        <meta property="og:title" content="Cartoon — StreamVault" />
        <meta property="og:description" content="Children’s cartoons and animated family adventures." />
      </Helmet>
      <CartoonHero item={seriesItems[0]} />
      <div className="relative z-10 -mt-4 flex flex-col gap-2 md:gap-4">
        <section className="container mx-auto px-4 md:px-8 py-4">
          <h2 className="text-2xl font-bold">Kids’ cartoons</h2>
          <p className="mt-2 text-white/60 text-sm">A selected lineup of children’s series and family animated films. Parents should check each title’s rating; third-party players may show ads.</p>
          {(series.isError || movies.isError) && (
            <div role="alert" className="mt-4 rounded-xl border border-white/15 bg-white/5 p-4">
              <p>Some cartoons could not be loaded. Please try again.</p>
              <Button variant="outline" className="mt-3" onClick={() => {
                if (series.isError) void series.refetch();
                if (movies.isError) void movies.refetch();
              }}>Retry loading</Button>
            </div>
          )}
        </section>
        <ContentRow title="Popular Kids’ Cartoons" items={popularItems} type="tv" isLoading={series.isLoading} />
        <ContentRow title="Top Rated Cartoons" items={topRatedItems} type="tv" isLoading={series.isLoading} />
        <ContentRow title="Family Cartoon Movies" items={movieItems} type="movie" isLoading={movies.isLoading} />
      </div>
    </div>
  );
}
