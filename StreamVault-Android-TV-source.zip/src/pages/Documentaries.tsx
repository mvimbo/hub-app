import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import { BadgeCheck, Clapperboard, Film, Play, Search } from "lucide-react";
import { Link } from "wouter";
import { tmdb, getImageUrl } from "@/lib/tmdb";
import ContentRow from "@/components/ContentRow";
import DocumentaryBadges from "@/components/DocumentaryBadges";
import { Button } from "@/components/ui/button";

function DocumentaryHero({ item }: { item: any }) {
  if (!item) {
    return <div className="h-[52vh] min-h-[420px] bg-gradient-to-br from-cyan-950 via-background to-background" />;
  }

  const title = item.name || item.title;
  const backdrop = getImageUrl(item.backdrop_path, "w1280");
  const type = item.media_type === "tv" ? "tv" : "movie";
  const watchUrl = type === "tv" ? `/watch/tv/${item.id}/1/1` : `/watch/movie/${item.id}`;

  return (
    <div className="relative h-[52vh] min-h-[420px] w-full overflow-hidden">
      {backdrop && <img src={backdrop} alt="" className="h-full w-full object-cover" />}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/75 to-background/10" />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/45 to-transparent" />
      <div className="absolute inset-x-0 bottom-0">
        <div className="container mx-auto px-4 md:px-8 pb-12 md:pb-16">
          <div className="flex items-center gap-2 text-cyan-300 text-xs font-bold uppercase tracking-[0.2em] mb-4">
            <Film className="w-4 h-4" /> Featured documentary
          </div>
          <h1 className="max-w-2xl text-4xl md:text-6xl font-bold text-white tracking-tight">{title}</h1>
          <p className="mt-4 max-w-xl text-white/65 line-clamp-3 leading-relaxed">
            {item.overview || "Explore real stories, remarkable people, and ideas that changed the world."}
          </p>
          <div className="mt-5">
            <DocumentaryBadges compact />
          </div>
          <div className="mt-6 flex items-center gap-3">
            <Link href={watchUrl}>
              <Button className="bg-primary hover:bg-primary/90 text-white font-bold gap-2">
                <Play className="w-4 h-4 fill-current" /> Watch now
              </Button>
            </Link>
            <Link href={`/${type}/${item.id}`}>
              <Button variant="outline" className="border-white/20 bg-black/30 text-white hover:bg-white/10 gap-2">
                <Clapperboard className="w-4 h-4" /> View details
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

function mapItems(data: any, fallbackType: "movie" | "tv") {
  return (data?.results ?? []).map((item: any) => ({
    ...item,
    media_type: item.media_type || fallbackType,
  }));
}

export default function Documentaries() {
  const { data: popularMovies, isLoading: popularMoviesLoading } = useQuery({
    queryKey: ["documentaries", "movies", "popular"],
    queryFn: () => tmdb.getDocumentaries("movie", "popularity.desc"),
  });
  const { data: topRatedMovies, isLoading: topRatedMoviesLoading } = useQuery({
    queryKey: ["documentaries", "movies", "top-rated"],
    queryFn: () => tmdb.getDocumentaries("movie", "vote_average.desc"),
  });
  const { data: documentarySeries, isLoading: documentarySeriesLoading } = useQuery({
    queryKey: ["documentaries", "tv", "popular"],
    queryFn: () => tmdb.getDocumentaries("tv", "popularity.desc"),
  });
  const { data: newDocumentaries, isLoading: newDocumentariesLoading } = useQuery({
    queryKey: ["documentaries", "movies", "new"],
    queryFn: () => tmdb.getDocumentaries("movie", "primary_release_date.desc"),
  });
  const { data: trueCrime, isLoading: trueCrimeLoading } = useQuery({
    queryKey: ["documentaries", "topic", "true-crime"],
    queryFn: () => tmdb.getDocumentaryTopic("true crime"),
  });
  const { data: nature, isLoading: natureLoading } = useQuery({
    queryKey: ["documentaries", "topic", "nature"],
    queryFn: () => tmdb.getDocumentaryTopic("nature wildlife"),
  });
  const { data: history, isLoading: historyLoading } = useQuery({
    queryKey: ["documentaries", "topic", "history"],
    queryFn: () => tmdb.getDocumentaryTopic("history"),
  });
  const { data: science, isLoading: scienceLoading } = useQuery({
    queryKey: ["documentaries", "topic", "science"],
    queryFn: () => tmdb.getDocumentaryTopic("science technology"),
  });
  const { data: biography, isLoading: biographyLoading } = useQuery({
    queryKey: ["documentaries", "topic", "biography"],
    queryFn: () => tmdb.getDocumentaryTopic("biography"),
  });
  const { data: sports, isLoading: sportsLoading } = useQuery({
    queryKey: ["documentaries", "topic", "sports"],
    queryFn: () => tmdb.getDocumentaryTopic("sports"),
  });

  const popularItems = mapItems(popularMovies, "movie");
  const topRatedItems = mapItems(topRatedMovies, "movie");
  const seriesItems = mapItems(documentarySeries, "tv");
  const newItems = mapItems(newDocumentaries, "movie");
  const featured = popularItems[0];

  const topicRows = [
    { title: "True Crime", data: trueCrime, isLoading: trueCrimeLoading },
    { title: "Nature & Wildlife", data: nature, isLoading: natureLoading },
    { title: "History", data: history, isLoading: historyLoading },
    { title: "Science & Technology", data: science, isLoading: scienceLoading },
    { title: "Biography", data: biography, isLoading: biographyLoading },
    { title: "Sports Documentaries", data: sports, isLoading: sportsLoading },
  ];

  return (
    <div className="min-h-screen pb-20">
      <Helmet>
        <title>Documentaries — StreamVault</title>
        <meta name="description" content="Explore true crime, nature, history, science, biography, and sports documentaries on StreamVault." />
      </Helmet>

      <DocumentaryHero item={featured} />

      <div className="relative z-10 -mt-4 flex flex-col gap-2 md:gap-4">
        <div className="container mx-auto px-4 md:px-8 pt-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl border border-cyan-300/15 bg-cyan-950/20 p-5">
            <div>
              <p className="text-cyan-300 text-[11px] font-bold uppercase tracking-[0.18em] mb-1">Documentary guide</p>
              <p className="text-white/60 text-sm">Curated real stories with subtitles and availability that may vary by source.</p>
            </div>
            <Link href="/search?documentary=1">
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 gap-2 whitespace-nowrap">
                <Search className="w-4 h-4" /> Search documentaries
              </Button>
            </Link>
          </div>
        </div>

        <ContentRow title="Popular Documentaries" items={popularItems} type="movie" isLoading={popularMoviesLoading} />
        <ContentRow title="Documentary Series" items={seriesItems} type="tv" isLoading={documentarySeriesLoading} />
        <ContentRow title="Award-Worthy Documentaries" items={topRatedItems} type="movie" isLoading={topRatedMoviesLoading} />
        <ContentRow title="Recently Released" items={newItems} type="movie" isLoading={newDocumentariesLoading} />

        {topicRows.map((row) => (
          <ContentRow
            key={row.title}
            title={row.title}
            items={mapItems(row.data, "movie")}
            type="mixed"
            isLoading={row.isLoading}
          />
        ))}

        <section className="container mx-auto px-4 md:px-8 pt-6">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 md:p-6">
            <div className="flex items-center gap-3 mb-3">
              <BadgeCheck className="w-5 h-5 text-cyan-300" />
              <h2 className="text-xl font-bold text-white">Documentary collections</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {["Short documentaries", "Mini-series", "Based on real events", "Hidden gems", "Award winners", "Family learning"].map((label) => (
                <span key={label} className="inline-flex rounded-full bg-white/10 px-3 py-2 text-xs text-white/70">
                  {label}
                </span>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}