import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import { CalendarDays, ChevronLeft, ChevronRight, CircleAlert, ExternalLink, Film, Radio, RefreshCw, ShieldCheck, Trophy, Tv2 } from "lucide-react";
import { getSportsEventsForDate, getSportsRecentEvents, getSportsStandings, localSportsDate, SPORTS_REPLAY_LOOKBACK_DAYS, SportsDataError, sportsLeagues } from "@/lib/sports";
import type { SportsEvent, SportsLeague } from "@/lib/sports";
import SportsStandingsTable from "@/components/SportsStandingsTable";
import SportsFeedStatus from "@/components/SportsFeedStatus";
import SportsReplayCard from "@/components/SportsReplayCard";
import { useSportsClock } from "@/hooks/useSportsClock";
import { trackEvent } from "@/lib/analytics";

const refreshPolicy = {
  refetchOnMount: "always" as const,
  refetchOnWindowFocus: "always" as const,
  refetchOnReconnect: "always" as const,
  refetchIntervalInBackground: false,
  retry: (failures: number, error: Error) =>
    !(error instanceof SportsDataError && error.status && error.status >= 400 && error.status < 500) && failures < 2,
  retryDelay: (attempt: number) => Math.min(1_000 * 2 ** attempt, 10_000),
};

function displayDate(value: string) {
  if (!value) return "Date to be confirmed";
  return new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" })
    .format(new Date(`${value}T12:00:00`));
}

function formatTime(value: string | null) {
  if (!value) return "Time TBC";
  const parsed = new Date(`2000-01-01T${value}`);
  return Number.isNaN(parsed.getTime())
    ? value.slice(0, 5)
    : new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(parsed);
}

function isCompleted(status: string) {
  return /finished|(^|\b)ft(\b|$)|final|ended|complete|aet|aot/i.test(status);
}

function isLive(status: string) {
  return /live|in progress|half|quarter|period|inning|set [1-5]|^\d{1,2}['′]|^(1h|2h|q[1-4]|ot|p[1-3])$/i.test(status);
}

function formatStatus(status: string) {
  const normalized = status.trim().toUpperCase();
  if (!normalized || normalized === "NS" || normalized === "SCHEDULED") return "Scheduled";
  if (normalized === "FT" || normalized === "FINAL") return "Final";
  if (normalized === "HT") return "Half-time";
  if (normalized === "AOT") return "Final · OT";
  if (normalized === "AET") return "Final · ET";
  return status;
}

function TeamMark({ badge, name }: { badge: string | null; name: string }) {
  return (
    <span className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border border-white/10 bg-[#172321]">
      {badge ? (
        <img src={badge} alt="" loading="lazy" className="h-7 w-7 object-contain" />
      ) : (
        <span className="text-[11px] font-black tracking-wide text-[#d7e2d8]">{name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase()}</span>
      )}
    </span>
  );
}

function EventCard({ event }: { event: SportsEvent }) {
  const hasScore = event.homeScore !== null && event.awayScore !== null;
  const complete = isCompleted(event.status);
  const live = isLive(event.status);
  return (
    <article data-testid={`card-sports-event-${event.id}`} className="group relative overflow-hidden rounded-2xl border border-white/[0.09] bg-[#101918] p-4 transition-colors hover:border-[#c6f36b]/30 sm:p-5">
      <div className="mb-4 flex items-center justify-between gap-3 text-[10px] font-bold uppercase tracking-[0.17em] text-[#a6b4ae]">
        <span className="flex min-w-0 items-center gap-2 truncate"><CalendarDays className="h-3.5 w-3.5 text-[#c6f36b]" />{formatTime(event.time)}</span>
        <span className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 tracking-[0.12em] ${live ? "bg-red-500/15 text-red-300" : complete ? "bg-white/[0.07] text-white/55" : hasScore ? "bg-[#c6f36b]/10 text-[#c6f36b]" : "bg-[#df795c]/10 text-[#f2a184]"}`}>
          {live && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" />}
          {formatStatus(event.status)}
        </span>
      </div>
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-4 gap-y-4">
        <div className="flex min-w-0 items-center gap-3">
          <TeamMark badge={event.homeBadge} name={event.homeTeam} />
          <span className="truncate text-sm font-bold text-[#f5f4ed] sm:text-base">{event.homeTeam}</span>
        </div>
        <span className="min-w-[2.4rem] text-right font-mono text-xl font-bold tabular-nums text-white" data-testid={`text-home-score-${event.id}`}>
          {hasScore ? event.homeScore : <span className="text-sm font-medium text-white/25">—</span>}
        </span>
        <div className="flex min-w-0 items-center gap-3">
          <TeamMark badge={event.awayBadge} name={event.awayTeam} />
          <span className="truncate text-sm font-bold text-[#f5f4ed] sm:text-base">{event.awayTeam}</span>
        </div>
        <span className="min-w-[2.4rem] text-right font-mono text-xl font-bold tabular-nums text-white" data-testid={`text-away-score-${event.id}`}>
          {hasScore ? event.awayScore : <span className="text-sm font-medium text-white/25">—</span>}
        </span>
      </div>
      <div className="mt-4 flex items-center justify-between gap-3 border-t border-white/[0.07] pt-3">
        <p className="min-w-0 truncate text-xs text-white/40" title={event.venue ?? event.name}>{event.venue || event.name}</p>
        {event.videoUrl && (
          <a href={event.videoUrl} target="_blank" rel="noopener noreferrer" data-testid={`link-event-source-${event.id}`} className="inline-flex shrink-0 items-center gap-1.5 text-[11px] font-semibold text-[#c6f36b] transition-colors hover:text-white">
            Highlight source <ExternalLink className="h-3 w-3" />
          </a>
        )}
      </div>
    </article>
  );
}

function SkeletonCards() {
  return (
    <div className="grid gap-3 lg:grid-cols-2" aria-label="Loading fixtures">
      {[0, 1, 2, 3].map((item) => <div key={item} className="h-[170px] animate-pulse rounded-2xl border border-white/[0.06] bg-white/[0.035]" />)}
    </div>
  );
}

export default function Sports() {
  const [leagueId, setLeagueId] = useState(sportsLeagues[0]?.id ?? "");
  const [chosenDate, setChosenDate] = useState<string | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<SportsEvent | null>(null);
  const { now, online } = useSportsClock();
  const league: SportsLeague | undefined = sportsLeagues.find((item) => item.id === leagueId);
  const today = localSportsDate(new Date(now));
  const selectedDate = chosenDate ?? today;
  const selectedIsToday = selectedDate === today;
  const setSelectedDate = (date: string) => setChosenDate(date === today ? null : date);
  const fixturesQuery = useQuery({
    ...refreshPolicy,
    queryKey: ["sports-scoreboard-espn", leagueId, selectedDate],
    queryFn: ({ signal }) => getSportsEventsForDate(leagueId, selectedDate, signal),
    enabled: Boolean(leagueId && selectedDate),
    staleTime: 15_000,
    refetchInterval: (query) => query.state.error instanceof SportsDataError && query.state.error.status === 429
      ? 5 * 60_000
      : query.state.status === "error"
        ? 2 * 60_000
        : selectedIsToday
          ? query.state.data?.some((event) => isLive(event.status)) ? 30_000 : 60_000
          : 5 * 60_000,
  });
  const highlightsQuery = useQuery({
    ...refreshPolicy,
    queryKey: ["sports-replays-espn", leagueId, today],
    queryFn: ({ signal }) => getSportsRecentEvents(leagueId, signal),
    enabled: Boolean(leagueId),
    staleTime: 60_000,
    refetchInterval: (query) => query.state.error instanceof SportsDataError && query.state.error.status === 429
      ? 5 * 60_000
      : 2 * 60_000,
  });
  const standingsQuery = useQuery({
    ...refreshPolicy,
    queryKey: ["sports-standings", leagueId],
    queryFn: ({ signal }) => getSportsStandings(leagueId, signal),
    enabled: Boolean(leagueId),
    staleTime: 60_000,
    refetchInterval: 5 * 60_000,
  });
  const highlights = highlightsQuery.data ?? [];
  const dayEvents = fixturesQuery.data ?? [];
  const hasLiveGame = dayEvents.some((event) => isLive(event.status));
  const isScoreboardLoading = dayEvents.length === 0 && fixturesQuery.isPending && online;
  const scoreboardError = fixturesQuery.error ?? (!online && !fixturesQuery.data
    ? new Error("You're offline. Reconnect to load this scoreboard; updates will resume automatically.")
    : null);
  const isRefreshing = fixturesQuery.isFetching || highlightsQuery.isFetching || standingsQuery.isFetching;

  function refreshAll() {
    trackEvent("sports_refresh_requested", { league: league?.name ?? "unknown" });
    void fixturesQuery.refetch({ cancelRefetch: false });
    void highlightsQuery.refetch({ cancelRefetch: false });
    void standingsQuery.refetch({ cancelRefetch: false });
  }

  function shiftDate(days: number) {
    const next = new Date(`${selectedDate}T12:00:00`);
    next.setDate(next.getDate() + days);
    setSelectedDate(localSportsDate(next));
  }

  return (
    <div className="min-h-screen overflow-hidden bg-[#0b1110] pb-20 text-[#f5f4ed]">
      <Helmet>
        <title>Sports — StreamVault</title>
        <meta name="description" content="Browse sports schedules, results, and official highlights across major leagues on StreamVault." />
      </Helmet>

      <section className="relative border-b border-white/[0.08] bg-[#0b1110]">
        <div className="pointer-events-none absolute inset-0 opacity-60" style={{ backgroundImage: "linear-gradient(115deg, transparent 42%, rgba(198,243,107,.07) 42.1%, transparent 42.4%), radial-gradient(ellipse at 84% 8%, rgba(198,243,107,.13), transparent 30%)" }} />
        <div className="container relative mx-auto px-4 pb-10 pt-28 md:px-8 md:pb-14 md:pt-36">
          <div className="grid items-end gap-8 lg:grid-cols-[1fr_auto]">
            <div className="max-w-3xl">
              <div className="mb-5 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.24em] text-[#c6f36b]">
                <span className="h-2 w-2 rounded-full bg-[#c6f36b]" /> StreamVault sports desk
              </div>
              <h1 className="max-w-3xl text-4xl font-black leading-[0.98] tracking-[-0.045em] sm:text-5xl md:text-7xl">
                The day in <span className="text-[#c6f36b]">play.</span>
              </h1>
              <p className="mt-5 max-w-xl text-sm leading-6 text-[#a5b1ac] sm:text-base">
                Fixtures, final scores, and the moments worth replaying. All in one place, with the source always in view.
              </p>
            </div>
            <div className="max-w-sm border-l-2 border-[#c6f36b] pl-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.16em] text-[#d5e5ce]"><Radio className="h-4 w-4 text-[#c6f36b]" /> Score data, honestly</div>
              <p className="mt-2 text-xs leading-5 text-white/45">Scores, fixtures and latest completed games: ESPN. Standings: TheSportsDB. Feeds refresh automatically while this tab is active, but provider delays and gaps can still occur.</p>
            </div>
          </div>
        </div>
      </section>

      <main className="container mx-auto space-y-12 px-4 pt-8 md:px-8 md:pt-10">
        <section aria-labelledby="fixtures-title">
          <div className="mb-5 flex flex-col justify-between gap-5 xl:flex-row xl:items-end">
            <div>
              <div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-[#c6f36b]"><Trophy className="h-3.5 w-3.5" /> Scoreboard</div>
              <h2 id="fixtures-title" className="text-2xl font-extrabold tracking-tight sm:text-3xl">Fixtures & results</h2>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="flex gap-1 overflow-x-auto rounded-xl border border-white/10 bg-[#111a18] p-1 no-scrollbar" role="tablist" aria-label="Select league">
                {sportsLeagues.map((item) => (
                  <button key={item.id} type="button" role="tab" aria-selected={leagueId === item.id} data-testid={`button-league-${item.id}`} onClick={() => { if (item.id === leagueId) return; setLeagueId(item.id); setSelectedVideo(null); trackEvent("sports_league_selected", { league: item.name }); }} className={`shrink-0 rounded-lg px-3 py-2 text-xs font-bold transition-colors ${leagueId === item.id ? "bg-[#c6f36b] text-[#10150e]" : "text-white/50 hover:bg-white/[0.06] hover:text-white"}`}>
                    {item.name}
                  </button>
                ))}
              </div>
              <div className="flex h-11 items-center gap-1 rounded-xl border border-white/10 bg-[#111a18] p-1">
                <button type="button" aria-label="Previous day" data-testid="button-date-previous" onClick={() => shiftDate(-1)} className="grid h-9 w-9 place-items-center rounded-lg text-white/55 hover:bg-white/[0.07] hover:text-white"><ChevronLeft className="h-4 w-4" /></button>
                <label className="relative flex min-w-0 items-center gap-2 px-1">
                  <CalendarDays className="h-4 w-4 shrink-0 text-[#c6f36b]" />
                  <span className="sr-only">Choose fixture date</span>
                  <input type="date" value={selectedDate} onChange={(event) => { if (event.target.value) setSelectedDate(event.target.value); }} data-testid="input-fixture-date" className="w-[132px] border-0 bg-transparent text-xs font-semibold text-white outline-none [color-scheme:dark]" />
                </label>
                <button type="button" aria-label="Next day" data-testid="button-date-next" onClick={() => shiftDate(1)} className="grid h-9 w-9 place-items-center rounded-lg text-white/55 hover:bg-white/[0.07] hover:text-white"><ChevronRight className="h-4 w-4" /></button>
                {!selectedIsToday && <button type="button" data-testid="button-date-today" onClick={() => setSelectedDate(today)} className="mr-1 rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-[#c6f36b] hover:bg-[#c6f36b]/10">Today</button>}
              </div>
            </div>
          </div>

          <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.08] pb-3">
            <p className="text-sm font-semibold text-white/75" data-testid="text-fixture-date">{displayDate(selectedDate)} <span className="mx-1 text-white/20">/</span> {league?.name}</p>
            <div className="flex flex-wrap items-center gap-4">
              {selectedIsToday && (
                <span data-testid="status-live-feed" className="inline-flex items-center gap-1.5 text-xs text-white/45">
                  <Radio className={`h-3.5 w-3.5 ${hasLiveGame ? "text-red-400" : "text-[#c6f36b]"}`} />
                  {fixturesQuery.error
                    ? "Score update unavailable"
                    : hasLiveGame
                      ? "Live match reported"
                      : fixturesQuery.dataUpdatedAt
                        ? "Score feed checked"
                        : "Checking scores"}
                </span>
              )}
              {league && <a href={league.officialScoresUrl} target="_blank" rel="noopener noreferrer" data-testid="link-official-scores" className="inline-flex items-center gap-1.5 text-xs font-semibold text-white/45 transition-colors hover:text-[#c6f36b]">Official scores <ExternalLink className="h-3.5 w-3.5" /></a>}
            </div>
          </div>

          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-1">
              <SportsFeedStatus updatedAt={fixturesQuery.dataUpdatedAt} now={now} online={online} isFetching={fixturesQuery.isFetching} hasError={fixturesQuery.isError} maxAge={selectedIsToday ? 90_000 : 6 * 60_000} testId="status-scores-freshness" />
              <p className="text-[11px] text-white/35">Scores checked {selectedIsToday ? hasLiveGame ? "every 30 seconds during live games" : "every minute" : "every 5 minutes"} · Times in {Intl.DateTimeFormat().resolvedOptions().timeZone}</p>
            </div>
            <button type="button" data-testid="button-refresh-sports" disabled={!online || isRefreshing} onClick={refreshAll} className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-xs font-bold hover:border-[#c6f36b]/40 disabled:cursor-not-allowed disabled:opacity-40">
              <RefreshCw className={`h-3.5 w-3.5 ${isRefreshing ? "animate-spin" : ""}`} /> {isRefreshing ? "Refreshing…" : "Refresh all"}
            </button>
          </div>

          {isScoreboardLoading ? <SkeletonCards /> : dayEvents.length === 0 && scoreboardError ? (
            <div data-testid="state-fixtures-error" className="flex flex-col items-start gap-3 rounded-2xl border border-[#df795c]/25 bg-[#df795c]/[0.06] p-6 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3"><CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-[#f2a184]" /><div><h3 className="font-bold">Couldn’t load this scoreboard</h3><p role="alert" className="mt-1 text-sm text-white/50">{scoreboardError instanceof Error ? scoreboardError.message : "The sports data provider is unavailable right now."}</p></div></div>
              <button type="button" data-testid="button-retry-fixtures" disabled={!online || fixturesQuery.isFetching} onClick={() => void fixturesQuery.refetch({ cancelRefetch: false })} className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-xs font-bold hover:border-[#c6f36b]/40 disabled:opacity-40"><RefreshCw className="h-3.5 w-3.5" /> Try again</button>
            </div>
          ) : dayEvents.length === 0 ? (
            <div data-testid="state-no-fixtures" className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-5 py-10 text-center">
              <CalendarDays className="mx-auto h-7 w-7 text-[#c6f36b]/70" />
              <h3 className="mt-3 font-bold">No fixtures listed for this date</h3>
              <p className="mx-auto mt-1 max-w-md text-sm leading-6 text-white/45">There may be no scheduled matches, or the provider may not have a listing yet. Try another date or check the league’s official schedule.</p>
              {league && <a href={league.officialScoresUrl} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-2 text-xs font-bold text-[#c6f36b] hover:text-white">Open official schedule <ExternalLink className="h-3.5 w-3.5" /></a>}
            </div>
          ) : (
            <div className="grid gap-3 lg:grid-cols-2">{dayEvents.map((event) => <EventCard key={event.id} event={event} />)}</div>
          )}
        </section>

        {league && (
          <div className="space-y-3">
            <SportsFeedStatus updatedAt={standingsQuery.dataUpdatedAt} now={now} online={online} isFetching={standingsQuery.isFetching} hasError={standingsQuery.isError} maxAge={6 * 60_000} testId="status-standings-freshness" />
            <SportsStandingsTable
              standings={standingsQuery.data ?? []}
              isLoading={standingsQuery.isPending && online}
              error={standingsQuery.error instanceof Error ? standingsQuery.error : !online && !standingsQuery.data ? new Error("Offline") : null}
              officialStandingsUrl={league.officialStandingsUrl}
            />
          </div>
        )}

        <section aria-labelledby="highlights-title">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
            <div>
              <div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-[#df795c]"><Film className="h-3.5 w-3.5" /> Official & supplied video</div>
              <h2 id="highlights-title" className="text-2xl font-extrabold tracking-tight sm:text-3xl">Replay the moment</h2>
              <p className="mt-2 max-w-lg text-sm leading-6 text-white/45">The latest 8 completed games from the last {SPORTS_REPLAY_LOOKBACK_DAYS} days, newest first. Official clips appear when supplied; games without clips stay listed rather than being replaced by older videos.</p>
            </div>
            {league && <a href={league.officialVideosUrl} target="_blank" rel="noopener noreferrer" data-testid="link-official-videos" className="inline-flex items-center gap-2 text-xs font-semibold text-white/55 transition-colors hover:text-[#c6f36b]">More from {league.name} <ExternalLink className="h-3.5 w-3.5" /></a>}
          </div>

          <div className="mb-4">
            <SportsFeedStatus updatedAt={highlightsQuery.dataUpdatedAt} now={now} online={online} isFetching={highlightsQuery.isFetching} hasError={highlightsQuery.isError} maxAge={3 * 60_000} testId="status-highlights-freshness" />
            <p className="mt-1 text-[11px] text-white/35">Recent games and clips checked every 2 minutes · Times in {Intl.DateTimeFormat().resolvedOptions().timeZone} · Standings checked every 5 minutes.</p>
          </div>
          {highlightsQuery.isPending && online ? (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[0, 1, 2, 3].map((item) => <div key={item} className="aspect-video animate-pulse rounded-2xl bg-white/[0.04]" />)}</div>
          ) : (highlightsQuery.isError || (!online && !highlightsQuery.data)) && highlights.length === 0 ? (
            <div data-testid="state-highlights-error" className="flex flex-col items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.025] p-5 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-white/55">Recent completed games could not be loaded right now. Fixture data remains available above.</p>
              <button type="button" data-testid="button-retry-highlights" disabled={!online || highlightsQuery.isFetching} onClick={() => void highlightsQuery.refetch({ cancelRefetch: false })} className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-xs font-bold hover:border-[#c6f36b]/40 disabled:opacity-40"><RefreshCw className="h-3.5 w-3.5" /> Retry highlights</button>
            </div>
          ) : highlights.length === 0 ? (
            <div data-testid="state-no-highlights" className="flex items-start gap-4 rounded-2xl border border-white/10 bg-[#111a18] p-5 sm:p-6">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#c6f36b]/10 text-[#c6f36b]"><Tv2 className="h-5 w-5" /></span>
              <div><h3 className="font-bold">No recent completed games reported</h3><p className="mt-1 text-sm leading-6 text-white/45">The feed has no final games for this league in the last {SPORTS_REPLAY_LOOKBACK_DAYS} days. Older clips won’t be presented as current. Check the league’s official video page for more coverage.</p></div>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {highlights.map((event) => (
                <SportsReplayCard
                  key={event.id}
                  event={event}
                  selected={selectedVideo?.id === event.id}
                  onPlay={(game) => { setSelectedVideo(game); trackEvent("sports_highlight_selected", { league: league?.name ?? "unknown" }); }}
                  onOpen={() => trackEvent("sports_replay_source_opened", { league: league?.name ?? "unknown", has_video: Boolean(event.videoUrl) })}
                />
              ))}
            </div>
          )}

          {selectedVideo && (
            <div className="mt-5 rounded-2xl border border-[#c6f36b]/20 bg-[#111a18] p-4 sm:p-5" data-testid={`panel-video-${selectedVideo.id}`}>
              <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                <div><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#c6f36b]">Now playing · YouTube</p><h3 className="mt-1 font-bold">{selectedVideo.homeTeam} vs {selectedVideo.awayTeam}</h3></div>
                {selectedVideo.videoUrl && <a href={selectedVideo.videoUrl} target="_blank" rel="noopener noreferrer" data-testid="link-video-source" className="inline-flex items-center gap-2 text-xs font-bold text-white/65 hover:text-[#c6f36b]">Open source <ExternalLink className="h-3.5 w-3.5" /></a>}
              </div>
              <div className="mx-auto aspect-video w-full max-w-4xl overflow-hidden rounded-xl bg-black">
                {selectedVideo.videoId ? <iframe data-testid="iframe-sports-highlight" title={`${selectedVideo.homeTeam} vs ${selectedVideo.awayTeam} highlight`} src={`https://www.youtube-nocookie.com/embed/${encodeURIComponent(selectedVideo.videoId)}?rel=0`} className="h-full w-full" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen /> : <div className="grid h-full place-items-center text-sm text-white/55">No embeddable video was supplied. Open the source link to watch.</div>}
              </div>
            </div>
          )}
        </section>

        <aside className="flex flex-col gap-3 border-t border-white/[0.08] pt-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="flex max-w-2xl items-start gap-2 text-xs leading-5 text-white/40"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#c6f36b]/70" /> StreamVault links to official ESPN and league coverage, and embeds supplied YouTube videos. Clip availability and regional restrictions are controlled by the providers. No live streams are hosted here.</p>
          {league && <div className="flex shrink-0 gap-4"><a href={league.officialScoresUrl} target="_blank" rel="noopener noreferrer" className="text-xs font-semibold text-white/50 hover:text-white">League scores <ExternalLink className="ml-1 inline h-3 w-3" /></a><a href={league.officialVideosUrl} target="_blank" rel="noopener noreferrer" className="text-xs font-semibold text-white/50 hover:text-white">League videos <ExternalLink className="ml-1 inline h-3 w-3" /></a></div>}
        </aside>
      </main>
    </div>
  );
}