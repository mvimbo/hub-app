import { useParams, Link } from "wouter";
import { Helmet } from "react-helmet-async";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { tmdb } from "@/lib/tmdb";
import VideoPlayer from "@/components/VideoPlayer";
import { useEffect } from "react";
import { storage } from "@/lib/storage";

export default function WatchMovie() {
  const { id } = useParams();

  const { data: movie } = useQuery({
    queryKey: ["movie", id],
    queryFn: () => tmdb.getMovieDetails(id!),
    enabled: !!id,
  });

  useEffect(() => {
    if (!movie || movie.id !== Number(id)) return;
    storage.recordOpened({
      id: movie.id, type: "movie", title: movie.title,
      poster_path: movie.poster_path, vote_average: movie.vote_average,
      release_date: movie.release_date,
    });
  }, [movie, id]);

  return (
    <div className="min-h-screen bg-black">
      <Helmet>
        <title>Watching {movie?.title || "Movie"} - StreamVault</title>
      </Helmet>

      {/* Top Bar */}
      <div className="fixed top-0 left-0 w-full p-4 z-50 flex items-center justify-between bg-gradient-to-b from-black/80 to-transparent pointer-events-none">
        <Link href={`/movie/${id}`} className="pointer-events-auto">
          <div className="flex items-center gap-2 text-white/80 hover:text-white transition-colors cursor-pointer group bg-black/40 px-4 py-2 rounded-full backdrop-blur-md">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="font-medium">Back to details</span>
          </div>
        </Link>
      </div>

      {/* Player */}
      <div className="pt-20 md:pt-0 min-h-screen flex flex-col justify-center max-w-[1600px] mx-auto p-4 md:p-8">
        <VideoPlayer
          tmdbId={id!}
          type="movie"
        />

        {movie && (
          <div className="mt-8 px-2 md:px-4 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-4xl font-bold text-white mb-2">{movie.title}</h1>
              <p className="text-white/70 max-w-3xl leading-relaxed">{movie.overview}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
