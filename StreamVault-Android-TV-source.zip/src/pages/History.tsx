import { useCallback, useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Clock3, Film, Trash2, Tv } from "lucide-react";
import { Link } from "wouter";
import { storage, WatchProgress, getWatchUrl, STORAGE_CHANGED_EVENT } from "@/lib/storage";
import { getImageUrl } from "@/lib/tmdb";
import { Button } from "@/components/ui/button";

export default function History() {
  const [items, setItems] = useState<WatchProgress[]>([]);

  const refresh = useCallback(() => {
    setItems(storage.getViewingHistory());
  }, []);

  useEffect(() => {
    refresh();
    window.addEventListener("focus", refresh);
    window.addEventListener("storage", refresh);
    window.addEventListener(STORAGE_CHANGED_EVENT, refresh);
    return () => {
      window.removeEventListener("focus", refresh);
      window.removeEventListener("storage", refresh);
      window.removeEventListener(STORAGE_CHANGED_EVENT, refresh);
    };
  }, [refresh]);

  const clearHistory = () => {
    items.forEach((item) => storage.removeProgress(item.id, item.type, item.season, item.episode));
    refresh();
  };

  return (
    <>
      <Helmet>
        <title>Viewing History — StreamVault</title>
        <meta name="description" content="Your recently watched movies and TV episodes." />
      </Helmet>

      <div className="min-h-screen pt-24 pb-16 px-4 md:px-8 max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-primary/10">
                <Clock3 className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-white">Viewing History</h1>
            </div>
            <p className="text-white/50 text-sm ml-12">
              {items.length ? `${items.length} title${items.length === 1 ? "" : "s"} and episodes` : "Your recently watched content appears here"}
            </p>
          </div>
          {items.length > 0 && (
            <Button
              variant="outline"
              onClick={clearHistory}
              className="border-white/15 text-white/70 hover:bg-white/10 gap-2"
            >
              <Trash2 className="w-4 h-4" /> Clear history
            </Button>
          )}
        </div>

        {items.length === 0 ? (
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] py-24 text-center">
            <Clock3 className="w-10 h-10 text-white/20 mx-auto mb-4" />
            <h2 className="text-white/70 font-semibold text-lg mb-2">No viewing history yet</h2>
            <p className="text-white/40 text-sm mb-6">Start watching something and it will be saved here.</p>
            <Link href="/">
              <Button className="bg-primary hover:bg-primary/90 text-white">Browse content</Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {items.map((item) => {
              const watchUrl = getWatchUrl(item);
              const detailUrl = `/${item.type}/${item.id}`;
              const poster = getImageUrl(item.poster_path, "w500");
              return (
                <div key={`${item.type}-${item.id}-${item.season ?? ""}-${item.episode ?? ""}`} className="flex gap-4 rounded-xl border border-white/10 bg-white/[0.03] p-3">
                  <Link href={detailUrl} className="w-20 h-28 rounded-lg overflow-hidden bg-secondary flex-none">
                    {poster ? <img src={poster} alt={item.title} className="w-full h-full object-cover" /> : (
                      <div className="w-full h-full flex items-center justify-center">
                        {item.type === "tv" ? <Tv className="w-6 h-6 text-white/30" /> : <Film className="w-6 h-6 text-white/30" />}
                      </div>
                    )}
                  </Link>
                  <div className="min-w-0 flex flex-col justify-between py-1">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-primary font-semibold">{item.type === "tv" ? "TV episode" : "Movie"}</p>
                      <h2 className="text-white font-semibold leading-tight line-clamp-2 mt-1">{item.title}</h2>
                      {item.type === "tv" && item.season != null && item.episode != null && (
                        <p className="text-white/50 text-xs mt-1">Season {item.season} · Episode {item.episode}</p>
                      )}
                      <p className="text-white/40 text-xs mt-2">
                        {item.watched || item.progress >= 90 ? "Previously marked watched" : "Opened in player"}
                      </p>
                    </div>
                    <Link href={watchUrl}>
                      <Button size="sm" className="bg-primary hover:bg-primary/90 text-white w-full mt-2">Open player</Button>
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}