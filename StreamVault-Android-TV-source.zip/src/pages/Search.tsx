import { useState, useEffect, useMemo, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import { useLocation } from "wouter";
import { Search as SearchIcon, SlidersHorizontal, X } from "lucide-react";
import { tmdb } from "@/lib/tmdb";
import { Input } from "@/components/ui/input";
import MovieCard from "@/components/MovieCard";
import SkeletonCard from "@/components/SkeletonCard";
import { trackEvent } from "@/lib/analytics";

export default function Search() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const initialType = searchParams.get("type") || "all";
  const koreanMode = searchParams.get("language") === "ko";
  const documentaryMode = searchParams.get("documentary") === "1";
  
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [filter, setFilter] = useState<string>(initialType);
  const [genre, setGenre] = useState("");
  const [year, setYear] = useState("");
  const [minRating, setMinRating] = useState("");
  const [episodeLimit, setEpisodeLimit] = useState("");
  const [sort, setSort] = useState("popularity");
  const lastTrackedSearch = useRef<string | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), 300);
    return () => clearTimeout(timer);
  }, [query]);

  const { data, isLoading } = useQuery({
    queryKey: ["search", debouncedQuery, filter, koreanMode, documentaryMode, genre, year, minRating, episodeLimit],
    queryFn: () => documentaryMode
      ? tmdb.getDocumentarySearch(debouncedQuery, filter as "all" | "movie" | "tv")
      : koreanMode
        ? tmdb.getKoreanSearch(debouncedQuery, filter as "all" | "movie" | "tv", true)
        : tmdb.searchMulti(debouncedQuery),
    enabled: debouncedQuery.length > 0,
  });

  const filteredResults = useMemo(() => {
    const results = data?.results ?? [];
    return results
      .filter((item: any) => {
        const itemType = item.media_type || filter;
        if (!koreanMode && !documentaryMode && filter === "all") return itemType === "movie" || itemType === "tv";
        if (filter !== "all" && itemType !== filter) return false;
        if (genre && !item.genre_ids?.includes(Number(genre))) return false;
        const releaseDate = item.release_date || item.first_air_date;
        if (year && !releaseDate?.startsWith(year)) return false;
        if (minRating && (item.vote_average ?? 0) < Number(minRating)) return false;
        if (episodeLimit && itemType === "tv" && (item.number_of_episodes ?? 999) > Number(episodeLimit)) return false;
        return true;
      })
      .sort((a: any, b: any) => {
        if (sort === "rating") return (b.vote_average ?? 0) - (a.vote_average ?? 0);
        if (sort === "newest") return new Date(b.release_date || b.first_air_date || 0).getTime() - new Date(a.release_date || a.first_air_date || 0).getTime();
        return (b.popularity ?? 0) - (a.popularity ?? 0);
      });
  }, [data, documentaryMode, episodeLimit, filter, genre, koreanMode, minRating, sort, year]);

  useEffect(() => {
    if (!debouncedQuery || !data) return;

    const mode = documentaryMode ? "documentaries" : koreanMode ? "korean" : "catalog";
    const trackingKey = [
      debouncedQuery,
      mode,
      filter,
      genre,
      year,
      minRating,
      episodeLimit,
    ].join("\u0000");
    if (lastTrackedSearch.current === trackingKey) return;
    lastTrackedSearch.current = trackingKey;

    trackEvent("catalog_search_completed", {
      mode,
      media_type: filter,
      result_count: filteredResults.length,
    });
  }, [
    data,
    debouncedQuery,
    documentaryMode,
    episodeLimit,
    filter,
    filteredResults.length,
    genre,
    koreanMode,
    minRating,
    year,
  ]);

  return (
    <div className="container mx-auto px-4 md:px-8 pt-24 pb-12 min-h-screen">
      <Helmet>
        <title>{documentaryMode ? "Search Documentaries - StreamVault" : koreanMode ? "Search Korean Titles - StreamVault" : "Search - StreamVault"}</title>
      </Helmet>

      <div className="max-w-3xl mx-auto mb-12">
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={documentaryMode ? "Search documentary titles, subjects, or topics..." : koreanMode ? "Search Korean or English titles..." : "Movies, TV shows, and more..."}
            className="w-full pl-14 h-16 text-lg bg-secondary/50 border-none rounded-2xl text-white placeholder:text-muted-foreground focus-visible:ring-1 focus-visible:ring-primary"
            autoFocus
          />
        </div>

        <div className="flex flex-wrap gap-3 mt-6">
          {["all", "movie", "tv"].map((type) => (
            <button
              key={type}
              onClick={() => setFilter(type)}
              className={`px-6 py-2 rounded-full font-medium transition-colors ${
                filter === type
                  ? "bg-white text-black"
                  : "bg-secondary text-white hover:bg-secondary/80"
              }`}
            >
              {type === "all" ? "All" : type === "movie" ? "Movies" : "TV Shows"}
            </button>
          ))}
        </div>
        {documentaryMode && (
          <div className="mt-5 rounded-2xl border border-cyan-300/15 bg-cyan-950/15 p-4">
            <div className="flex items-center gap-2 text-cyan-200 text-sm font-semibold mb-3">
              <SlidersHorizontal className="w-4 h-4" /> Documentary filters
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <select value={genre} onChange={(e) => setGenre(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="">All categories</option>
                <option value="99">Documentary</option>
              </select>
              <select value={year} onChange={(e) => setYear(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="">All years</option>
                {[2026, 2025, 2024, 2023, 2022, 2021, 2020].map((value) => <option key={value} value={value}>{value}</option>)}
              </select>
              <select value={minRating} onChange={(e) => setMinRating(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="">Any rating</option>
                <option value="8">8+ rating</option>
                <option value="7">7+ rating</option>
                <option value="6">6+ rating</option>
              </select>
              <select value={sort} onChange={(e) => setSort(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="popularity">Most popular</option>
                <option value="rating">Highest rated</option>
                <option value="newest">Newest first</option>
              </select>
            </div>
            {(genre || year || minRating) && (
              <button onClick={() => { setGenre(""); setYear(""); setMinRating(""); }} className="mt-3 inline-flex items-center gap-1 text-xs text-white/60 hover:text-white">
                <X className="w-3 h-3" /> Clear filters
              </button>
            )}
          </div>
        )}
        {koreanMode && !documentaryMode && (
          <div className="mt-5 rounded-2xl border border-rose-300/15 bg-rose-950/15 p-4">
            <div className="flex items-center gap-2 text-rose-200 text-sm font-semibold mb-3">
              <SlidersHorizontal className="w-4 h-4" /> Korean filters
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <select value={genre} onChange={(e) => setGenre(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="">All genres</option>
                <option value="18">Drama</option>
                <option value="10749">Romance</option>
                <option value="53">Thriller</option>
                <option value="80">Crime</option>
                <option value="35">Comedy</option>
                <option value="27">Horror</option>
                <option value="28">Action</option>
              </select>
              <select value={year} onChange={(e) => setYear(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="">All years</option>
                {[2026, 2025, 2024, 2023, 2022, 2021, 2020].map((value) => <option key={value} value={value}>{value}</option>)}
              </select>
              <select value={minRating} onChange={(e) => setMinRating(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="">Any rating</option>
                <option value="8">8+ rating</option>
                <option value="7">7+ rating</option>
                <option value="6">6+ rating</option>
              </select>
              <select value={episodeLimit} onChange={(e) => setEpisodeLimit(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="">Any length</option>
                <option value="12">12 episodes or less</option>
                <option value="16">16 episodes or less</option>
                <option value="24">24 episodes or less</option>
              </select>
              <select value={sort} onChange={(e) => setSort(e.target.value)} className="h-10 rounded-lg bg-secondary px-3 text-sm text-white">
                <option value="popularity">Most popular</option>
                <option value="rating">Highest rated</option>
                <option value="newest">Newest first</option>
              </select>
            </div>
            {(genre || year || minRating || episodeLimit) && (
              <button onClick={() => { setGenre(""); setYear(""); setMinRating(""); setEpisodeLimit(""); }} className="mt-3 inline-flex items-center gap-1 text-xs text-white/60 hover:text-white">
                <X className="w-3 h-3" /> Clear filters
              </button>
            )}
          </div>
        )}
      </div>

      {debouncedQuery.length > 0 && (
        <div>
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i} className="w-full aspect-[2/3]"><SkeletonCard /></div>
              ))}
            </div>
          ) : filteredResults && filteredResults.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
              {filteredResults.map((item: any) => (
                <div key={item.id} className="w-full aspect-[2/3] flex justify-center">
                  <MovieCard item={item} type={(item.media_type || filter) as "movie" | "tv"} showOriginalTitle={koreanMode} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-muted-foreground mt-20">
              <p className="text-xl">No results found for "{debouncedQuery}"</p>
            </div>
          )}
        </div>
      )}

      {debouncedQuery.length === 0 && (
        <div className="text-center text-muted-foreground mt-20">
          <SearchIcon className="w-16 h-16 mx-auto mb-4 opacity-20" />
          <p className="text-xl">Search for your favorite movies and TV shows</p>
        </div>
      )}
    </div>
  );
}
