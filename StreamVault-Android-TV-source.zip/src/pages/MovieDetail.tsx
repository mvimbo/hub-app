import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Helmet } from "react-helmet-async";
import { Play, Heart, Check, Plus, Star, Clock, Calendar } from "lucide-react";
import { useState, useEffect } from "react";
import { tmdb, getImageUrl } from "@/lib/tmdb";
import { storage } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import ContentRow from "@/components/ContentRow";
import KoreanBadges from "@/components/KoreanBadges";
import DocumentaryBadges from "@/components/DocumentaryBadges";

export default function MovieDetail() {
  const { id } = useParams();
  const [isFave, setIsFave] = useState(false);
  const [isWatchlist, setIsWatchlist] = useState(false);

  const { data: movie, isLoading, isError } = useQuery({
    queryKey: ["movie", id],
    queryFn: () => tmdb.getMovieDetails(id!),
    enabled: !!id,
  });

  useEffect(() => {
    if (movie) {
      setIsFave(storage.isFavorite(movie.id));
      setIsWatchlist(storage.isInWatchlist(movie.id));
    }
  }, [movie]);

  if (isLoading) return <div className="min-h-screen bg-background animate-pulse" />;
  if (isError || !movie) return <div className="min-h-screen flex items-center justify-center text-white">Failed to load movie.</div>;

  const toggleFavorite = () => {
    if (isFave) {
      storage.removeFavorite(movie.id);
      setIsFave(false);
    } else {
      storage.addFavorite({
        id: movie.id,
        type: "movie",
        title: movie.title,
        poster_path: movie.poster_path,
        vote_average: movie.vote_average,
        release_date: movie.release_date,
      });
      setIsFave(true);
    }
  };

  const toggleWatchlist = () => {
    if (isWatchlist) {
      storage.removeFromWatchlist(movie.id);
      setIsWatchlist(false);
    } else {
      storage.addToWatchlist({
        id: movie.id,
        type: "movie",
        title: movie.title,
        poster_path: movie.poster_path,
        vote_average: movie.vote_average,
        release_date: movie.release_date,
      });
      setIsWatchlist(true);
    }
  };

  const backdropUrl = getImageUrl(movie.backdrop_path, "w1280");
  const posterUrl = getImageUrl(movie.poster_path, "w500");
  const year = movie.release_date ? new Date(movie.release_date).getFullYear() : "";
  const runtime = movie.runtime ? `${Math.floor(movie.runtime / 60)}h ${movie.runtime % 60}m` : "";
  const isKorean = movie.original_language === "ko";
  const isDocumentary = movie.genres?.some((genre: any) => genre.id === 99);
  const originalTitle = movie.original_title && movie.original_title !== movie.title ? movie.original_title : null;
  const director = movie.credits?.crew?.find((person: any) => person.job === "Director")?.name;

  return (
    <div className="min-h-screen pb-20">
      <Helmet>
        <title>{movie.title} - StreamVault</title>
      </Helmet>

      {/* Hero Section */}
      <div className="relative h-[60vh] md:h-[80vh] w-full">
        {backdropUrl && (
          <img src={backdropUrl} alt={movie.title} className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent" />
        
        <div className="absolute inset-0 flex items-center pt-20">
          <div className="container mx-auto px-4 md:px-8 flex flex-col md:flex-row gap-8 items-center md:items-end">
            {/* Poster - hidden on small mobile, visible md+ */}
            {posterUrl && (
              <div className="hidden md:block flex-none w-64 rounded-xl overflow-hidden shadow-2xl ring-1 ring-white/20">
                <img src={posterUrl} alt={movie.title} className="w-full h-auto" />
              </div>
            )}
            
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-2 text-shadow-lg tracking-tight">
                {movie.title}
              </h1>
              {isKorean && originalTitle && (
                <p className="text-white/55 text-sm md:text-base mb-3">{originalTitle}</p>
              )}
              {movie.tagline && (
                <p className="text-xl text-white/70 italic mb-6 text-shadow">{movie.tagline}</p>
              )}
              
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 md:gap-6 text-white/80 font-medium mb-8">
                <div className="flex items-center gap-1.5 text-green-400">
                  <Star className="w-5 h-5 fill-current" />
                  <span>{movie.vote_average?.toFixed(1)} / 10</span>
                </div>
                {year && (
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-5 h-5" />
                    <span>{year}</span>
                  </div>
                )}
                {runtime && (
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-5 h-5" />
                    <span>{runtime}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  {movie.genres?.slice(0, 3).map((g: any) => (
                    <span key={g.id} className="px-2.5 py-0.5 rounded-md bg-white/10 text-sm">
                      {g.name}
                    </span>
                  ))}
                </div>
              </div>
              {isKorean && (
                <div className="mb-6 flex justify-center md:justify-start">
                  <KoreanBadges />
                </div>
              )}
              {isDocumentary && (
                <div className="mb-6 flex justify-center md:justify-start">
                  <DocumentaryBadges />
                </div>
              )}

              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
                <Link href={`/watch/movie/${movie.id}`}>
                  <Button size="lg" className="bg-primary hover:bg-primary/90 text-white font-bold px-8 h-14 text-lg w-full sm:w-auto">
                    <Play className="w-6 h-6 mr-2 fill-current" /> Play Now
                  </Button>
                </Link>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="bg-black/40 border-white/20 hover:bg-white/10 h-14 w-14 p-0 shrink-0"
                  onClick={toggleWatchlist}
                >
                  {isWatchlist ? <Check className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="bg-black/40 border-white/20 hover:bg-white/10 h-14 w-14 p-0 shrink-0"
                  onClick={toggleFavorite}
                >
                  <Heart className={`w-6 h-6 ${isFave ? 'fill-primary text-primary' : ''}`} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8 mt-12 md:mt-24">
        <div className="max-w-4xl">
          <h2 className="text-2xl font-bold text-white mb-4">Overview</h2>
          <p className="text-lg text-white/80 leading-relaxed mb-12">
            {movie.overview}
          </p>
          {isKorean && (
            <div className="mb-12 grid grid-cols-2 sm:grid-cols-4 gap-4 rounded-2xl border border-rose-300/15 bg-rose-950/15 p-5">
              <div>
                <p className="text-white/40 text-[10px] uppercase">Original title</p>
                <p className="text-white text-sm font-medium mt-1">{movie.original_title || movie.title}</p>
              </div>
              <div>
                <p className="text-white/40 text-[10px] uppercase">Original audio</p>
                <p className="text-white text-sm font-medium mt-1">Korean</p>
              </div>
              <div>
                <p className="text-white/40 text-[10px] uppercase">Runtime</p>
                <p className="text-white text-sm font-medium mt-1">{runtime || "—"}</p>
              </div>
              <div>
                <p className="text-white/40 text-[10px] uppercase">Release date</p>
                <p className="text-white text-sm font-medium mt-1">{movie.release_date || "—"}</p>
              </div>
            </div>
          )}
          {isDocumentary && (
            <div className="mb-12 grid grid-cols-2 sm:grid-cols-4 gap-4 rounded-2xl border border-cyan-300/15 bg-cyan-950/15 p-5">
              <div>
                <p className="text-white/40 text-[10px] uppercase">Format</p>
                <p className="text-white text-sm font-medium mt-1">Documentary film</p>
              </div>
              <div>
                <p className="text-white/40 text-[10px] uppercase">Director</p>
                <p className="text-white text-sm font-medium mt-1">{director || "Not listed"}</p>
              </div>
              <div>
                <p className="text-white/40 text-[10px] uppercase">Original language</p>
                <p className="text-white text-sm font-medium mt-1">{movie.original_language?.toUpperCase() || "—"}</p>
              </div>
              <div>
                <p className="text-white/40 text-[10px] uppercase">Runtime</p>
                <p className="text-white text-sm font-medium mt-1">{runtime || "—"}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Rows */}
      {movie.credits?.cast && movie.credits.cast.length > 0 && (
        <div className="container mx-auto px-4 md:px-8 mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Top Cast</h2>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
            {movie.credits.cast.slice(0, 15).map((actor: any) => (
              <div key={actor.id} className="flex-none w-[140px] text-center">
                <div className="w-24 h-24 mx-auto rounded-full overflow-hidden bg-secondary mb-3 shadow-lg">
                  {actor.profile_path ? (
                    <img 
                      src={getImageUrl(actor.profile_path, "w500")!} 
                      alt={actor.name} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xl font-bold text-white/30">
                      {actor.name.charAt(0)}
                    </div>
                  )}
                </div>
                <h3 className="font-medium text-white text-sm line-clamp-1">{actor.name}</h3>
                <p className="text-xs text-white/50 line-clamp-1">{actor.character}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {movie.similar?.results?.length > 0 && (
        <ContentRow title="Similar Movies" items={movie.similar.results} type="movie" />
      )}
      {movie.recommendations?.results?.length > 0 && (
        <ContentRow title="Recommendations" items={movie.recommendations.results} type="movie" />
      )}

    </div>
  );
}
