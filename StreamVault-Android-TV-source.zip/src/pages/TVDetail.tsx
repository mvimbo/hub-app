import { useQuery } from "@tanstack/react-query";
import { useParams, Link, useLocation } from "wouter";
import { Helmet } from "react-helmet-async";
import { Play, Heart, Check, Plus, Star, Calendar, CheckCircle2, Circle } from "lucide-react";
import { useState, useEffect } from "react";
import { tmdb, getImageUrl } from "@/lib/tmdb";
import { formatAniListStatus, getAniListDisplayTitle, getAniListMetadata } from "@/lib/anilist";
import { storage } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import ContentRow from "@/components/ContentRow";
import KoreanBadges from "@/components/KoreanBadges";
import DocumentaryBadges from "@/components/DocumentaryBadges";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function TVDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const [isFave, setIsFave] = useState(false);
  const [isWatchlist, setIsWatchlist] = useState(false);
  const [selectedSeason, setSelectedSeason] = useState<string>("1");

  const { data: tv, isLoading, isError } = useQuery({
    queryKey: ["tv", id],
    queryFn: () => tmdb.getTVDetails(id!),
    enabled: !!id,
  });

  const isLikelyAnime = tv?.original_language === "ja" &&
    tv?.genres?.some((genre: any) => genre.name === "Animation");
  const { data: animeMetadata } = useQuery({
    queryKey: ["anilist", "tv", tv?.id, tv?.name],
    queryFn: () => getAniListMetadata(tv?.name ?? ""),
    enabled: !!isLikelyAnime && !!tv?.name,
    retry: 1,
  });

  const { data: seasonDetails } = useQuery({
    queryKey: ["season", id, selectedSeason],
    queryFn: () => tmdb.getSeasonDetails(id!, selectedSeason),
    enabled: !!id && !!selectedSeason,
  });

  useEffect(() => {
    if (tv) {
      setIsFave(storage.isFavorite(tv.id));
      setIsWatchlist(storage.isInWatchlist(tv.id));
      const progress = storage.getViewingHistory().find(
        (p) => p.id === tv.id && p.type === "tv"
      );
      if (progress?.season) {
        setSelectedSeason(progress.season.toString());
      } else if (tv.seasons?.length > 0) {
        const valid = tv.seasons.filter((s: any) => s.season_number > 0);
        if (valid.length > 0) setSelectedSeason(valid[0].season_number.toString());
      }
    }
  }, [tv]);

  if (isLoading) return <div className="min-h-screen bg-background animate-pulse" />;
  if (isError || !tv)
    return (
      <div className="min-h-screen flex items-center justify-center text-white">
        Failed to load TV show.
      </div>
    );

  const toggleFavorite = () => {
    if (isFave) { storage.removeFavorite(tv.id); setIsFave(false); }
    else {
      storage.addFavorite({ id: tv.id, type: "tv", title: tv.name, poster_path: tv.poster_path, vote_average: tv.vote_average, release_date: tv.first_air_date });
      setIsFave(true);
    }
  };

  const toggleWatchlist = () => {
    if (isWatchlist) { storage.removeFromWatchlist(tv.id); setIsWatchlist(false); }
    else {
      storage.addToWatchlist({ id: tv.id, type: "tv", title: tv.name, poster_path: tv.poster_path, vote_average: tv.vote_average, release_date: tv.first_air_date });
      setIsWatchlist(true);
    }
  };

  const backdropUrl = getImageUrl(tv.backdrop_path, "w1280");
  const posterUrl = getImageUrl(tv.poster_path, "w500");
  const year = tv.first_air_date ? new Date(tv.first_air_date).getFullYear() : "";
  const validSeasons = (tv.seasons ?? []).filter((s: any) => s.season_number > 0);
  const isKorean = tv.original_language === "ko";
  const isDocumentary = tv.genres?.some((genre: any) => genre.id === 99);
  const originalTitle = tv.original_name && tv.original_name !== tv.name ? tv.original_name : null;
  const episodes = seasonDetails?.episodes ?? [];
  const watchedEpisodes = episodes.filter((episode: any) =>
    storage.getProgress(tv.id, "tv", Number(selectedSeason), episode.episode_number)?.watched ||
    (storage.getProgress(tv.id, "tv", Number(selectedSeason), episode.episode_number)?.progress ?? 0) >= 90
  );
  const nextUnwatchedEpisode = episodes.find((episode: any) => !watchedEpisodes.some((watched: any) => watched.id === episode.id));

  return (
    <div className="min-h-screen pb-20">
      <Helmet>
        <title>{tv.name} - StreamVault</title>
      </Helmet>

      {/* Hero */}
      <div className="relative h-[60vh] md:h-[80vh] w-full">
        {backdropUrl && (
          <img src={backdropUrl} alt={tv.name} className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent" />

        <div className="absolute inset-0 flex items-center pt-20">
          <div className="container mx-auto px-4 md:px-8 flex flex-col md:flex-row gap-8 items-center md:items-end">
            {posterUrl && (
              <div className="hidden md:block flex-none w-64 rounded-xl overflow-hidden shadow-2xl ring-1 ring-white/20">
                <img src={posterUrl} alt={tv.name} className="w-full h-auto" />
              </div>
            )}

            <div className="flex-1 text-center md:text-left">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-2 tracking-tight">
                {tv.name}
              </h1>
              {isKorean && originalTitle && (
                <p className="text-white/55 text-sm md:text-base mb-3">{originalTitle}</p>
              )}
              {tv.tagline && (
                <p className="text-xl text-white/70 italic mb-6">{tv.tagline}</p>
              )}

              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 md:gap-6 text-white/80 font-medium mb-8">
                <div className="flex items-center gap-1.5 text-green-400">
                  <Star className="w-5 h-5 fill-current" />
                  <span>{tv.vote_average?.toFixed(1)} / 10</span>
                </div>
                {year && (
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-5 h-5" />
                    <span>{year}</span>
                  </div>
                )}
                <span className="px-2 py-1 bg-white/10 rounded-md text-sm">
                  {tv.number_of_seasons} Seasons
                </span>
                {tv.genres?.slice(0, 3).map((g: any) => (
                  <span key={g.id} className="px-2.5 py-0.5 rounded-md bg-white/10 text-sm">
                    {g.name}
                  </span>
                ))}
              </div>
              {isKorean && (
                <div className="mb-6 flex justify-center md:justify-start">
                  <KoreanBadges />
                </div>
              )}
              {isDocumentary && (
                <div className="mb-6 flex justify-center md:justify-start">
                  <DocumentaryBadges />
                </div>
              )}

              <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
                <Link href={`/watch/tv/${tv.id}/${selectedSeason}/1`}>
                  <Button size="lg" className="bg-primary hover:bg-primary/90 text-white font-bold px-8 h-14 text-lg">
                    <Play className="w-6 h-6 mr-2 fill-current" /> Play S{selectedSeason} E{nextUnwatchedEpisode?.episode_number ?? 1}
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="bg-black/40 border-white/20 hover:bg-white/10 h-14 w-14 p-0 shrink-0" onClick={toggleWatchlist}>
                  {isWatchlist ? <Check className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
                </Button>
                <Button size="lg" variant="outline" className="bg-black/40 border-white/20 hover:bg-white/10 h-14 w-14 p-0 shrink-0" onClick={toggleFavorite}>
                  <Heart className={`w-6 h-6 ${isFave ? "fill-primary text-primary" : ""}`} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8 mt-12 md:mt-24">
        <div className="flex flex-col lg:flex-row gap-12">
          <div className="flex-1 max-w-4xl">
            <h2 className="text-2xl font-bold text-white mb-4">Overview</h2>
            <p className="text-lg text-white/80 leading-relaxed mb-12">{tv.overview}</p>

            {isKorean && (
              <div className="mb-12 grid grid-cols-2 sm:grid-cols-4 gap-4 rounded-2xl border border-rose-300/15 bg-rose-950/15 p-5">
                <div>
                  <p className="text-white/40 text-[10px] uppercase">Original title</p>
                  <p className="text-white text-sm font-medium mt-1">{tv.original_name || tv.name}</p>
                </div>
                <div>
                  <p className="text-white/40 text-[10px] uppercase">Original audio</p>
                  <p className="text-white text-sm font-medium mt-1">Korean</p>
                </div>
                <div>
                  <p className="text-white/40 text-[10px] uppercase">Episodes</p>
                  <p className="text-white text-sm font-medium mt-1">{tv.number_of_episodes ?? "TBA"}</p>
                </div>
                <div>
                  <p className="text-white/40 text-[10px] uppercase">Episode runtime</p>
                  <p className="text-white text-sm font-medium mt-1">{tv.episode_run_time?.[0] ? `${tv.episode_run_time[0]} min` : "—"}</p>
                </div>
              </div>
            )}
            {isDocumentary && (
              <div className="mb-12 grid grid-cols-2 sm:grid-cols-4 gap-4 rounded-2xl border border-cyan-300/15 bg-cyan-950/15 p-5">
                <div>
                  <p className="text-white/40 text-[10px] uppercase">Format</p>
                  <p className="text-white text-sm font-medium mt-1">Documentary series</p>
                </div>
                <div>
                  <p className="text-white/40 text-[10px] uppercase">Original language</p>
                  <p className="text-white text-sm font-medium mt-1">{tv.original_language?.toUpperCase() || "—"}</p>
                </div>
                <div>
                  <p className="text-white/40 text-[10px] uppercase">Episodes</p>
                  <p className="text-white text-sm font-medium mt-1">{tv.number_of_episodes ?? "TBA"}</p>
                </div>
                <div>
                  <p className="text-white/40 text-[10px] uppercase">Episode runtime</p>
                  <p className="text-white text-sm font-medium mt-1">{tv.episode_run_time?.[0] ? `${tv.episode_run_time[0]} min` : "—"}</p>
                </div>
              </div>
            )}

            {animeMetadata && (
              <div className="mb-12 rounded-2xl border border-indigo-300/15 bg-indigo-950/20 p-5 md:p-6">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-5">
                  <div>
                    <p className="text-indigo-300 text-[11px] font-bold uppercase tracking-[0.18em] mb-1">Anime metadata</p>
                    <h2 className="text-xl font-bold text-white">{getAniListDisplayTitle(animeMetadata)}</h2>
                    <p className="text-white/45 text-xs mt-1">{animeMetadata.title.native || animeMetadata.title.romaji}</p>
                  </div>
                  <a href={animeMetadata.siteUrl} target="_blank" rel="noopener noreferrer" className="text-indigo-300 hover:text-indigo-200 text-xs font-semibold">
                    View AniList profile
                  </a>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div><p className="text-white/40 text-[10px] uppercase">Status</p><p className="text-white text-sm font-medium">{formatAniListStatus(animeMetadata.status)}</p></div>
                  <div><p className="text-white/40 text-[10px] uppercase">Episodes</p><p className="text-white text-sm font-medium">{animeMetadata.episodes ?? "TBA"}</p></div>
                  <div><p className="text-white/40 text-[10px] uppercase">Season</p><p className="text-white text-sm font-medium">{animeMetadata.seasonYear ? `${animeMetadata.seasonYear} ${formatAniListStatus(animeMetadata.season ?? "")}` : "—"}</p></div>
                  <div><p className="text-white/40 text-[10px] uppercase">Studio</p><p className="text-white text-sm font-medium">{animeMetadata.studios.nodes[0]?.name ?? "—"}</p></div>
                </div>
                {animeMetadata.genres.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-5">
                    {animeMetadata.genres.slice(0, 6).map((genre) => (
                      <span key={genre} className="rounded-full bg-white/10 px-3 py-1 text-xs text-white/65">{genre}</span>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Season selector + episode list */}
            <div className="mb-12">
              <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
                <h2 className="text-2xl font-bold text-white">Episodes</h2>
                <div className="flex items-center gap-3">
                  {tv.seasons && (
                    <Select value={selectedSeason} onValueChange={setSelectedSeason}>
                      <SelectTrigger className="w-[160px] bg-secondary border-none">
                        <SelectValue placeholder="Select Season" />
                      </SelectTrigger>
                      <SelectContent>
                        {validSeasons.map((s: any) => (
                          <SelectItem key={s.id} value={s.season_number.toString()}>
                            Season {s.season_number}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </div>

               <div className="bg-secondary/30 rounded-xl p-4 md:p-6">
                 <div className="flex items-center justify-between gap-3 mb-4">
                   <p className="text-white/70 text-sm">
                     {episodes.length ? `${watchedEpisodes.length} of ${episodes.length} episodes watched` : "Loading episode guide…"}
                   </p>
                   {nextUnwatchedEpisode && (
                     <Link href={`/watch/tv/${tv.id}/${selectedSeason}/${nextUnwatchedEpisode.episode_number}`}>
                       <Button size="sm" className="bg-primary hover:bg-primary/90 text-white gap-2">
                         <Play className="w-3.5 h-3.5 fill-current" /> Next unwatched
                       </Button>
                     </Link>
                   )}
                 </div>
                 {episodes.length > 0 && (
                   <div className="space-y-2">
                     {episodes.map((episode: any) => {
                       const progress = storage.getProgress(tv.id, "tv", Number(selectedSeason), episode.episode_number);
                       const watched = progress?.watched || (progress?.progress ?? 0) >= 90;
                       return (
                         <Link key={episode.id} href={`/watch/tv/${tv.id}/${selectedSeason}/${episode.episode_number}`}>
                           <div className="group flex items-center gap-3 rounded-lg p-3 hover:bg-white/10 transition-colors">
                             <div className="w-14 h-9 rounded overflow-hidden bg-black/40 flex-none">
                               {episode.still_path ? <img src={getImageUrl(episode.still_path, "w500")!} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Play className="w-3 h-3 text-white/30" /></div>}
                             </div>
                             <span className="text-white/40 text-xs font-mono w-8">E{episode.episode_number}</span>
                             <div className="min-w-0 flex-1">
                               <p className="text-white text-sm font-medium truncate group-hover:text-primary transition-colors">{episode.name}</p>
                               <p className="text-white/40 text-xs truncate">{episode.overview || "No episode description available."}</p>
                             </div>
                             {watched ? <CheckCircle2 className="w-4 h-4 text-green-400 flex-none" /> : <Circle className="w-4 h-4 text-white/20 flex-none" />}
                           </div>
                         </Link>
                       );
                     })}
                   </div>
                 )}
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* Cast */}
      {tv.credits?.cast?.length > 0 && (
        <div className="container mx-auto px-4 md:px-8 mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Top Cast</h2>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
            {tv.credits.cast.slice(0, 15).map((actor: any) => (
              <div key={actor.id} className="flex-none w-[140px] text-center">
                <div className="w-24 h-24 mx-auto rounded-full overflow-hidden bg-secondary mb-3 shadow-lg">
                  {actor.profile_path ? (
                    <img src={getImageUrl(actor.profile_path, "w500")!} alt={actor.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xl font-bold text-white/30">
                      {actor.name.charAt(0)}
                    </div>
                  )}
                </div>
                <h3 className="font-medium text-white text-sm line-clamp-1">{actor.name}</h3>
                <p className="text-xs text-white/50 line-clamp-1">{actor.character}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {tv.similar?.results?.length > 0 && (
        <ContentRow title="Similar Shows" items={tv.similar.results} type="tv" />
      )}
      {tv.recommendations?.results?.length > 0 && (
        <ContentRow title="Recommendations" items={tv.recommendations.results} type="tv" />
      )}

    </div>
  );
}
