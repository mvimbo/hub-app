import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import { Bookmark, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { storage, SavedItem } from "@/lib/storage";
import MovieCard from "@/components/MovieCard";
import { Button } from "@/components/ui/button";
import { trackEvent } from "@/lib/analytics";

export default function Watchlist() {
  const [watchlist, setWatchlist] = useState<SavedItem[]>([]);

  useEffect(() => {
    setWatchlist(storage.getWatchlist());
  }, []);

  const handleRemove = (item: SavedItem) => {
    storage.removeFromWatchlist(item.id);
    setWatchlist(storage.getWatchlist());
    trackEvent("watchlist_changed", { action: "removed", content_type: item.type });
  };

  return (
    <div className="container mx-auto px-4 md:px-8 pt-24 pb-12 min-h-screen">
      <Helmet>
        <title>My Watchlist - StreamVault</title>
      </Helmet>

      <div className="flex items-center gap-3 mb-8">
        <Bookmark className="w-8 h-8 text-white" />
        <h1 className="text-3xl font-bold text-white tracking-tight">My Watchlist</h1>
      </div>

      {watchlist.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Bookmark className="w-20 h-20 text-white/10 mb-6" />
          <h2 className="text-2xl font-semibold text-white mb-2">Your watchlist is empty</h2>
          <p className="text-white/50 mb-8 max-w-md">
            Save movies and TV shows to watch later by clicking the plus icon.
          </p>
          <Link href="/">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white font-bold">
              Explore Content
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {watchlist.map((item) => (
            <div key={item.id} className="relative group">
              <MovieCard item={item} type={item.type} />
              <Button
                size="icon"
                variant="destructive"
                className="absolute -top-2 -right-2 z-20 opacity-0 group-hover:opacity-100 transition-opacity w-8 h-8 rounded-full shadow-lg"
                onClick={(e) => {
                  e.preventDefault();
                  handleRemove(item);
                }}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
