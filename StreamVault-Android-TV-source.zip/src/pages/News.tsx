import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { ExternalLink, RefreshCw, Search, WifiOff, Newspaper } from "lucide-react";
import { filterNewsChannels, getNewsChannel, newsCategories } from "@/lib/news";
import type { NewsCategory, NewsFilter } from "@/lib/news";
import NewsCard from "@/components/NewsCard";
import NewsCategorySection from "@/components/NewsCategorySection";
import { trackEvent } from "@/lib/analytics";

export default function News() {
  const [selectedId, setSelectedId] = useState("ntv-uganda");
  const [category, setCategory] = useState<NewsFilter>("All");
  const [search, setSearch] = useState("");
  const [collapsed, setCollapsed] = useState<Set<NewsCategory>>(() => new Set());
  const [retry, setRetry] = useState(0);
  const [online, setOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);

  const channel = getNewsChannel(selectedId);
  const list = filterNewsChannels(category, search);
  const sections = newsCategories
    .filter((c): c is NewsCategory => c !== "All")
    .map((c) => ({ category: c, items: list.filter((ch) => ch.category === c) }))
    .filter((s) => s.items.length > 0);

  // Search or category changes reopen every section so stale collapsed state cannot hide results.
  useEffect(() => { setCollapsed(new Set()); }, [category, search]);

  return (
    <div className="min-h-[100dvh] overflow-x-hidden bg-[#0d1112] pb-20 text-[#f3efe6]">
      <Helmet>
        <title>News — StreamVault</title>
        <meta name="description" content="Watch official East African and global news broadcasters on StreamVault, with direct links to every broadcaster's official viewing sources." />
      </Helmet>
      <div className="container mx-auto px-4 pt-24 md:px-8 md:pt-28">
        <div className="mb-6">
          <div className="mb-2 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.22em] text-[#f0b429]"><Newspaper className="h-4 w-4" /> News desk</div>
          <h1 className="text-3xl font-black tracking-tight sm:text-5xl">News channels</h1>
          <p className="mt-2 text-sm text-white/55">{filterNewsChannels("All", "").length} official broadcasters across East Africa, Africa, Global and Business.</p>
        </div>
        <div className="grid gap-8">
          <section aria-label="Player" className="min-w-0">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
              <h2 className="min-w-0 truncate text-lg font-bold" data-testid="text-news-channel-name">{channel.name}</h2>
              <div className="flex flex-wrap items-center gap-2">
                <a href={channel.officialUrl} target="_blank" rel="noopener noreferrer" data-testid="link-news-official" onClick={() => trackEvent("news_official_source_opened", { channel: channel.id })} className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 px-3 py-2 text-xs font-bold hover:border-[#f0b429]/60">
                  Official source <ExternalLink className="h-3.5 w-3.5" />
                </a>
                <button type="button" data-testid="button-news-reload" disabled={!online} onClick={() => { setRetry((n) => n + 1); trackEvent("news_player_reloaded", { channel: channel.id }); }} className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 px-3 py-2 text-xs font-bold hover:border-[#f0b429]/60 disabled:cursor-not-allowed disabled:opacity-40">
                  <RefreshCw className="h-3.5 w-3.5" /> Reload player
                </button>
              </div>
            </div>
            <div className={`aspect-video w-full overflow-hidden rounded-xl border border-white/10 bg-black ${!online ? "min-h-[260px]" : ""}`}>
              {!online ? (
                <div data-testid="state-news-offline" role="status" className="grid h-full place-items-center p-6 text-center">
                  <div><WifiOff className="mx-auto h-8 w-8 text-[#f0b429]" /><p className="mt-3 font-bold">You are offline</p><p className="mt-1 text-sm text-white/55">Reconnect to load the player. The official link stays available above.</p></div>
                </div>
              ) : (
                <iframe key={`${channel.id}-${retry}`} data-testid="iframe-news-player" title={`${channel.name} player`} src={channel.embedUrl} className="h-full w-full border-0" allow="autoplay; encrypted-media; picture-in-picture; fullscreen *" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen />
              )}
            </div>
          </section>

          <aside aria-label="Channels" className="min-w-0">
            <label className="relative block">
              <span className="sr-only">Search news channels</span>
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
              <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search channels" data-testid="input-news-search" className="h-11 w-full rounded-xl border border-white/10 bg-[#151b1c] pl-9 pr-3 text-sm outline-none focus:border-[#f0b429]/60" />
            </label>
            <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label="Filter by category">
              {newsCategories.map((c) => (
                <button key={c} type="button" aria-pressed={category === c} data-testid={`button-news-filter-${c.toLowerCase().replace(/\s+/g, "-")}`} onClick={() => { setCategory(c); trackEvent("news_category_selected", { category: c }); }} className={`rounded-full px-3 py-1.5 text-xs font-bold transition-colors ${category === c ? "bg-[#f0b429] text-[#17130a]" : "border border-white/15 text-white/65 hover:text-white"}`}>{c} <span className="ml-1 opacity-65">{filterNewsChannels(c, "").length}</span></button>
              ))}
            </div>
            <div className="mt-4">
              {list.length === 0 ? (
                <div data-testid="state-news-empty" className="rounded-xl border border-dashed border-white/15 p-6 text-center text-sm text-white/55">No channels match. Clear the search or choose another category.</div>
              ) : (
                <div className="grid gap-6">
                  <div className="flex justify-end gap-2">
                    <button type="button" data-testid="button-news-expand-all" onClick={() => setCollapsed(new Set())} className="rounded-full border border-white/15 px-3 py-1 text-xs font-bold text-white/65 hover:text-white">Expand all</button>
                    <button type="button" data-testid="button-news-collapse-all" onClick={() => setCollapsed(new Set(sections.map((s) => s.category)))} className="rounded-full border border-white/15 px-3 py-1 text-xs font-bold text-white/65 hover:text-white">Collapse all</button>
                  </div>
                  {sections.map((s) => (
                    <NewsCategorySection
                      key={s.category}
                      title={s.category}
                      count={s.items.length}
                      expanded={!collapsed.has(s.category)}
                      onToggle={() => setCollapsed((prev) => { const next = new Set(prev); if (next.has(s.category)) next.delete(s.category); else next.add(s.category); return next; })}
                    >
                      <div className="grid grid-cols-2 gap-x-4 gap-y-6 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                        {s.items.map((c) => (
                          <NewsCard key={c.id} channel={c} active={c.id === channel.id} onSelect={() => { setSelectedId(c.id); trackEvent("news_channel_selected", { channel: c.id, category: c.category }); }} />
                        ))}
                      </div>
                    </NewsCategorySection>
                  ))}
                </div>
              )}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
