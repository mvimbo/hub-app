import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import { Clapperboard, Globe2, Play, Search } from "lucide-react";
import { Link } from "wouter";
import { tmdb, getImageUrl } from "@/lib/tmdb";
import ContentRow from "@/components/ContentRow";
import { Button } from "@/components/ui/button";
import KoreanBadges from "@/components/KoreanBadges";

const koreanGenres = [
  { id: "18", label: "Korean Dramas" },
  { id: "10749", label: "Romantic K-Dramas" },
  { id: "53", label: "Korean Thrillers" },
  { id: "80", label: "Korean Crime" },
];

function KoreanHero({ item }: { item: any }) {
  if (!item) {
    return <div className="h-[52vh] min-h-[420px] bg-gradient-to-br from-rose-950 via-background to-background" />;
  }

  const title = item.name || item.title;
  const backdrop = getImageUrl(item.backdrop_path, "w1280");
  const type = item.media_type === "movie" ? "movie" : "tv";
  const watchUrl = type === "tv" ? `/watch/tv/${item.id}/1/1` : `/watch/movie/${item.id}`;

  return (
    <div className="relative h-[52vh] min-h-[420px] w-full overflow-hidden">
      {backdrop && <img src={backdrop} alt="" className="h-full w-full object-cover" />}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/75 to-background/10" />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/45 to-transparent" />
      <div className="absolute inset-x-0 bottom-0">
        <div className="container mx-auto px-4 md:px-8 pb-12 md:pb-16">
          <div className="flex items-center gap-2 text-rose-300 text-xs font-bold uppercase tracking-[0.2em] mb-4">
            <Globe2 className="w-4 h-4" /> Featured Korean watch
          </div>
          <h1 className="max-w-2xl text-4xl md:text-6xl font-bold text-white tracking-tight">{title}</h1>
          <p className="mt-4 max-w-xl text-white/65 line-clamp-3 leading-relaxed">
            {item.overview || "Discover standout Korean dramas, series, and movies selected for your next watch."}
          </p>
          <div className="mt-5">
            <KoreanBadges compact />
          </div>
          <div className="mt-6 flex items-center gap-3">
            <Link href={watchUrl}>
              <Button className="bg-primary hover:bg-primary/90 text-white font-bold gap-2">
                <Play className="w-4 h-4 fill-current" /> Watch now
              </Button>
            </Link>
            <Link href={`/${type}/${item.id}`}>
              <Button variant="outline" className="border-white/20 bg-black/30 text-white hover:bg-white/10 gap-2">
                <Clapperboard className="w-4 h-4" /> View details
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Korean() {
  const { data: popularTV, isLoading: popularTVLoading } = useQuery({
    queryKey: ["korean", "tv", "popular"],
    queryFn: () => tmdb.getKoreanTV("popularity.desc"),
  });
  const { data: topRatedTV, isLoading: topRatedTVLoading } = useQuery({
    queryKey: ["korean", "tv", "top-rated"],
    queryFn: () => tmdb.getKoreanTV("vote_average.desc"),
  });
  const { data: latestTV, isLoading: latestTVLoading } = useQuery({
    queryKey: ["korean", "tv", "latest"],
    queryFn: () => tmdb.getKoreanTV("first_air_date.desc"),
  });
  const { data: koreanMovies, isLoading: koreanMoviesLoading } = useQuery({
    queryKey: ["korean", "movies", "popular"],
    queryFn: () => tmdb.getKoreanMovies("popularity.desc"),
  });
  const { data: dramaTV, isLoading: dramaTVLoading } = useQuery({
    queryKey: ["korean", "genre", "18"],
    queryFn: () => tmdb.getKoreanTVByGenre("18"),
  });
  const { data: romanceTV, isLoading: romanceTVLoading } = useQuery({
    queryKey: ["korean", "genre", "10749"],
    queryFn: () => tmdb.getKoreanTVByGenre("10749"),
  });
  const { data: thrillerTV, isLoading: thrillerTVLoading } = useQuery({
    queryKey: ["korean", "genre", "53"],
    queryFn: () => tmdb.getKoreanTVByGenre("53"),
  });
  const { data: crimeTV, isLoading: crimeTVLoading } = useQuery({
    queryKey: ["korean", "genre", "80"],
    queryFn: () => tmdb.getKoreanTVByGenre("80"),
  });
  const { data: thrillerMovies, isLoading: thrillerMoviesLoading } = useQuery({
    queryKey: ["korean", "movies", "thriller"],
    queryFn: () => tmdb.getKoreanMoviesByGenre("53"),
  });
  const { data: acclaimedMovies, isLoading: acclaimedMoviesLoading } = useQuery({
    queryKey: ["korean", "movies", "drama"],
    queryFn: () => tmdb.getKoreanMoviesByGenre("18"),
  });

  const popularItems = (popularTV?.results ?? []).map((item: any) => ({ ...item, media_type: "tv" }));
  const topRatedItems = (topRatedTV?.results ?? []).map((item: any) => ({ ...item, media_type: "tv" }));
  const latestItems = (latestTV?.results ?? []).map((item: any) => ({ ...item, media_type: "tv" }));
  const movieItems = (koreanMovies?.results ?? []).map((item: any) => ({ ...item, media_type: "movie" }));

  return (
    <div className="min-h-screen pb-20">
      <Helmet>
        <title>Korean — StreamVault</title>
        <meta name="description" content="Browse popular Korean dramas, series, and movies on StreamVault." />
      </Helmet>

      <KoreanHero item={popularItems[0]} />

      <div className="relative z-10 -mt-4 flex flex-col gap-2 md:gap-4">
        <div className="container mx-auto px-4 md:px-8 pt-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl border border-rose-300/15 bg-rose-950/20 p-5">
            <div>
              <p className="text-rose-300 text-[11px] font-bold uppercase tracking-[0.18em] mb-1">Korean content guide</p>
              <p className="text-white/60 text-sm">Original Korean titles, audio context, and subtitle availability vary by provider.</p>
            </div>
            <Link href="/search?language=ko">
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 gap-2 whitespace-nowrap">
                <Search className="w-4 h-4" /> Search Korean titles
              </Button>
            </Link>
          </div>
        </div>
        <ContentRow
          title="Popular Korean Dramas"
          items={popularItems}
          type="tv"
          isLoading={popularTVLoading}
          showOriginalTitle
        />
        <ContentRow
          title="Top Rated Korean Series"
          items={topRatedItems}
          type="tv"
          isLoading={topRatedTVLoading}
          showOriginalTitle
        />
        <ContentRow
          title="Korean Movies"
          items={movieItems}
          type="movie"
          isLoading={koreanMoviesLoading}
          showOriginalTitle
        />
        <ContentRow
          title="Recently Released Korean Series"
          items={latestItems}
          type="tv"
          isLoading={latestTVLoading}
          showOriginalTitle
        />
        {[
          { genre: koreanGenres[0], data: dramaTV, isLoading: dramaTVLoading },
          { genre: koreanGenres[1], data: romanceTV, isLoading: romanceTVLoading },
          { genre: koreanGenres[2], data: thrillerTV, isLoading: thrillerTVLoading },
          { genre: koreanGenres[3], data: crimeTV, isLoading: crimeTVLoading },
        ].map(({ genre, data, isLoading }) => (
          <ContentRow
            key={genre.id}
            title={genre.label}
            items={(data?.results ?? []).map((item: any) => ({ ...item, media_type: "tv" }))}
            type="tv"
            isLoading={isLoading}
            showOriginalTitle
          />
        ))}
        <ContentRow
          title="Korean Thriller Movies"
          items={(thrillerMovies?.results ?? []).map((item: any) => ({ ...item, media_type: "movie" }))}
          type="movie"
          isLoading={thrillerMoviesLoading}
          showOriginalTitle
        />
        <ContentRow
          title="Korean Drama Movies"
          items={(acclaimedMovies?.results ?? []).map((item: any) => ({ ...item, media_type: "movie" }))}
          type="movie"
          isLoading={acclaimedMoviesLoading}
          showOriginalTitle
        />
      </div>
    </div>
  );
}