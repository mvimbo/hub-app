import { useCallback, useEffect, useState } from "react";
import { ShieldCheck, ShieldOff, AlertTriangle, RotateCcw, Smartphone } from "lucide-react";
import { getProtectionStatus, setProtectionEnabled, isAndroidApp, type ProtectionStatus } from "@/lib/native-protection";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function Settings() {
  const [status, setStatus] = useState<ProtectionStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const android = isAndroidApp();

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try { setStatus(await getProtectionStatus()); }
    catch (e) { setError(e instanceof Error ? e.message : "Could not read protection status."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const toggle = async (next: boolean) => {
    setPending(true); setError(null);
    try { setStatus(await setProtectionEnabled(next)); }
    catch (e) { setError(e instanceof Error ? e.message : "Could not change protection."); }
    finally { setPending(false); }
  };

  return (
    <div className="container mx-auto px-4 md:px-8 pt-24 pb-16 max-w-2xl">
      <h1 className="text-3xl font-bold mb-2" data-testid="text-settings-title">Settings</h1>
      <p className="text-white/60 mb-8">Protection preferences for this device.</p>

      <section className="rounded-lg border border-white/10 bg-card p-5 md:p-6" data-testid="section-protection">
        <div className="flex items-start justify-between gap-4">
          <div className="flex gap-3">
            {status?.enabled ? <ShieldCheck className="h-6 w-6 text-primary shrink-0" /> : <ShieldOff className="h-6 w-6 text-white/50 shrink-0" />}
            <div>
              <h2 className="font-semibold text-lg">Request protection</h2>
              <p className="text-sm text-white/60 mt-1">Blocks requests matching a known rule list inside the Android app. It reduces some ads and pop-ups from third-party providers but cannot block all of them.</p>
            </div>
          </div>
          {loading ? <Skeleton className="h-6 w-11 rounded-full" /> : (
            <Switch
              checked={!!status?.enabled}
              disabled={!status?.available || pending}
              onCheckedChange={(v) => void toggle(v)}
              aria-label="Request protection"
              data-testid="switch-protection"
            />
          )}
        </div>

        {pending && <p className="mt-4 text-sm text-white/60" data-testid="status-protection-pending">Applying change...</p>}

        {error && (
          <div className="mt-4 flex items-center justify-between gap-3 rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm" data-testid="status-protection-error">
            <span className="flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-destructive" />{error}</span>
            <Button size="sm" variant="secondary" onClick={() => void load()} data-testid="button-retry-protection"><RotateCcw className="h-4 w-4 mr-1" />Retry</Button>
          </div>
        )}

        {loading ? (
          <div className="mt-6 space-y-2"><Skeleton className="h-4 w-1/2" /><Skeleton className="h-4 w-1/3" /></div>
        ) : status && !status.available ? (
          <div className="mt-6 flex gap-3 rounded-md bg-white/5 p-4 text-sm text-white/70" data-testid="status-protection-unavailable">
            <Smartphone className="h-5 w-5 shrink-0" />
            <span>{status.reason ?? "Request protection is not available here."}</span>
          </div>
        ) : status ? (
          <dl className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
            <div className="rounded-md bg-white/5 p-3"><dt className="text-white/50">Status</dt><dd className="font-semibold mt-1" data-testid="text-protection-state">{status.enabled ? "On" : "Off"}</dd></div>
            <div className="rounded-md bg-white/5 p-3"><dt className="text-white/50">Pop-up blocking</dt><dd className="font-semibold mt-1" data-testid="text-popup-blocking">{status.popupBlocking ? "Active" : "Inactive"}</dd></div>
            <div className="rounded-md bg-white/5 p-3"><dt className="text-white/50">Rules loaded</dt><dd className="font-semibold mt-1 tabular-nums" data-testid="text-rule-count">{status.ruleCount.toLocaleString()}</dd></div>
            {android && (
              <div className="rounded-md bg-white/5 p-3 sm:col-span-3"><dt className="text-white/50">Requests blocked on this device</dt><dd className="font-semibold mt-1 tabular-nums text-xl" data-testid="text-blocked-requests">{status.blockedRequests.toLocaleString()}</dd></div>
            )}
            {status.reason && <p className="sm:col-span-3 text-white/60" data-testid="text-protection-reason">{status.reason}</p>}
          </dl>
        ) : null}
      </section>
    </div>
  );
}
