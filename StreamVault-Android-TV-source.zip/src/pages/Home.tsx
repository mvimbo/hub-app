import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import { Compass, Search } from "lucide-react";
import { Link } from "wouter";
import { tmdb, TMDB_API_KEY } from "@/lib/tmdb";
import HeroBanner from "@/components/HeroBanner";
import ContentRow from "@/components/ContentRow";
import ContinueWatchingRow from "@/components/ContinueWatchingRow";
import { useContinueWatching } from "@/hooks/useContinueWatching";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { items: continueWatching, remove } = useContinueWatching();
  const latestWatched = continueWatching[0];

  const { data: trending, isLoading: trendingLoading } = useQuery({
    queryKey: ["trending", "all", "week"],
    queryFn: () => tmdb.getTrending("all", "week"),
  });

  const { data: popularMovies, isLoading: popularMoviesLoading } = useQuery({
    queryKey: ["popular", "movie"],
    queryFn: () => tmdb.getPopularMovies(),
  });

  const { data: topRatedMovies, isLoading: topRatedMoviesLoading } = useQuery({
    queryKey: ["top_rated", "movie"],
    queryFn: () => tmdb.getTopRatedMovies(),
  });
  const { data: nowPlayingMovies, isLoading: nowPlayingMoviesLoading } = useQuery({
    queryKey: ["now_playing", "movie"],
    queryFn: () => tmdb.getNowPlayingMovies(),
  });
  const { data: actionMovies, isLoading: actionMoviesLoading } = useQuery({
    queryKey: ["home", "movies", "action"],
    queryFn: () => tmdb.getMoviesByGenre("28"),
  });
  const { data: comedyMovies, isLoading: comedyMoviesLoading } = useQuery({
    queryKey: ["home", "movies", "comedy"],
    queryFn: () => tmdb.getMoviesByGenre("35"),
  });
  const { data: sciFiMovies, isLoading: sciFiMoviesLoading } = useQuery({
    queryKey: ["home", "movies", "science-fiction"],
    queryFn: () => tmdb.getMoviesByGenre("878"),
  });
  const { data: horrorMovies, isLoading: horrorMoviesLoading } = useQuery({
    queryKey: ["home", "movies", "horror"],
    queryFn: () => tmdb.getMoviesByGenre("27"),
  });

  const { data: popularTV, isLoading: popularTVLoading } = useQuery({
    queryKey: ["popular", "tv"],
    queryFn: () => tmdb.getPopularTV(),
  });

  const { data: topRatedTV, isLoading: topRatedTVLoading } = useQuery({
    queryKey: ["top_rated", "tv"],
    queryFn: () => tmdb.getTopRatedTV(),
  });
  const { data: crimeTV, isLoading: crimeTVLoading } = useQuery({
    queryKey: ["home", "tv", "crime"],
    queryFn: () => tmdb.getTVByGenre("80"),
  });
  const { data: comedyTV, isLoading: comedyTVLoading } = useQuery({
    queryKey: ["home", "tv", "comedy"],
    queryFn: () => tmdb.getTVByGenre("35"),
  });
  const { data: latestTV, isLoading: latestTVLoading } = useQuery({
    queryKey: ["home", "tv", "latest"],
    queryFn: () => tmdb.getTVByGenre("18", "first_air_date.desc"),
  });

  const { data: personalizedSource } = useQuery({
    queryKey: ["personalized", latestWatched?.type, latestWatched?.id],
    queryFn: () => latestWatched?.type === "tv"
      ? tmdb.getTVDetails(latestWatched.id)
      : tmdb.getMovieDetails(latestWatched!.id),
    enabled: !!latestWatched,
  });

  const personalizedItems = personalizedSource?.recommendations?.results?.length
    ? personalizedSource.recommendations.results
    : personalizedSource?.similar?.results ?? [];
  const personalizedType = latestWatched?.type ?? "movie";

  return (
    <div className="pb-20">
      <Helmet>
        <title>StreamVault - Watch TV Shows & Movies</title>
        <meta name="description" content="Your personal cinema experience. Stream movies and TV shows." />
      </Helmet>

      {!TMDB_API_KEY && (
        <section
          role="status"
          data-testid="status-tmdb-configuration"
          className="container mx-auto px-4 md:px-8 pt-24"
        >
          <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 p-5 text-white/80">
            <h1 className="font-semibold text-white">Configure movie and TV metadata</h1>
            <p className="mt-2 text-sm">
              This standalone build needs your TMDB client API key to load movie and series catalogs.
              Set <code className="text-white">VITE_TMDB_API_KEY</code> in a private local
              <code className="text-white"> .env</code> file, then build the Android app again.
              News and sports do not need this key.
            </p>
            <a className="mt-2 inline-block text-sm text-primary underline" href="https://developer.themoviedb.org/docs/getting-started" target="_blank" rel="noreferrer">
              TMDB API setup
            </a>
          </div>
        </section>
      )}

      <HeroBanner items={trending?.results?.slice(0, 5) || []} />

      <div className="relative z-10 -mt-20 flex flex-col gap-2 md:gap-4 pb-8">
        <section className="container mx-auto px-4 md:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl border border-primary/20 bg-primary/[0.08] p-5 md:p-6">
            <div>
              <div className="flex items-center gap-2 text-primary text-[11px] font-bold uppercase tracking-[0.18em] mb-2">
                <Compass className="w-4 h-4" /> Your watch hub
              </div>
              <p className="text-white/65 text-sm">Curated movies and series, personalized picks, and new ways to find your next favorite.</p>
            </div>
            <Link href="/search">
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 gap-2 whitespace-nowrap">
                <Search className="w-4 h-4" /> Explore the catalog
              </Button>
            </Link>
          </div>
        </section>

        {/* Continue Watching — live, reactive, with remove + resume */}
        <ContinueWatchingRow items={continueWatching} onRemove={remove} />

        <ContentRow
          title={latestWatched ? `Because you watched ${latestWatched.title}` : "Recommended for you"}
          items={personalizedItems}
          type={personalizedType}
        />

        <ContentRow
          title="Trending Now"
          items={trending?.results || []}
          type="mixed"
          isLoading={trendingLoading}
        />

        <ContentRow
          title="Popular Movies"
          items={popularMovies?.results || []}
          type="movie"
          isLoading={popularMoviesLoading}
        />

        <ContentRow
          title="Top Rated Movies"
          items={topRatedMovies?.results || []}
          type="movie"
          isLoading={topRatedMoviesLoading}
        />
        <ContentRow
          title="Now Playing"
          items={nowPlayingMovies?.results || []}
          type="movie"
          isLoading={nowPlayingMoviesLoading}
        />
        <ContentRow
          title="Action & Adventure"
          items={actionMovies?.results || []}
          type="movie"
          isLoading={actionMoviesLoading}
        />
        <ContentRow
          title="Comedy Night"
          items={comedyMovies?.results || []}
          type="movie"
          isLoading={comedyMoviesLoading}
        />
        <ContentRow
          title="Science Fiction Worlds"
          items={sciFiMovies?.results || []}
          type="movie"
          isLoading={sciFiMoviesLoading}
        />
        <ContentRow
          title="Horror After Dark"
          items={horrorMovies?.results || []}
          type="movie"
          isLoading={horrorMoviesLoading}
        />

        <ContentRow
          title="Popular TV Shows"
          items={popularTV?.results || []}
          type="tv"
          isLoading={popularTVLoading}
        />

        <ContentRow
          title="Top Rated TV Shows"
          items={topRatedTV?.results || []}
          type="tv"
          isLoading={topRatedTVLoading}
        />
        <ContentRow
          title="Crime & Mystery Series"
          items={crimeTV?.results || []}
          type="tv"
          isLoading={crimeTVLoading}
        />
        <ContentRow
          title="Comedy Series"
          items={comedyTV?.results || []}
          type="tv"
          isLoading={comedyTVLoading}
        />
        <ContentRow
          title="Recently Released Series"
          items={latestTV?.results || []}
          type="tv"
          isLoading={latestTVLoading}
        />
      </div>
    </div>
  );
}
