import { useParams, Link, useLocation } from "wouter";
import { Helmet } from "react-helmet-async";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";
import { tmdb } from "@/lib/tmdb";
import VideoPlayer from "@/components/VideoPlayer";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";
import { storage } from "@/lib/storage";

export default function WatchTV() {
  const { id, season, episode } = useParams();
  const [, setLocation] = useLocation();

  const { data: tv } = useQuery({
    queryKey: ["tv", id],
    queryFn: () => tmdb.getTVDetails(id!),
    enabled: !!id,
  });

  const s = parseInt(season ?? "1");
  const e = parseInt(episode ?? "1");

  useEffect(() => {
    if (!tv || tv.id !== Number(id) || !Number.isSafeInteger(s) || s < 0 ||
      !Number.isSafeInteger(e) || e < 1) return;
    storage.recordOpened({
      id: tv.id, type: "tv", title: tv.name, poster_path: tv.poster_path,
      vote_average: tv.vote_average, release_date: tv.first_air_date,
      season: s, episode: e,
    });
  }, [tv, id, s, e]);

  return (
    <div className="min-h-screen bg-black">
      <Helmet>
        <title>Watching {tv?.name || "TV Show"} S{season} E{episode} - StreamVault</title>
      </Helmet>

      {/* Top Bar */}
      <div className="fixed top-0 left-0 w-full p-4 z-50 flex flex-wrap items-center justify-between bg-gradient-to-b from-black/80 to-transparent pointer-events-none gap-4">
        <Link href={`/tv/${id}`} className="pointer-events-auto">
          <div className="flex items-center gap-2 text-white/80 hover:text-white transition-colors cursor-pointer group bg-black/40 px-4 py-2 rounded-full backdrop-blur-md">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="font-medium hidden sm:inline">Back to details</span>
          </div>
        </Link>
        <div className="text-white font-bold bg-black/40 px-4 py-2 rounded-full backdrop-blur-md pointer-events-auto">
          {tv?.name} — S{season} E{episode}
        </div>
      </div>

      {/* Player */}
      <div className="pt-24 md:pt-0 min-h-screen flex flex-col justify-center max-w-[1600px] mx-auto p-4 md:p-8">
        <VideoPlayer
          tmdbId={id!}
          type="tv"
          season={season}
          episode={episode}
        />

        {/* Bottom bar */}
        <div className="mt-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 px-2 md:px-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-white">Season {season} Episode {episode}</h1>
            <p className="text-white/60 mt-1">{tv?.name}</p>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <Button
              variant="outline"
              onClick={() => { if (e > 1) setLocation(`/watch/tv/${id}/${s}/${e - 1}`); }}
              disabled={e <= 1}
              className="flex-1 md:flex-none border-white/20 text-white hover:bg-white/10"
            >
              <ChevronLeft className="w-4 h-4 mr-2" /> Prev Ep
            </Button>

            <Button
              onClick={() => setLocation(`/watch/tv/${id}/${s}/${e + 1}`)}
              className="flex-1 md:flex-none bg-primary hover:bg-primary/90 text-white font-bold"
            >
              Next Ep <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
