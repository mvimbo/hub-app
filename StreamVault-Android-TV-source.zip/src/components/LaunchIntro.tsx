import { useEffect, useReducer, useRef } from "react";
import { Play, RotateCcw } from "lucide-react";
import { introReducer, INITIAL_INTRO } from "@/lib/intro-state.mjs";
import { isAndroidApp } from "@/lib/native-protection";

export default function LaunchIntro({ onFinished }: { onFinished: () => void }) {
  const [state, dispatch] = useReducer(introReducer, INITIAL_INTRO);
  const videoRef = useRef<HTMLVideoElement>(null);
  const actionRef = useRef<HTMLButtonElement>(null);
  const finishedRef = useRef(onFinished);
  finishedRef.current = onFinished;
  const src = import.meta.env.BASE_URL.replace(/\/$/, "") +
    (isAndroidApp() ? "/launch-intro.android.mp4" : "/launch-intro.webm");

  const play = (restart: boolean) => {
    const v = videoRef.current;
    if (!v) return;
    if (restart) { v.load(); }
    v.muted = true;
    const p = v.play();
    if (p) p.catch((err: unknown) => {
      dispatch(err instanceof DOMException && err.name === "NotAllowedError" ? "autoplay-blocked" : "error");
    });
  };

  useEffect(() => { play(false); }, []);
  useEffect(() => { if (state === "done") finishedRef.current(); }, [state]);
  useEffect(() => { if (state === "blocked" || state === "error") actionRef.current?.focus(); }, [state]);

  // Swallow keyboard input while the intro owns the screen (except its own action button).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target === actionRef.current && (e.key === "Enter" || e.key === " ")) return;
      e.preventDefault(); e.stopPropagation();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, []);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden bg-black" data-testid="launch-intro" role="dialog" aria-label="StreamVault launch intro">
      <video
        ref={videoRef}
        src={src}
        autoPlay
        muted
        playsInline
        preload="auto"
        disablePictureInPicture
        className="max-h-[100dvh] max-w-full aspect-square object-contain"
        data-testid="video-launch-intro"
        onPlaying={() => dispatch("playing")}
        onEnded={() => dispatch("ended")}
        onError={() => dispatch("error")}
      />
      {(state === "blocked" || state === "error") && (
        <div className="absolute inset-x-0 bottom-12 flex flex-col items-center gap-3 px-6 text-center">
          <p className="text-sm text-white/70" data-testid="text-intro-status">
            {state === "blocked" ? "Tap to play the StreamVault intro." : "The intro could not play."}
          </p>
          <button
            ref={actionRef}
            type="button"
            onClick={() => { dispatch(state === "blocked" ? "start" : "retry"); play(state === "error"); }}
            className="tv-focus inline-flex items-center gap-2 rounded-md bg-primary px-6 py-3 font-semibold text-primary-foreground"
            data-testid={state === "blocked" ? "button-start-intro" : "button-retry-intro"}
          >
            {state === "blocked" ? <Play className="h-5 w-5" /> : <RotateCcw className="h-5 w-5" />}
            {state === "blocked" ? "Start intro" : "Retry intro"}
          </button>
        </div>
      )}
    </div>
  );
}
