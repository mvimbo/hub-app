import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Play, Info } from "lucide-react";
import { getImageUrl } from "@/lib/tmdb";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

interface HeroBannerProps {
  items: any[];
}

export default function HeroBanner({ items }: HeroBannerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!items || items.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % Math.min(items.length, 5));
    }, 8000);
    return () => clearInterval(interval);
  }, [items]);

  if (!items || items.length === 0) {
    return <div className="h-[70vh] md:h-[85vh] w-full bg-secondary animate-pulse" />;
  }

  const currentItem = items[currentIndex];
  const type = currentItem.media_type || "movie";
  const title = currentItem.title || currentItem.name;
  const overview = currentItem.overview;
  const backdropUrl = getImageUrl(currentItem.backdrop_path, "w1280");
  const detailUrl = `/${type}/${currentItem.id}`;
  const playUrl = `/watch/${type}/${currentItem.id}${type === 'tv' ? '/1/1' : ''}`;

  return (
    <div className="relative h-[70vh] md:h-[85vh] w-full overflow-hidden bg-black">
      <AnimatePresence mode="popLayout">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute inset-0"
        >
          {backdropUrl && (
            <img
              src={backdropUrl}
              alt={title}
              className="w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/50 to-transparent" />
        </motion.div>
      </AnimatePresence>

      <div className="absolute inset-0 flex items-center">
        <div className="container mx-auto px-4 md:px-8 mt-20">
          <motion.div
            key={`content-${currentIndex}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-2xl"
          >
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-4 text-shadow-lg tracking-tight leading-tight">
              {title}
            </h1>
            
            <p className="text-base md:text-lg text-white/90 mb-8 line-clamp-3 text-shadow-sm font-medium">
              {overview}
            </p>

            <div className="flex flex-wrap items-center gap-4">
              <Button
                size="lg"
                className="bg-white text-black hover:bg-white/90 font-bold px-8 text-base h-12"
                onClick={() => setLocation(playUrl)}
              >
                <Play className="w-5 h-5 mr-2 fill-current" /> Play
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-black/40 border-white/30 text-white hover:bg-white/20 font-bold px-8 text-base h-12 backdrop-blur-md"
                onClick={() => setLocation(detailUrl)}
              >
                <Info className="w-5 h-5 mr-2" /> More Info
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
