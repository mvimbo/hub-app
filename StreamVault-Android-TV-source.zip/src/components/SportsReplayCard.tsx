import { ExternalLink, Play, Tv2 } from "lucide-react";
import type { SportsEvent } from "@/lib/sports";

interface SportsReplayCardProps {
  event: SportsEvent;
  selected: boolean;
  onPlay: (event: SportsEvent) => void;
  onOpen: () => void;
}

export default function SportsReplayCard({ event, selected, onPlay, onOpen }: SportsReplayCardProps) {
  const image = event.thumbnail || (event.videoId ? `https://img.youtube.com/vi/${encodeURIComponent(event.videoId)}/hqdefault.jpg` : null);
  const gameDate = new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric" }).format(new Date(`${event.date}T12:00:00`));
  const hasScore = event.homeScore !== null && event.awayScore !== null;

  return (
    <article data-testid={`card-replay-${event.id}`} className={`overflow-hidden rounded-2xl border bg-[#101918] ${selected ? "border-[#c6f36b]/55" : "border-white/[0.09]"}`}>
      <div className="relative grid aspect-video place-items-center overflow-hidden bg-[linear-gradient(135deg,#1a2a26,#111716)]">
        {image && <img src={image} loading="lazy" alt="" className="absolute inset-0 h-full w-full object-cover opacity-55" />}
        <span className="absolute left-2 top-2 rounded bg-black/70 px-2 py-1 text-[9px] font-bold uppercase tracking-wide text-[#c6f36b]">Final · {gameDate}</span>
        {event.videoId ? (
          <button type="button" data-testid={`button-highlight-${event.id}`} aria-label={`Play highlights: ${event.homeTeam} vs ${event.awayTeam}`} onClick={() => onPlay(event)} className="relative grid h-12 w-12 place-items-center rounded-full border border-white/30 bg-black/65 text-white hover:bg-black/90">
            <Play className="ml-0.5 h-5 w-5 fill-current" />
          </button>
        ) : event.videoUrl ? (
          <a href={event.videoUrl} target="_blank" rel="noopener noreferrer" data-testid={`link-replay-video-${event.id}`} onClick={onOpen} className="relative inline-flex items-center gap-2 rounded-full border border-white/30 bg-black/75 px-4 py-3 text-xs font-bold text-white hover:bg-black">
            <Play className="h-4 w-4 fill-current" /> Watch on ESPN <ExternalLink className="h-3.5 w-3.5" />
          </a>
        ) : (
          <div className="relative px-4 text-center text-xs text-white/55"><Tv2 className="mx-auto mb-2 h-7 w-7 text-white/25" />{event.videoLookupFailed ? "Clip details temporarily unavailable" : "Highlights not supplied yet"}</div>
        )}
      </div>
      <div className="space-y-2 p-3.5">
        <h3 className="text-sm font-bold text-white">{event.homeTeam} <span className="text-white/35">vs</span> {event.awayTeam}</h3>
        <p className="text-xs text-white/50">{gameDate} {event.time?.slice(0, 5)}{hasScore && ` · ${event.homeScore}–${event.awayScore}`}</p>
        {event.videoTitle && <p className="line-clamp-2 text-xs leading-5 text-white/45">{event.videoTitle}</p>}
        {!event.videoUrl && event.coverageUrl && (
          <a href={event.coverageUrl} target="_blank" rel="noopener noreferrer" onClick={onOpen} data-testid={`link-replay-coverage-${event.id}`} className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#c6f36b] hover:text-white">
            Check official game coverage <ExternalLink className="h-3.5 w-3.5" />
          </a>
        )}
      </div>
    </article>
  );
}
