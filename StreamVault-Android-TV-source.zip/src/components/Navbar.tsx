import { Link, useLocation } from "wouter";
import { Search, Heart, Bookmark, Menu, X, History, Settings } from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Cartoon", path: "/cartoon" },
    { name: "Korean", path: "/korean" },
    { name: "Documentary", path: "/documentaries" },
    { name: "Sports", path: "/sports" },
    { name: "News", path: "/news" },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 w-full z-50 transition-colors duration-300",
        isScrolled ? "bg-background/95 backdrop-blur-md border-b border-white/10" : "bg-transparent bg-gradient-to-b from-black/80 to-transparent"
      )}
    >
      <div className="container mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="text-primary font-bold text-2xl tracking-tighter">
            StreamVault
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.path}
                data-testid={link.path === "/sports" ? "link-sports" : link.path === "/news" ? "link-news" : undefined}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location === link.path ? "text-white" : "text-white/70"
                )}
              >
                {link.name}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <Link href="/search" className="text-white/70 hover:text-white transition-colors">
            <Search className="w-5 h-5" />
          </Link>
          <Link href="/favorites" className="hidden md:block text-white/70 hover:text-white transition-colors" data-testid="link-favorites">
            <Heart className="w-5 h-5" />
          </Link>
          <Link href="/watchlist" className="hidden md:block text-white/70 hover:text-white transition-colors" data-testid="link-watchlist">
            <Bookmark className="w-5 h-5" />
          </Link>
          <Link href="/history" className="hidden md:block text-white/70 hover:text-white transition-colors" data-testid="link-history" title="Viewing history">
            <History className="w-5 h-5" />
          </Link>

          <Link href="/settings" className="hidden md:block text-white/70 hover:text-white transition-colors" data-testid="link-settings" title="Settings" aria-label="Settings">
            <Settings className="w-5 h-5" />
          </Link>

          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden text-white"
            aria-label={mobileMenuOpen ? "Close navigation" : "Open navigation"}
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-navigation"
            data-testid="button-mobile-menu"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div id="mobile-navigation" className="lg:hidden absolute top-16 left-0 w-full bg-background border-b border-white/10 flex flex-col p-4 shadow-xl">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.path}
              data-testid={link.path === "/sports" ? "link-sports-mobile" : link.path === "/news" ? "link-news-mobile" : undefined}
              onClick={() => setMobileMenuOpen(false)}
              className="py-3 px-4 text-white hover:bg-white/5 rounded-md font-medium"
            >
              {link.name}
            </Link>
          ))}
          <div className="h-px bg-white/10 my-2" />
          <Link href="/favorites" className="py-3 px-4 text-white hover:bg-white/5 rounded-md flex items-center gap-3">
            <Heart className="w-5 h-5" /> Favorites
          </Link>
          <Link href="/watchlist" className="py-3 px-4 text-white hover:bg-white/5 rounded-md flex items-center gap-3">
            <Bookmark className="w-5 h-5" /> Watchlist
          </Link>
          <Link href="/history" className="py-3 px-4 text-white hover:bg-white/5 rounded-md flex items-center gap-3">
            <History className="w-5 h-5" /> Viewing History
          </Link>
          <Link href="/settings" className="py-3 px-4 text-white hover:bg-white/5 rounded-md flex items-center gap-3" data-testid="link-settings-mobile">
            <Settings className="w-5 h-5" /> Settings
          </Link>
        </div>
      )}
    </header>
  );
}
