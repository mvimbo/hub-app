import { useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import MovieCard from "./MovieCard";
import SkeletonCard from "./SkeletonCard";

interface ContentRowProps {
  title: string;
  items: any[];
  type?: "movie" | "tv" | "mixed";
  isLoading?: boolean;
  link?: string;
  showProgress?: boolean;
  showOriginalTitle?: boolean;
}

export default function ContentRow({ title, items, type = "movie", isLoading, link, showProgress, showOriginalTitle }: ContentRowProps) {
  const rowRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  const scroll = (direction: "left" | "right") => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === "left" ? scrollLeft - clientWidth + 100 : scrollLeft + clientWidth - 100;
      rowRef.current.scrollTo({ left: scrollTo, behavior: "smooth" });
    }
  };

  if (!isLoading && (!items || items.length === 0)) return null;

  return (
    <div 
      className="py-4 md:py-6 group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="container mx-auto px-4 md:px-8 mb-3 flex items-center justify-between">
        <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">{title}</h2>
        {link && (
          <Link href={link} className="text-sm font-medium text-white/50 hover:text-white transition-colors">
            See All
          </Link>
        )}
      </div>

      <div className="relative">
        {/* Left Arrow */}
        <div 
          className={`absolute left-0 top-0 bottom-0 w-12 md:w-16 bg-black/60 backdrop-blur-sm z-20 flex items-center justify-center cursor-pointer transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'} hidden md:flex`}
          onClick={() => scroll("left")}
        >
          <ChevronLeft className="w-8 h-8 text-white hover:scale-125 transition-transform" />
        </div>

        {/* Row Container */}
        <div 
          ref={rowRef}
          className="flex gap-4 overflow-x-auto no-scrollbar px-4 md:px-8 pb-4 pt-2"
        >
          {isLoading ? (
            Array.from({ length: 10 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))
          ) : (
            items.map((item) => {
              const itemType = type === "mixed" ? (item.media_type || "movie") : type;
              return (
                <MovieCard 
                  key={`${itemType}-${item.id}`} 
                  item={item} 
                  type={itemType as "movie" | "tv"} 
                  showProgress={showProgress}
                  progress={item.progress}
                  showOriginalTitle={showOriginalTitle}
                />
              );
            })
          )}
        </div>

        {/* Right Arrow */}
        <div 
          className={`absolute right-0 top-0 bottom-0 w-12 md:w-16 bg-black/60 backdrop-blur-sm z-20 flex items-center justify-center cursor-pointer transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'} hidden md:flex`}
          onClick={() => scroll("right")}
        >
          <ChevronRight className="w-8 h-8 text-white hover:scale-125 transition-transform" />
        </div>
      </div>
    </div>
  );
}
