import { useState } from "react";
import { Play } from "lucide-react";
import type { NewsChannel } from "@/lib/news";

interface NewsCardProps {
  channel: NewsChannel;
  active: boolean;
  onSelect: () => void;
}

const YT_EMBED = /^https:\/\/(?:www\.youtube(?:-nocookie)?\.com)\/embed\/([A-Za-z0-9_-]{11})(?:[?#].*)?$/;

function thumbFor(channel: NewsChannel) {
  if (channel.embedProvider !== "YouTube") return null;
  const m = YT_EMBED.exec(channel.embedUrl);
  return m ? `https://i.ytimg.com/vi/${m[1]}/hqdefault.jpg` : null;
}

export default function NewsCard({ channel, active, onSelect }: NewsCardProps) {
  const [failed, setFailed] = useState(false);
  const thumb = thumbFor(channel);
  const showImage = !!thumb && !failed;
  return (
    <button
      type="button"
      aria-pressed={active}
      data-testid={`button-news-channel-${channel.id}`}
      onClick={onSelect}
      className="group flex w-full flex-col gap-2 rounded-lg text-left outline-none focus-visible:ring-2 focus-visible:ring-[#f0b429] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0d1112]"
    >
      <span className={`relative block aspect-video w-full overflow-hidden rounded-lg bg-[#151b1c] transition-transform duration-200 group-hover:scale-[1.03] group-focus-visible:scale-[1.03] ${active ? "ring-2 ring-[#f0b429]" : ""}`}>
        {showImage ? (
          <img src={thumb!} alt="" loading="lazy" referrerPolicy="no-referrer" onError={() => setFailed(true)} className="h-full w-full object-cover" />
        ) : (
          <span className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#1b2425] to-[#101516] p-3 text-center">
            <span className="text-lg font-black leading-tight tracking-tight text-[#f3efe6] sm:text-xl">{channel.shortName}</span>
          </span>
        )}
        <span className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-black">
            <Play className="ml-0.5 h-4 w-4 fill-current" />
          </span>
        </span>
        {active && <span className="absolute bottom-2 left-2 rounded bg-[#f0b429] px-1.5 py-0.5 text-[10px] font-bold text-[#17130a]">Selected</span>}
      </span>
      <span className="min-w-0">
        <span className="line-clamp-2 text-sm font-bold leading-tight text-white">{channel.name}</span>
        <span className="mt-1 block text-xs text-white/60">{channel.location} · {channel.language}</span>
        <span className="mt-0.5 block truncate text-[10px] font-bold uppercase tracking-wider text-white/45">{channel.category}</span>
        <span className="mt-1 line-clamp-2 text-xs text-white/55">{channel.description}</span>
      </span>
    </button>
  );
}
