import { BadgeCheck, Captions, Film, Globe2 } from "lucide-react";

interface DocumentaryBadgesProps {
  compact?: boolean;
}

export default function DocumentaryBadges({ compact = false }: DocumentaryBadgesProps) {
  const size = compact ? "w-3 h-3" : "w-3.5 h-3.5";
  const spacing = compact ? "px-2 py-1 text-[10px]" : "px-3 py-1.5 text-xs";

  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-cyan-400/15 text-cyan-200 ${spacing}`}>
        <Film className={size} /> Real stories
      </span>
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-white/10 text-white/75 ${spacing}`}>
        <Globe2 className={size} /> Documentary
      </span>
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-white/10 text-white/75 ${spacing}`}>
        <Captions className={size} /> Subtitles vary by source
      </span>
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-white/10 text-white/75 ${spacing}`}>
        <BadgeCheck className={size} /> Curated picks
      </span>
    </div>
  );
}