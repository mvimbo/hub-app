import { AudioLines, Captions, Languages } from "lucide-react";

interface KoreanBadgesProps {
  compact?: boolean;
}

export default function KoreanBadges({ compact = false }: KoreanBadgesProps) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-rose-500/15 text-rose-200 ${compact ? "px-2 py-1 text-[10px]" : "px-3 py-1.5 text-xs"}`}>
        <AudioLines className={compact ? "w-3 h-3" : "w-3.5 h-3.5"} /> Korean audio
      </span>
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-white/10 text-white/75 ${compact ? "px-2 py-1 text-[10px]" : "px-3 py-1.5 text-xs"}`}>
        <Languages className={compact ? "w-3 h-3" : "w-3.5 h-3.5"} /> Original Korean title
      </span>
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-white/10 text-white/75 ${compact ? "px-2 py-1 text-[10px]" : "px-3 py-1.5 text-xs"}`}>
        <Captions className={compact ? "w-3 h-3" : "w-3.5 h-3.5"} /> English subs vary by source
      </span>
    </div>
  );
}