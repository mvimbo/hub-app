interface SportsFeedStatusProps {
  updatedAt: number;
  now: number;
  online: boolean;
  isFetching: boolean;
  hasError: boolean;
  maxAge: number;
  testId: string;
}

export default function SportsFeedStatus({ updatedAt, now, online, isFetching, hasError, maxAge, testId }: SportsFeedStatusProps) {
  const age = Math.max(0, now - updatedAt);
  const stale = Boolean(updatedAt && age > maxAge);
  const warning = !online || hasError || stale;
  const status = !online
    ? "Offline — updates paused"
    : isFetching
      ? "Checking for updates…"
      : hasError
        ? "Update failed — retrying automatically"
        : stale
          ? "Data may be stale"
          : "Auto-refresh on";
  const elapsed = age < 60_000 ? "just now" : `${Math.floor(age / 60_000)} min ago`;

  return (
    <div data-testid={testId} className={`flex flex-wrap items-center gap-x-3 gap-y-1 text-xs ${warning ? "text-[#f2a184]" : "text-white/45"}`}>
      <span role="status">{status}</span>
      {updatedAt > 0 && (
        <span>
          Last checked <time dateTime={new Date(updatedAt).toISOString()} title={new Date(updatedAt).toLocaleString()}>{new Date(updatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</time> · {elapsed}
          {warning && " · showing last available data"}
        </span>
      )}
    </div>
  );
}
