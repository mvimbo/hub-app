import { useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Play, X, Tv } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { getImageUrl } from "@/lib/tmdb";
import { WatchProgress, getWatchUrl } from "@/lib/storage";
import { cn } from "@/lib/utils";

interface Props {
  items: WatchProgress[];
  onRemove: (id: number, type: WatchProgress["type"], season?: number, episode?: number) => void;
}

function ContinueCard({ item, onRemove }: { item: WatchProgress; onRemove: Props["onRemove"] }) {
  const title = item.title;
  const poster = getImageUrl(item.poster_path, "w500");
  const resumeUrl = getWatchUrl(item);

  return (
    <motion.div
      className="relative flex-none w-[160px] md:w-[220px] aspect-[2/3] rounded-lg overflow-hidden"
      whileHover={{ scale: 1.05, zIndex: 10 }}
      transition={{ duration: 0.2 }}
    >
      <Link href={resumeUrl} aria-label={`Continue ${title}${item.type === "tv" && item.season != null && item.episode != null ? `, season ${item.season}, episode ${item.episode}` : ""}`}
        data-testid={`link-continue-${item.type}-${item.id}`}
        className="block h-full w-full outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary">
        {poster ? (
          <img src={poster} alt="" className="w-full h-full object-cover" loading="lazy" />
        ) : (
          <div className="w-full h-full bg-zinc-800" />
        )}
        {item.type === "tv" && item.season != null && item.episode != null && (
          <span className="absolute top-2 left-2 flex items-center gap-1 bg-black/75 text-white text-[10px] font-bold px-2 py-1 rounded-full">
            <Tv className="w-2.5 h-2.5" /> S{item.season} E{item.episode}
          </span>
        )}
        <span className="absolute bottom-0 left-0 right-0 flex flex-col gap-2 bg-gradient-to-t from-black via-black/90 to-transparent p-3 pt-12">
          <span className="text-white font-bold text-sm line-clamp-2 leading-tight">{title}</span>
          <span className="flex items-center justify-center gap-2 rounded-lg bg-primary py-2 text-xs font-bold text-white">
            <Play className="h-3.5 w-3.5 fill-current" /> Continue
          </span>
        </span>
      </Link>
      <button type="button" onClick={() => onRemove(item.id, item.type, item.season, item.episode)}
        aria-label={`Remove ${title} from Continue Watching`}
        data-testid={`button-remove-continue-${item.type}-${item.id}`}
        className="absolute right-2 top-2 flex h-9 w-9 items-center justify-center rounded-full bg-black/80 text-white/80 hover:bg-black hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary"
        title="Remove from Continue Watching">
        <X className="h-4 w-4" />
      </button>
    </motion.div>
  );
}

export default function ContinueWatchingRow({ items, onRemove }: Props) {
  const rowRef = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState(false);

  const scroll = (dir: "left" | "right") => {
    if (!rowRef.current) return;
    const { scrollLeft, clientWidth } = rowRef.current;
    rowRef.current.scrollTo({
      left: dir === "left" ? scrollLeft - clientWidth + 100 : scrollLeft + clientWidth - 100,
      behavior: "smooth",
    });
  };

  if (!items.length) return null;

  return (
    <div
      className="py-4 md:py-6"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="container mx-auto px-4 md:px-8 mb-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">Continue Watching</h2>
          <span className="bg-primary/20 text-primary text-xs font-bold px-2 py-0.5 rounded-full">
            {items.length}
          </span>
        </div>
      </div>
      <p className="container mx-auto mb-3 px-4 text-xs text-white/50 md:px-8">
        Open your last selected movie or episode. Exact playback position is controlled by the video provider.
      </p>

      <div className="relative">
        <div
          className={cn(
            "absolute left-0 top-0 bottom-0 w-12 md:w-16 bg-black/60 backdrop-blur-sm z-20 items-center justify-center cursor-pointer transition-opacity duration-300 hidden md:flex",
            hovered ? "opacity-100" : "opacity-0"
          )}
          onClick={() => scroll("left")}
        >
          <ChevronLeft className="w-8 h-8 text-white hover:scale-125 transition-transform" />
        </div>

        <div
          ref={rowRef}
          className="flex gap-4 overflow-x-auto no-scrollbar px-4 md:px-8 pb-4 pt-2"
        >
            {items.map((item) => (
            <ContinueCard key={`${item.type}-${item.id}-${item.season ?? ""}-${item.episode ?? ""}`} item={item} onRemove={onRemove} />
          ))}
        </div>

        <div
          className={cn(
            "absolute right-0 top-0 bottom-0 w-12 md:w-16 bg-black/60 backdrop-blur-sm z-20 items-center justify-center cursor-pointer transition-opacity duration-300 hidden md:flex",
            hovered ? "opacity-100" : "opacity-0"
          )}
          onClick={() => scroll("right")}
        >
          <ChevronRight className="w-8 h-8 text-white hover:scale-125 transition-transform" />
        </div>
      </div>
    </div>
  );
}
