import { ExternalLink, Trophy } from "lucide-react";
import type { SportsStanding } from "@/lib/sports";

interface SportsStandingsTableProps {
  standings: SportsStanding[];
  isLoading: boolean;
  error: Error | null;
  officialStandingsUrl: string;
}

function OfficialStandingsLink({ href }: { href: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      data-testid="link-official-standings"
      className="inline-flex items-center gap-1.5 text-xs font-semibold text-white/55 transition-colors hover:text-[#c6f36b]"
    >
      Official standings <ExternalLink className="h-3.5 w-3.5" />
    </a>
  );
}

export default function SportsStandingsTable({
  standings,
  isLoading,
  error,
  officialStandingsUrl,
}: SportsStandingsTableProps) {
  return (
    <section className="overflow-hidden rounded-2xl border border-white/10 bg-[#111114]" aria-labelledby="sports-standings-title">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-4 py-4 md:px-5">
        <div className="flex items-center gap-2">
          <Trophy className="h-4 w-4 text-[#c6f36b]" />
          <h2 id="sports-standings-title" className="font-bold text-white">Standings</h2>
        </div>
        <OfficialStandingsLink href={officialStandingsUrl} />
      </div>

      {isLoading ? (
        <div role="status" aria-label="Loading standings" data-testid="status-sports-standings-loading" className="space-y-3 p-5">
          {Array.from({ length: 5 }, (_, index) => (
            <div key={index} className="h-8 animate-pulse rounded-lg bg-white/[0.06]" />
          ))}
        </div>
      ) : error && standings.length === 0 ? (
        <div className="p-5">
          <p role="alert" data-testid="status-sports-standings-error" className="text-sm text-white/55">
            Standings are temporarily unavailable from the data feed.
          </p>
          <a
            href={officialStandingsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-[#c6f36b] hover:underline"
          >
            Check the official table <ExternalLink className="h-4 w-4" />
          </a>
        </div>
      ) : standings.length === 0 ? (
        <div className="p-5">
          <p data-testid="text-sports-standings-unavailable" className="text-sm leading-relaxed text-white/55">
            This league’s table isn’t available in the current sports feed.
          </p>
          <a
            href={officialStandingsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-[#c6f36b] hover:underline"
          >
            View official standings <ExternalLink className="h-4 w-4" />
          </a>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <p data-testid="text-sports-standings-source-note" className="border-b border-white/[0.06] px-4 py-3 text-xs leading-relaxed text-white/40">
            Showing standings currently supplied by the free feed; check the official table for complete, up-to-date results.
          </p>
          <table className="w-full min-w-[570px] text-left text-xs">
            <caption className="sr-only">League standings supplied by the sports data feed</caption>
            <thead className="bg-white/[0.025] text-[10px] uppercase tracking-[0.12em] text-white/35">
              <tr>
                <th scope="col" className="px-3 py-3 text-center font-semibold">#</th>
                <th scope="col" className="px-3 py-3 font-semibold">Team</th>
                <th scope="col" className="px-2 py-3 text-center font-semibold">P</th>
                <th scope="col" className="px-2 py-3 text-center font-semibold">W</th>
                <th scope="col" className="px-2 py-3 text-center font-semibold">D</th>
                <th scope="col" className="px-2 py-3 text-center font-semibold">L</th>
                <th scope="col" className="px-2 py-3 text-center font-semibold">GD</th>
                <th scope="col" className="px-3 py-3 text-center font-semibold">Pts</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.06]">
              {standings.map((standing) => (
                <tr
                  key={standing.id}
                  data-testid={`row-sports-standing-${standing.id}`}
                  className="text-white/65 transition-colors hover:bg-white/[0.025]"
                >
                  <td className="px-3 py-3 text-center tabular-nums text-white/40">{standing.rank ?? "–"}</td>
                  <th scope="row" className="px-3 py-3 font-semibold text-white">
                    <span className="flex min-w-0 items-center gap-2">
                      {standing.badge ? (
                        <img src={standing.badge} alt="" className="h-5 w-5 shrink-0 object-contain" />
                      ) : (
                        <span className="h-5 w-5 shrink-0 rounded-full bg-white/10" />
                      )}
                      <span className="truncate">{standing.team}</span>
                    </span>
                  </th>
                  <td className="px-2 py-3 text-center tabular-nums">{standing.played ?? "–"}</td>
                  <td className="px-2 py-3 text-center tabular-nums">{standing.wins ?? "–"}</td>
                  <td className="px-2 py-3 text-center tabular-nums">{standing.draws ?? "–"}</td>
                  <td className="px-2 py-3 text-center tabular-nums">{standing.losses ?? "–"}</td>
                  <td className="px-2 py-3 text-center tabular-nums">{standing.goalDifference ?? "–"}</td>
                  <td className="px-3 py-3 text-center font-bold tabular-nums text-[#c6f36b]">{standing.points ?? "–"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}