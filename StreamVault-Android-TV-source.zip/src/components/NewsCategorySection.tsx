import type { ReactNode } from "react";
import { ChevronDown } from "lucide-react";

interface NewsCategorySectionProps {
  title: string;
  count: number;
  expanded: boolean;
  onToggle: () => void;
  children: ReactNode;
}

export default function NewsCategorySection({ title, count, expanded, onToggle, children }: NewsCategorySectionProps) {
  const slug = title.toLowerCase().replace(/\s+/g, "-");
  const panelId = `news-section-panel-${slug}`;
  return (
    <section aria-labelledby={`news-section-heading-${slug}`} data-testid={`section-news-${slug}`}>
      <h3 id={`news-section-heading-${slug}`} className="m-0">
        <button
          type="button"
          aria-expanded={expanded}
          aria-controls={panelId}
          data-testid={`button-news-section-${slug}`}
          onClick={onToggle}
          className="flex w-full items-center justify-between gap-3 rounded-lg border-b border-white/10 py-2 text-left outline-none focus-visible:ring-2 focus-visible:ring-[#f0b429] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0d1112]"
        >
          <span className="flex items-baseline gap-2">
            <span className="text-sm font-extrabold uppercase tracking-[0.18em] text-[#f3efe6]">{title}</span>
            <span className="text-xs font-bold text-[#f0b429]" data-testid={`text-news-section-count-${slug}`}>{count} {count === 1 ? "channel" : "channels"}</span>
          </span>
          <ChevronDown aria-hidden="true" className={`h-4 w-4 text-white/60 transition-transform ${expanded ? "rotate-180" : ""}`} />
        </button>
      </h3>
      <div id={panelId} hidden={!expanded} className="pt-4" data-testid={`panel-news-section-${slug}`}>
        {children}
      </div>
    </section>
  );
}
