import { useState } from "react";
import { Play, Heart, Plus, Check } from "lucide-react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { getImageUrl } from "@/lib/tmdb";
import { storage } from "@/lib/storage";
import { trackEvent } from "@/lib/analytics";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface MovieCardProps {
  item: any;
  type: "movie" | "tv";
  showProgress?: boolean;
  progress?: number;
  showOriginalTitle?: boolean;
}

export default function MovieCard({ item, type, showProgress, progress, showOriginalTitle }: MovieCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [, setLocation] = useLocation();
  const [isFave, setIsFave] = useState(() => storage.isFavorite(item.id));
  const [isWatchlist, setIsWatchlist] = useState(() => storage.isInWatchlist(item.id));

  const title = item.title || item.name;
  const releaseDate = item.release_date || item.first_air_date;
  const year = releaseDate ? new Date(releaseDate).getFullYear() : "";
  const detailUrl = `/${type}/${item.id}`;
  const playUrl = `/watch/${type}/${item.id}${type === 'tv' ? '/1/1' : ''}`; // Default to S1E1 for TV

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isFave) {
      storage.removeFavorite(item.id);
      setIsFave(false);
      trackEvent("favorite_changed", { action: "removed", content_type: type });
    } else {
      storage.addFavorite({
        id: item.id,
        type,
        title,
        poster_path: item.poster_path,
        vote_average: item.vote_average,
        release_date: releaseDate,
      });
      setIsFave(true);
      trackEvent("favorite_changed", { action: "added", content_type: type });
    }
  };

  const toggleWatchlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isWatchlist) {
      storage.removeFromWatchlist(item.id);
      setIsWatchlist(false);
      trackEvent("watchlist_changed", { action: "removed", content_type: type });
    } else {
      storage.addToWatchlist({
        id: item.id,
        type,
        title,
        poster_path: item.poster_path,
        vote_average: item.vote_average,
        release_date: releaseDate,
      });
      setIsWatchlist(true);
      trackEvent("watchlist_changed", { action: "added", content_type: type });
    }
  };

  const posterUrl = getImageUrl(item.poster_path, "w500");

  return (
    <motion.div
      className="relative flex-none w-[160px] md:w-[220px] aspect-[2/3] rounded-lg overflow-hidden group cursor-pointer"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      whileHover={{ scale: 1.05, zIndex: 10 }}
      transition={{ duration: 0.2 }}
      onClick={() => {
        trackEvent("content_opened", { content_type: type });
        setLocation(detailUrl);
      }}
    >
      {posterUrl ? (
        <img
          src={posterUrl}
          alt={title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      ) : (
        <div className="w-full h-full bg-secondary flex items-center justify-center text-center p-4">
          <span className="text-muted-foreground text-sm font-medium">{title}</span>
        </div>
      )}

      {/* Progress Bar for Continue Watching */}
      {showProgress && progress !== undefined && (
        <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-black/60">
          <div className="h-full bg-primary" style={{ width: `${progress}%` }} />
        </div>
      )}

      {/* Hover Overlay */}
      {isHovered && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 bg-black/80 p-4 flex flex-col justify-end gap-2"
        >
          <div className="flex flex-col gap-1">
            <h3 className="text-white font-bold text-sm line-clamp-2 leading-tight">
              {title}
            </h3>
            {showOriginalTitle && (item.original_title || item.original_name) && (
              <p className="text-white/50 text-[11px] line-clamp-1">
                {item.original_title || item.original_name}
              </p>
            )}
            <div className="flex items-center gap-2 text-xs text-white/70 font-medium">
              <span className="text-green-500">
                {item.vote_average ? Math.round(item.vote_average * 10) + "% Match" : "New"}
              </span>
              <span>{year}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 mt-2">
            <Button
              size="icon"
              className="h-8 w-8 rounded-full bg-white hover:bg-white/90 text-black shrink-0"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                trackEvent("playback_requested", { content_type: type });
                setLocation(playUrl);
              }}
              data-testid={`btn-play-${item.id}`}
            >
              <Play className="h-4 w-4 fill-current ml-0.5" />
            </Button>

            <Button
              size="icon"
              variant="outline"
              className="h-8 w-8 rounded-full border-white/40 bg-black/40 hover:bg-white/20 text-white shrink-0"
              onClick={toggleWatchlist}
              data-testid={`btn-watchlist-${item.id}`}
            >
              {isWatchlist ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            </Button>

            <Button
              size="icon"
              variant="outline"
              className="h-8 w-8 rounded-full border-white/40 bg-black/40 hover:bg-white/20 text-white shrink-0"
              onClick={toggleFavorite}
              data-testid={`btn-favorite-${item.id}`}
            >
              <Heart className={cn("h-4 w-4", isFave ? "fill-primary text-primary" : "")} />
            </Button>

          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
