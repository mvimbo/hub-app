export default function SkeletonCard() {
  return (
    <div className="flex-none w-[160px] md:w-[220px] aspect-[2/3] rounded-lg overflow-hidden bg-secondary animate-pulse relative">
      <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/5 to-transparent" />
    </div>
  );
}
