interface VideoPlayerProps {
  tmdbId: string | number;
  type: "movie" | "tv";
  season?: string | number;
  episode?: string | number;
}

function getEmbedUrl({ tmdbId, type, season, episode }: VideoPlayerProps) {
  const id = encodeURIComponent(String(tmdbId));
  if (type === "movie") {
    return `https://vidsrc.me/embed/movie?tmdb=${id}`;
  }

  const seasonNumber = encodeURIComponent(String(season ?? 1));
  const episodeNumber = encodeURIComponent(String(episode ?? 1));
  return `https://vidsrc.me/embed/tv?tmdb=${id}&season=${seasonNumber}&episode=${episodeNumber}`;
}

export default function VideoPlayer(props: VideoPlayerProps) {
  const { type, season, episode } = props;
  const embedUrl = getEmbedUrl(props);
  const title = type === "movie"
    ? "Movie player"
    : `Season ${season ?? 1}, episode ${episode ?? 1} player`;

  return (
    <div
      data-testid="video-embed-container"
      className="w-full overflow-hidden rounded-xl border border-white/10 bg-black shadow-2xl"
    >
      <div className="aspect-video w-full">
        <iframe
          title={title}
          src={embedUrl}
          className="block h-full w-full border-0"
          allow="autoplay; fullscreen *; encrypted-media; picture-in-picture"
          referrerPolicy="no-referrer"
          allowFullScreen
        />
      </div>
    </div>
  );
}
