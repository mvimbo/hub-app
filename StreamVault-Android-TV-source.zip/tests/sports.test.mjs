import { afterEach, test } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import ts from "typescript";

process.env.TZ = "Africa/Nairobi";
const source = await readFile(new URL("../src/lib/sports.ts", import.meta.url), "utf8");
const { outputText } = ts.transpileModule(source, {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
});
const sports = await import(`data:text/javascript;base64,${Buffer.from(outputText).toString("base64")}`);
const originalFetch = globalThis.fetch;
afterEach(() => { globalThis.fetch = originalFetch; });

function event(overrides = {}) {
  return {
    id: "game-1",
    name: "Away at Home",
    date: "2026-10-08T23:30:00Z",
    status: { type: { state: "in", detail: "9:22 - 1st Quarter" } },
    competitions: [{
      competitors: [
        { homeAway: "away", score: "7", team: { displayName: "Away" } },
        { homeAway: "home", score: "12", team: { displayName: "Home", logo: "https://example.com/logo.png" } },
      ],
      venue: { fullName: "Arena" },
    }],
    ...overrides,
  };
}

test("live scores deduplicate adjacent days and use the viewer's local kickoff date/time", async () => {
  const requests = [];
  globalThis.fetch = async (url, options) => {
    requests.push({ url: new URL(url), options });
    return Response.json({ events: [event(), event({ id: "other-day", date: "2026-10-08T12:00:00Z" })] });
  };
  const result = await sports.getSportsEventsForDate("4387", "2026-10-09");
  assert.equal(requests.length, 3);
  assert.deepEqual(requests.map(({ url }) => url.searchParams.get("dates")), ["20261008", "20261009", "20261010"]);
  assert.equal(requests[0].options.cache, "no-store");
  assert.equal(result.length, 1);
  assert.equal(result[0].time, "02:30:00");
  assert.equal(result[0].homeTeam, "Home");
  assert.equal(result[0].homeScore, 12);
  assert.equal(result[0].awayScore, 7);
  assert.match(result[0].status, /^Live/);
});

test("scheduled matches do not present default zero scores as results", async () => {
  globalThis.fetch = async () => Response.json({
    events: [event({ status: { type: { state: "pre", detail: "Scheduled" } } })],
  });
  const [result] = await sports.getSportsEventsForDate("4387", "2026-10-09");
  assert.equal(result.homeScore, null);
  assert.equal(result.awayScore, null);
  assert.equal(result.status, "Scheduled");
});

test("postponed fixtures keep their provider status rather than appearing live", async () => {
  globalThis.fetch = async () => Response.json({
    events: [event({ status: { type: { state: "pre", description: "Postponed", detail: "Provider date" } } })],
  });
  const [result] = await sports.getSportsEventsForDate("4387", "2026-10-09");
  assert.equal(result.status, "Postponed");
  assert.equal(result.homeScore, null);
});

test("finished results remain finished and unsafe badge URLs are discarded", async () => {
  const game = event({ status: { type: { state: "post", detail: "Final" } } });
  game.competitions[0].competitors[1].team.logo = "javascript:alert(1)";
  globalThis.fetch = async () => Response.json({ events: [game] });
  const [result] = await sports.getSportsEventsForDate("4387", "2026-10-09");
  assert.equal(result.status, "Final");
  assert.equal(result.homeBadge, null);
});

test("rate limits are reported with their HTTP status rather than empty fixtures", async () => {
  globalThis.fetch = async () => new Response("rate limited", { status: 429 });
  await assert.rejects(sports.getSportsEventsForDate("4387", "2026-10-09"), (error) =>
    error instanceof sports.SportsDataError && error.status === 429);
});

test("unexpected provider payloads fail explicitly", async () => {
  globalThis.fetch = async () => Response.json({ error: "temporarily unavailable" });
  await assert.rejects(sports.getSportsEventsForDate("4387", "2026-10-09"), /unexpected response/);
});

test("valid empty feeds do not fabricate fixtures", async () => {
  globalThis.fetch = async () => Response.json({ events: [] });
  assert.deepEqual(await sports.getSportsEventsForDate("4328", "2026-10-09"), []);
});

test("unknown leagues and invalid dates are rejected before network calls", async () => {
  globalThis.fetch = async () => { throw new Error("must not fetch"); };
  await assert.rejects(sports.getSportsEventsForDate("invalid", "2026-10-09"), /configured scoreboard/);
  await assert.rejects(sports.getSportsEventsForDate("4387", "2026-02-30"), /valid fixture date/);
});

test("aborted requests propagate cancellation instead of a fabricated successful response", async () => {
  globalThis.fetch = async (_url, { signal }) => {
    signal.throwIfAborted();
    throw new Error("must be aborted");
  };
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(sports.getSportsEventsForDate("4387", "2026-10-09", controller.signal), { name: "AbortError" });
});

test("midnight has an exact refresh deadline, including the near-midnight boundary", () => {
  assert.equal(sports.millisecondsUntilSportsMidnight(new Date("2026-10-08T23:59:58")), 2_000);
  assert.equal(sports.millisecondsUntilSportsMidnight(new Date("2026-10-09T00:00:00")), 24 * 60 * 60_000);
  assert.equal(sports.localSportsDate(new Date("2026-10-08T21:00:00Z")), "2026-10-09");
});

test("replays use completed scoreboard games and their exact official clips", async () => {
  let requestedUrl;
  const game = event({ status: { type: { state: "post", completed: true, detail: "Final" } } });
  game.competitions[0].highlights = [
    { headline: "A scoring moment", links: { web: { href: "https://www.espn.com/video/clip?id=1" } } },
    { headline: "Game Highlights", links: { web: { href: "https://www.espn.com/video/clip?id=2" } }, thumbnail: "https://example.com/clip.jpg" },
  ];
  globalThis.fetch = async (url) => {
    requestedUrl = new URL(url);
    return Response.json({ events: [game] });
  };
  const [result] = await sports.getSportsRecentEvents("4387", undefined, new Date("2026-10-09T12:00:00+03:00"));
  assert.match(requestedUrl.pathname, /basketball\/nba\/scoreboard$/);
  assert.equal(result.id, "game-1");
  assert.equal(result.videoUrl, "https://www.espn.com/video/clip?id=2");
  assert.equal(result.videoId, null);
  assert.equal(result.videoTitle, "Game Highlights");
});

test("replays keep the newest eight completed games even when some have no clip", async () => {
  const games = Array.from({ length: 10 }, (_, i) => event({
    id: `finished-${i}`, date: `2026-10-08T${String(10 + i).padStart(2, "0")}:00:00Z`,
    status: { type: { state: "post", completed: true, detail: "Final" } },
  }));
  games[0].competitions[0].highlights = [{ headline: "Oldest clip", links: { web: { href: "https://www.espn.com/video/clip?id=1" } } }];
  globalThis.fetch = async () => Response.json({ events: games });
  const result = await sports.getSportsRecentEvents("4387", undefined, new Date("2026-10-09T12:00:00+03:00"));
  assert.equal(result.length, 8);
  assert.deepEqual(result.map((game) => game.id), [9, 8, 7, 6, 5, 4, 3, 2].map((i) => `finished-${i}`));
  assert.ok(result.every((game) => game.videoUrl === null));
});

test("replays exclude live, scheduled, future, incomplete, and older games", async () => {
  const final = { type: { state: "post", completed: true, detail: "Final" } };
  const games = [
    event({ id: "valid", status: final }),
    event({ id: "live" }),
    event({ id: "scheduled", status: { type: { state: "pre" } } }),
    event({ id: "future", date: "2026-10-10T23:00:00Z", status: final }),
    event({ id: "old", date: "2026-09-20T23:00:00Z", status: final }),
    event({ id: "not-completed", status: { type: { state: "post", completed: false } } }),
    event({ id: "canceled", status: { type: { state: "post", completed: true, description: "Canceled" } } }),
  ];
  globalThis.fetch = async () => Response.json({ events: games });
  const result = await sports.getSportsRecentEvents("4387", undefined, new Date("2026-10-09T12:00:00+03:00"));
  assert.deepEqual(result.map((game) => game.id), ["valid"]);
});

test("replay links cannot send viewers to an untrusted clip site", async () => {
  const game = event({ status: { type: { state: "post", completed: true } } });
  game.competitions[0].highlights = [{ links: { web: { href: "https://untrusted.example/clip" } } }];
  game.links = [{ rel: ["summary"], href: "https://www.espn.com/nba/game/_/gameId/123" }];
  globalThis.fetch = async () => Response.json({ events: [game] });
  const [result] = await sports.getSportsRecentEvents("4387", undefined, new Date("2026-10-09T12:00:00+03:00"));
  assert.equal(result.videoUrl, null);
  assert.equal(result.coverageUrl, "https://www.espn.com/nba/game/_/gameId/123");
});

test("a league with no recent final games remains empty instead of showing old clips", async () => {
  let requests = 0;
  globalThis.fetch = async () => { requests += 1; return Response.json({ events: [] }); };
  const result = await sports.getSportsRecentEvents("4328", undefined, new Date("2026-10-09T12:00:00+03:00"));
  assert.deepEqual(result, []);
  assert.equal(requests, sports.SPORTS_REPLAY_LOOKBACK_DAYS + 2);
});

test("game-specific summary clips fill gaps without replacing the latest result", async () => {
  const game = event({ status: { type: { state: "post", completed: true, detail: "Final" } } });
  let summaryRequests = 0;
  globalThis.fetch = async (url) => {
    if (new URL(url).pathname.endsWith("/summary")) {
      summaryRequests += 1;
      assert.equal(new URL(url).searchParams.get("event"), game.id);
      return Response.json({ videos: [{ headline: "Game Highlights", links: { web: { href: "https://www.espn.com/video/clip?id=3" } } }] });
    }
    return Response.json({ events: [game] });
  };
  const [result] = await sports.getSportsRecentEvents("4391", undefined, new Date("2026-10-09T12:00:00+03:00"));
  assert.equal(summaryRequests, 1);
  assert.equal(result.id, game.id);
  assert.equal(result.videoUrl, "https://www.espn.com/video/clip?id=3");
  assert.equal(result.date, "2026-10-09");
});

test("failed video details preserve final games with an explicit temporary failure", async () => {
  const game = event({ status: { type: { state: "post", completed: true, detail: "Final" } } });
  globalThis.fetch = async (url) => new URL(url).pathname.endsWith("/summary")
    ? new Response("Unavailable", { status: 503 })
    : Response.json({ events: [game] });
  const [result] = await sports.getSportsRecentEvents("4391", undefined, new Date("2026-10-09T12:00:00+03:00"));
  assert.equal(result.id, game.id);
  assert.equal(result.videoUrl, null);
  assert.equal(result.videoLookupFailed, true);
});
