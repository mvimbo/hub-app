import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import ts from "typescript";

const source = await readFile(new URL("../src/lib/news.ts", import.meta.url), "utf8");
const { outputText } = ts.transpileModule(source, {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
});
const news = await import(`data:text/javascript;base64,${Buffer.from(outputText).toString("base64")}`);

test("the lineup contains 21 unique in-page broadcasters across every category", () => {
  assert.equal(news.newsChannels.length, 21);
  assert.equal(new Set(news.newsChannels.map((channel) => channel.id)).size, 21);
  assert.deepEqual(news.filterNewsChannels("East Africa", "").map((channel) => channel.id),
    ["ntv-uganda", "spark", "citizen-kenya", "ntv-kenya"]);
  assert.equal(news.filterNewsChannels("Global", "").length, 11);
  assert.equal(news.filterNewsChannels("Africa", "").length, 3);
  assert.equal(news.filterNewsChannels("Business", "").length, 3);
});

test("each broadcaster retains a secure official viewing link", () => {
  for (const channel of news.newsChannels) {
    assert.equal(new URL(channel.officialUrl).protocol, "https:");
    assert.ok(channel.description && channel.sourceNote && channel.language);
  }
});

test("player URLs are limited to verified player hosts, not full sites or direct video files", () => {
  const playerHosts = new Set([
    "ams-2629.antmedia.cloud", "embed.france24.com",
    "www.youtube.com", "www.youtube-nocookie.com",
  ]);
  for (const channel of news.newsChannels) {
    assert.ok(channel.embedUrl && channel.embedProvider);
    const url = new URL(channel.embedUrl);
    assert.equal(url.protocol, "https:");
    assert.ok(playerHosts.has(url.hostname), channel.name);
    assert.doesNotMatch(url.pathname, /\.(m3u8|mp4)$/i);
    if (channel.embedProvider === "YouTube") assert.match(url.pathname, /^\/embed\/[a-zA-Z0-9_-]{11}$/);
  }
});

test("Africa and Business filters expose the appropriate broadcasters", () => {
  assert.deepEqual(news.filterNewsChannels("Africa", "").map((channel) => channel.id),
    ["africanews", "channels-tv", "news-central"]);
  assert.deepEqual(news.filterNewsChannels("Business", "").map((channel) => channel.id),
    ["bloomberg", "cnbc-africa", "cnbc-tv18"]);
  assert.ok(news.filterNewsChannels("Global", "").every((channel) => channel.category === "Global"));
});

test("search is case-insensitive and respects the selected category", () => {
  assert.deepEqual(news.filterNewsChannels("All", "  CNA  ").map((channel) => channel.id), ["cna"]);
  assert.deepEqual(news.filterNewsChannels("East Africa", "CNA"), []);
  assert.deepEqual(news.filterNewsChannels("All", "LUGANDA").map((channel) => channel.id),
    ["ntv-uganda", "spark"]);
});

test("official-site-only channels are removed from the catalog and search results", () => {
  for (const id of ["nbs", "ubc", "bukedde", "sanyuka", "bbs", "sabc-news", "nbc-news", "cnbc",
    "ktn-home", "tbc-tanzania", "itv-tanzania", "ssbc"]) {
    assert.equal(news.newsChannels.some((channel) => channel.id === id), false);
    assert.equal(news.getNewsChannel(id).id, "ntv-uganda");
  }
  assert.deepEqual(news.filterNewsChannels("All", "Sanyuka"), []);
  assert.deepEqual(news.filterNewsChannels("All", "NBC News NOW"), []);
});

test("unknown channels default safely to NTV without introducing arbitrary iframe sources", () => {
  assert.equal(news.getNewsChannel("https://untrusted.example/iframe").id, "ntv-uganda");
  assert.equal(news.getNewsChannel(null).id, "ntv-uganda");
});

test("reported nonworking channels are absent from the lineup and search", () => {
  for (const [id, name] of [["rtnb", "RTNB"], ["rwanda-tv", "Rwanda TV"], ["ebc-news", "EBC"], ["kbc", "KBC"]]) {
    assert.equal(news.newsChannels.some((channel) => channel.id === id), false);
    assert.deepEqual(news.filterNewsChannels("All", name), []);
    assert.equal(news.getNewsChannel(id).id, "ntv-uganda");
  }
});

test("an empty result does not discard the independently selected broadcaster", () => {
  const selected = news.getNewsChannel("al-jazeera");
  assert.deepEqual(news.filterNewsChannels("East Africa", "no-such-station"), []);
  assert.equal(news.getNewsChannel(selected.id), selected);
});

test("East Africa replaces Uganda as a filter while keeping each channel's country", () => {
  assert.deepEqual(news.newsCategories, ["All", "East Africa", "Africa", "Global", "Business"]);
  assert.equal(news.getNewsChannel("ntv-uganda").location, "Uganda");
  assert.equal(news.getNewsChannel("ntv-uganda").category, "East Africa");
  const countries = new Set(news.filterNewsChannels("East Africa", "").map((channel) => channel.location));
  assert.deepEqual([...countries], ["Uganda", "Kenya"]);
  assert.deepEqual(news.filterNewsChannels("East Africa", "Tanzania"), []);
  assert.deepEqual(news.filterNewsChannels("East Africa", "Swahili").map((channel) => channel.id),
    ["citizen-kenya", "ntv-kenya"]);
});
