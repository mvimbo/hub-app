import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import ts from "typescript";

const source = await readFile(new URL("../src/lib/cartoons.ts", import.meta.url), "utf8");
const { outputText } = ts.transpileModule(source, {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
});
const { cartoonSeries, cartoonMovies, validateCartoon } = await import(
  `data:text/javascript;base64,${Buffer.from(outputText).toString("base64")}`
);

test("cartoons use a selected lineup of eight children's series and eight family films", () => {
  assert.equal(cartoonSeries.length, 8);
  assert.equal(cartoonMovies.length, 8);
  for (const entries of [cartoonSeries, cartoonMovies]) {
    assert.equal(new Set(entries.map((entry) => entry.id)).size, entries.length);
  }
  assert.deepEqual(cartoonSeries.slice(0, 3).map((entry) => entry.title), ["Bluey", "PAW Patrol", "Peppa Pig"]);
});

test("catalog rejects adult, nonanimated, mismatched and incorrect-ID results", () => {
  const expected = cartoonSeries[0];
  const item = { id: expected.id, name: expected.title, adult: false, genres: [{ id: 16 }] };
  assert.equal(validateCartoon(item, expected), item);
  for (const invalid of [
    { ...item, adult: true }, { ...item, genres: [{ id: 10763 }] },
    { ...item, name: "Unrelated program" }, { ...item, id: 1 },
  ]) assert.throws(() => validateCartoon(invalid, expected), /Unexpected catalog data/);
});

test("Cartoon replaces Anime in navigation with a redirect for old bookmarks", async () => {
  const nav = await readFile(new URL("../src/components/Navbar.tsx", import.meta.url), "utf8");
  const app = await readFile(new URL("../src/App.tsx", import.meta.url), "utf8");
  assert.match(nav, /name: "Cartoon", path: "\/cartoon"/);
  assert.doesNotMatch(nav, /name: "Anime"/);
  assert.match(app, /path="\/anime"><Redirect to="\/cartoon"/);
});
