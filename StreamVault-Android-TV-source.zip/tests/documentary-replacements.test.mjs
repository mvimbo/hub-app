import assert from "node:assert/strict";
import test from "node:test";
import {
  isRequestedDocumentary, replaceRequestedDocumentaries,
} from "../src/lib/documentary-replacements.mjs";

const card = (id, title, extra = {}) => ({
  id, title, genre_ids: [99], poster_path: `/original-${id}.jpg`, ...extra,
});
const candidates = [
  card(20, "Free Solo"),
  card(21, "My Octopus Teacher"),
  card(22, "Apollo 11"),
  card(23, "Another Documentary"),
];

test("matches the three named documentaries and their title punctuation variants only", () => {
  for (const title of [
    "My Massive Cock", "My Massive C**k", "Nude",
    "1,000 Men & Me: The Bonnie Blue Story",
  ]) assert.equal(isRequestedDocumentary(card(1, title)), true);
  for (const title of ["The Nude", "Nude Art", "Other Explicit Documentary", "1000 Men and Me: A Different Story"]) {
    assert.equal(isRequestedDocumentary(card(1, title)), false);
  }
  assert.equal(isRequestedDocumentary(card(1, "Nude", { genre_ids: [18] })), false);
});

test("replaces all three slots with real documentary metadata and preserves every other card", async () => {
  const untouched = card(4, "Unrelated Documentary", { adult: true });
  const items = [
    card(1, "My Massive Cock"), untouched,
    card(2, "Nude"), card(3, "1000 Men and Me"),
  ];
  const before = structuredClone(items);
  const output = await replaceRequestedDocumentaries(items, async () => candidates);
  assert.equal(output.length, items.length);
  assert.deepEqual(output.map((item) => item.id), [20, 4, 21, 22]);
  assert.strictEqual(output[1], untouched);
  assert.equal(output[0].poster_path, "/original-20.jpg");
  assert.equal(output[0].media_type, "movie");
  assert.deepEqual(items, before);
});

test("does not fetch replacements for unaffected lists or repeat an existing card", async () => {
  const items = [card(1, "Another Title")];
  assert.strictEqual(await replaceRequestedDocumentaries(items, () => {
    throw new Error("Unexpected request");
  }), items);
  const output = await replaceRequestedDocumentaries(
    [candidates[0], card(1, "Nude")], async () => candidates,
  );
  assert.equal(output[1].id, 21);
});

test("retains TV routes in mixed catalogs and uses the row's type when absent", async () => {
  const series = card(30, "Planet Earth", { name: "Planet Earth", title: undefined });
  const seenTypes = [];
  const loader = async (type) => { seenTypes.push(type); return [series]; };
  const output = await replaceRequestedDocumentaries([
    card(1, "Nude", { media_type: "tv" }),
  ], loader);
  assert.deepEqual(seenTypes, ["tv"]);
  assert.equal(output[0].media_type, "tv");
  assert.equal(output[0].id, 30);
  const tvRow = await replaceRequestedDocumentaries([card(1, "Nude")], loader, "tv");
  assert.equal(tvRow[0].media_type, "tv");
});

test("fails explicitly if genuine replacement cards cannot be loaded", async () => {
  await assert.rejects(
    replaceRequestedDocumentaries([card(1, "Nude")], async () => []),
    /Could not load a replacement/,
  );
});
