import assert from "node:assert/strict";
import { beforeEach, test } from "node:test";
import { storage, getWatchUrl, STORAGE_CHANGED_EVENT } from "../src/lib/storage.ts";

let values;
const movie = { id: 10, type: "movie", title: "Movie", poster_path: null };
const tv = { id: 10, type: "tv", title: "Series", poster_path: null, season: 2, episode: 3 };

beforeEach(() => {
  values = new Map();
  globalThis.localStorage = {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, String(value)),
  };
  globalThis.window = new EventTarget();
});

test("opened movies and episodes persist without inventing progress", () => {
  storage.recordOpened(movie);
  storage.recordOpened(tv);
  assert.equal(storage.getContinueWatching().length, 2);
  assert.equal(storage.getViewingHistory().length, 2);
  for (const item of storage.getContinueWatching()) {
    assert.equal(item.progress, 0);
    assert.equal(item.positionSecs, undefined);
    assert.equal(item.watched, undefined);
  }
  assert.deepEqual(storage.getViewingHistory(), JSON.parse(values.get("sv_continue_watching")));
});

test("existing history, saved positions and watchlist are preserved", () => {
  const existing = { ...tv, timestamp: 1, progress: 40, positionSecs: 900 };
  values.set("sv_continue_watching", JSON.stringify([existing]));
  const watchlist = JSON.stringify([{ ...movie, timestamp: 2 }]);
  values.set("sv_watchlist", watchlist);
  storage.recordOpened({ ...tv, title: "Updated series title" });
  const history = storage.getViewingHistory();
  assert.equal(history.length, 1);
  assert.equal(history[0].progress, 40);
  assert.equal(history[0].positionSecs, 900);
  assert.equal(history[0].title, "Updated series title");
  assert.equal(values.get("sv_watchlist"), watchlist);
});

test("Continue Watching shows only the latest episode while history retains earlier episodes", () => {
  values.set("sv_continue_watching", JSON.stringify([
    { ...tv, episode: 1, timestamp: 1, progress: 20 },
    { ...tv, episode: 2, timestamp: 2, progress: 30 },
    { ...movie, timestamp: 3, progress: 0 },
  ]));
  const visible = storage.getContinueWatching();
  assert.equal(visible.length, 2);
  assert.equal(visible.find(item => item.type === "tv").episode, 2);
  assert.equal(storage.getViewingHistory().length, 3);
  assert.equal(storage.getProgress(tv.id, "tv", 2, 1).progress, 20);
});

test("dismissing a series hides its older episodes but does not delete history or an overlapping movie ID", () => {
  storage.recordOpened({ ...tv, episode: 1 });
  storage.recordOpened(tv);
  storage.recordOpened(movie);
  const history = values.get("sv_continue_watching");
  storage.hideFromContinueWatching(tv.id, "tv");
  assert.equal(values.get("sv_continue_watching"), history);
  assert.deepEqual(storage.getContinueWatching().map(item => item.type), ["movie"]);
  // Hidden state survives future reads, and opening a new episode restores the series.
  assert.ok(JSON.parse(values.get("sv_continue_hidden")).includes("tv:10"));
  storage.recordOpened({ ...tv, episode: 4 });
  assert.equal(storage.getContinueWatching().find(item => item.type === "tv").episode, 4);
  assert.equal(storage.getViewingHistory().length, 4);
});

test("completed latest entries do not resurrect older unfinished episodes", () => {
  values.set("sv_continue_watching", JSON.stringify([
    { ...tv, episode: 1, timestamp: 1, progress: 20 },
    { ...tv, episode: 2, timestamp: 2, progress: 100, watched: true },
    { ...movie, timestamp: 3, progress: 95 },
  ]));
  assert.deepEqual(storage.getContinueWatching(), []);
  assert.equal(storage.getViewingHistory().length, 3);
  assert.equal(storage.getProgress(tv.id, "tv", 2, 2).watched, true);
});

test("explicit history deletion still works independently of Continue Watching dismissal", () => {
  storage.recordOpened(tv);
  storage.recordOpened(movie);
  storage.hideFromContinueWatching(tv.id, "tv");
  storage.removeProgress(tv.id, "tv", tv.season, tv.episode);
  assert.deepEqual(storage.getViewingHistory().map(item => item.type), ["movie"]);
});

test("watch links preserve episodes and send incomplete TV records to TV details, never movie playback", () => {
  assert.equal(getWatchUrl(movie), "/watch/movie/10");
  assert.equal(getWatchUrl(tv), "/watch/tv/10/2/3");
  assert.equal(getWatchUrl({ ...tv, season: 0 }), "/watch/tv/10/0/3");
  for (const invalid of [{ season: undefined }, { episode: undefined }, { episode: 0 }, { season: -1 }]) {
    assert.equal(getWatchUrl({ ...tv, ...invalid }), "/tv/10");
  }
});

test("same-tab changes notify consumers immediately without polling", () => {
  let events = 0;
  window.addEventListener(STORAGE_CHANGED_EVENT, () => { events++; });
  storage.recordOpened(movie);
  const previous = events;
  storage.hideFromContinueWatching(movie.id, "movie");
  assert.ok(previous > 0);
  assert.equal(events, previous + 1);
});

test("malformed saved collections do not crash the continue or history pages", () => {
  for (const invalid of ["invalid JSON", "{}", "null", JSON.stringify([null, {}, { ...movie, id: -1 }])]) {
    values.set("sv_continue_watching", invalid);
    assert.deepEqual(storage.getContinueWatching(), []);
    assert.deepEqual(storage.getViewingHistory(), []);
  }
});
