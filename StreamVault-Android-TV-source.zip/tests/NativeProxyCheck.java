import com.mvimbo.hubapp.DomainPolicy;
import com.mvimbo.hubapp.LocalFilteringProxy;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.io.*;

/** Offline smoke checks; does not contact playback providers. */
public class NativeProxyCheck {
    private static void require(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
    private static String request(int port, String authority) throws Exception {
        try (Socket socket = new Socket("127.0.0.1", port)) {
            socket.setSoTimeout(3000);
            socket.getOutputStream().write(("CONNECT " + authority
                + " HTTP/1.1\r\nHost: " + authority + "\r\n\r\n")
                .getBytes(StandardCharsets.US_ASCII));
            return new BufferedReader(new InputStreamReader(socket.getInputStream())).readLine();
        }
    }
    public static void main(String[] args) throws Exception {
        DomainPolicy policy = new DomainPolicy();
        require(policy.isBlocked("x.doubleclick.net"), "ad subdomain");
        require(policy.isBlocked("DOUBLECLICK.NET."), "normalized host");
        require(!policy.isBlocked("notdoubleclick.net"), "domain boundary");
        require(!policy.isBlocked("doubleclick.net.example.org"), "suffix boundary");
        for (String host : new String[] {"vidsrc.me", "youtube.com", "api.themoviedb.org", "image.tmdb.org"})
            require(!policy.isBlocked(host), "preserve video and metadata: " + host);
        for (String ip : new String[] {"127.0.0.1", "0.0.0.0", "10.0.0.1", "172.16.0.1",
            "192.168.1.1", "169.254.169.254", "100.64.0.1", "::1", "fc00::1", "fe80::1"})
            require(!DomainPolicy.isPublic(InetAddress.getByName(ip)), "private destination " + ip);
        require(DomainPolicy.isPublic(InetAddress.getByName("8.8.8.8")), "public IPv4");
        require(DomainPolicy.isPublic(InetAddress.getByName("2606:4700:4700::1111")), "public IPv6");
        try (LocalFilteringProxy proxy = new LocalFilteringProxy(policy)) {
            int port = proxy.start();
            require(request(port, "doubleclick.net:443").contains("403"), "blocked ad request");
            require(request(port, "127.0.0.1:443").contains("403"), "private connection forbidden");
            require(request(port, "example.org:22").contains("403"), "non-HTTPS port forbidden");
            require(policy.blocked.get() == 1, "only real ad blocks counted");
        }
        System.out.println("Native proxy offline smoke checks passed.");
    }
}
