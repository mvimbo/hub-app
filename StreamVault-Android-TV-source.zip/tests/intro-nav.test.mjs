import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { introReducer, INITIAL_INTRO, catalogUnlocked } from "../src/lib/intro-state.mjs";
import { pickNext, keepsArrowKey } from "../src/lib/tv-nav.mjs";

test("intro unlocks only on ended after playback", () => {
  let s = INITIAL_INTRO;
  s = introReducer(s, "ended"); assert.equal(catalogUnlocked(s), false);
  s = introReducer(s, "autoplay-blocked"); assert.equal(s, "blocked");
  s = introReducer(s, "start"); s = introReducer(s, "playing");
  s = introReducer(s, "ended"); assert.equal(catalogUnlocked(s), true);
});
test("error requires retry, no skip event", () => {
  let s = introReducer("playing", "error"); assert.equal(s, "error");
  assert.equal(introReducer(s, "skip"), "error");
  assert.equal(introReducer(s, "ended"), "error");
  assert.equal(introReducer(s, "retry"), "loading");
});
test("intro component has no skip, controls or timeout", () => {
  const src = readFileSync(new URL("../src/components/LaunchIntro.tsx", import.meta.url), "utf8");
  assert.doesNotMatch(src, /skip/i);
  assert.doesNotMatch(src, /setTimeout/);
  assert.doesNotMatch(src, /\bcontrols\b(?!List)/);
  assert.match(src, /onEnded/);
});
test("intro preserves the logo's square proportions against a full-screen black background", () => {
  const src = readFileSync(new URL("../src/components/LaunchIntro.tsx", import.meta.url), "utf8");
  assert.match(src, /className="fixed inset-0[^"]*bg-black"/);
  assert.match(src, /max-h-\[100dvh\] max-w-full aspect-square object-contain/);
});
test("geometric navigation", () => {
  const cur = { left: 0, top: 0, width: 100, height: 100 };
  const c = [{ left: 120, top: 0, width: 100, height: 100 }, { left: 0, top: 150, width: 100, height: 100 }, { left: 400, top: 10, width: 100, height: 100 }];
  assert.equal(pickNext(cur, c, "right"), 0);
  assert.equal(pickNext(cur, c, "down"), 1);
  assert.equal(pickNext(cur, c, "left"), -1);
  assert.equal(pickNext(cur, c, "up"), -1);
});
test("text cursor keys stay with inputs", () => {
  assert.equal(keepsArrowKey("input", "text", "left", 3, 3, 5), true);
  assert.equal(keepsArrowKey("input", "text", "left", 0, 0, 5), false);
  assert.equal(keepsArrowKey("input", "text", "right", 5, 5, 5), false);
  assert.equal(keepsArrowKey("input", "search", "down", 2, 2, 5), false);
  assert.equal(keepsArrowKey("textarea", null, "down", 0, 0, 0), true);
  assert.equal(keepsArrowKey("button", null, "left", null, null, 0), false);
});
