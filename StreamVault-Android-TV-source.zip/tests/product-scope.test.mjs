import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

const app = await readFile(new URL("../src/App.tsx", import.meta.url), "utf8");
const nav = await readFile(new URL("../src/components/Navbar.tsx", import.meta.url), "utf8");

test("the removed Music feature has no navigation, route, catalog, player or Spotify runtime", async () => {
  assert.doesNotMatch(app, /@\/pages\/Music|path="\/music"/);
  assert.doesNotMatch(nav, /name: "Music"|path: "\/music"/);
  for (const file of [
    "pages/Music.tsx", "lib/youtube-music.mjs", "lib/youtube-music.d.mts",
    "components/SpotifyAccountPlayer.tsx", "components/SpotifyEmbed.tsx",
    "hooks/useSpotifyPlayback.ts", "lib/spotify-auth.ts", "types/spotify-web-playback.d.ts",
  ]) {
    await assert.rejects(access(new URL(`../src/${file}`, import.meta.url)), { code: "ENOENT" });
  }
});

test("removed features leave News, Sports, Documentary and saved viewing data routes intact", () => {
  for (const path of ["news", "sports", "documentaries", "watchlist", "history", "favorites"]) {
    assert.ok(app.includes(`path="/${path}"`));
  }
});

test("Station has no navigation, page, player, catalog or server plugin", async () => {
  assert.doesNotMatch(app, /@\/pages\/Station|path="\/station"/);
  assert.doesNotMatch(nav, /name: "Station"|path: "\/station"/);
  const vite = await readFile(new URL("../vite.config.ts", import.meta.url), "utf8");
  assert.doesNotMatch(vite, /liveStationsPlugin|server\/stations/);
  for (const file of [
    "src/pages/Station.tsx", "src/components/StationCard.tsx",
    "src/components/StationCategorySection.tsx", "src/lib/station-channels.mjs",
    "src/lib/station-channels.d.mts", "server/stations.mjs", "server/stations.d.mts",
  ]) {
    await assert.rejects(access(new URL(`../${file}`, import.meta.url)), { code: "ENOENT" });
  }
});

test("the shared API contract and generated clients contain no Station operations or schemas", async () => {
  for (const file of [
    "api-spec/openapi.yaml", "api-client-react/src/generated/api.ts",
    "api-client-react/src/generated/api.schemas.ts", "api-zod/src/generated/api.ts",
    "api-zod/src/generated/types/index.ts",
  ]) {
    const content = await readFile(new URL(`../../../lib/${file}`, import.meta.url), "utf8");
    assert.doesNotMatch(content, /station/i);
    assert.match(content, /health/i);
  }
});
