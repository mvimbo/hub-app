import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.mvimbo.hubapp",
  appName: "StreamVault",
  webDir: "dist/public",
  android: {
    allowMixedContent: false,
    backgroundColor: "#000000",
    useLegacyBridge: false,
  },
};

export default config;
